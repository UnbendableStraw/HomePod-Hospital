#!/usr/bin/env python3
"""meter2sim: write a believable, moving /run/homepod/meter2 (contract B) without a HomePod.

For development, tests, and for showing the Live tab on a computer:

    python3 meter2sim.py [--path FILE] [--rate 15] [--profile apple3] [--seconds N] [--seed N]
                         [--hot]       (louder: the protection works hard most of the time)
                         [--idle]      (feeder running, nothing playing)

Music-like levels (a beat, bars, quiet and loud sections), bass that pushes the woofer towards
its excursion limit (the limiter and the sliding high-pass then act), supply power following the
bass, a 10 s average that creeps up to the 40 W budget in loud passages (then the control effort
rises), compressor bands and peak-limiter hits on the loudest moments. Same lock-free protocol as
hpfeed: seq is made odd, the fields are written, seq is made even again.
"""

import argparse
import math
import mmap
import os
import random
import struct
import time

FMT = struct.Struct("<4I2f8f8f4f12f2I2f3If8f")
SIZE = FMT.size          # 216
PROFILES = {"flat": 0, "apple": 1, "apple2": 2, "apple3": 3}
FIELDS = ("seq version playing profile in_rms in_peak "
          "r0 r1 r2 r3 r4 r5 r6 r7 k0 k1 k2 k3 k4 k5 k6 k7 "
          "drc0 drc1 drc2 drc3 hp_hz x_ask_mm x_out_mm xlim_mm p48_w p12_w pavg_w budget_w effort "
          "pg_w pg_t slow lim_w lim_t aref_db muted underruns fifo_min max_stall_us eq_on "
          "z0 z1 z2 z3 z4 z5 z6 z7").split()
assert len(FIELDS) == 54


def block(**kw):
    """A 216-byte meter2 block from named fields (missing = 0; version defaults to 2).
    Lists are accepted for drv_rms, drv_peak (8) and drc_db (4)."""
    v = dict.fromkeys(FIELDS, 0)
    v["version"] = 2
    for k, x in kw.items():
        if k == "drv_rms":
            for i, y in enumerate(x):
                v["r%d" % i] = y
        elif k == "drv_peak":
            for i, y in enumerate(x):
                v["k%d" % i] = y
        elif k == "drc_db":
            for i, y in enumerate(x):
                v["drc%d" % i] = y
        elif k in v:
            v[k] = x
        else:
            raise KeyError(k)
    vals = []
    for name, code in zip(FIELDS, "IIII" + "f" * 2 + "f" * 16 + "f" * 4 + "f" * 12 + "II" + "ff" + "III" + "f" + "f" * 8):
        vals.append(int(v[name]) if code == "I" else float(v[name]))
    return FMT.pack(*vals)


class Writer:
    """Maps the file (created and sized like hpfeed does) and publishes blocks with the seqlock."""

    def __init__(self, path):
        fd = os.open(path, os.O_RDWR | os.O_CREAT, 0o644)
        try:
            os.ftruncate(fd, SIZE)
            self.m = mmap.mmap(fd, SIZE, mmap.MAP_SHARED, mmap.PROT_READ | mmap.PROT_WRITE)
        finally:
            os.close(fd)
        self.seq = struct.unpack_from("<I", self.m, 0)[0] & ~1

    def begin(self):
        self.seq = (self.seq | 1) & 0xFFFFFFFF
        struct.pack_into("<I", self.m, 0, self.seq)

    def body(self, data):
        self.m[4:SIZE] = data[4:SIZE]

    def end(self):
        self.seq = (self.seq + 1) & 0xFFFFFFFF
        struct.pack_into("<I", self.m, 0, self.seq)

    def publish(self, data):
        self.begin()
        self.body(data)
        self.end()

    def close(self):
        self.m.close()


class Music:
    """A small generative model of a song through the apple3 chain."""

    def __init__(self, rate=15.0, profile="apple3", seed=None, hot=False, idle=False):
        self.dt = 1.0 / rate
        self.rnd = random.Random(seed)
        self.profile = PROFILES[profile]
        self.hot = hot
        self.idle = idle
        self.t = 0.0
        self.bpm = self.rnd.choice((92, 104, 118, 124, 128))
        self.section_left = 0.0
        self.loud = 0.5
        self.bassy = 0.6
        self.pavg = 6.0
        self.hp = 30.0
        self.effort = 0.0
        self.pgw = self.pgt = self.slow = 1.0
        self.underruns = 0
        self.vol_db = -4.0 if hot else -12.0
        self.drc = [0.0] * 4
        self.tw = [1.0] * 7

    def next_section(self):
        r = self.rnd
        self.section_left = r.uniform(6, 18)
        self.loud = r.choice((0.25, 0.45, 0.6, 0.8, 1.0))
        if self.hot:
            self.loud = min(1.0, self.loud + 0.35)
        self.bassy = r.uniform(0.35, 1.0)
        self.tw = [r.uniform(0.7, 1.1) for _ in range(7)]

    def step(self):
        r = self.rnd
        dt = self.dt
        self.t += dt
        self.section_left -= dt
        if self.section_left <= 0:
            self.next_section()
        if self.idle:
            return dict(playing=0, profile=self.profile, budget_w=40.0 if self.profile == 3 else 0,
                        xlim_mm=5.0 if self.profile == 3 else 0, hp_hz=30.0 if self.profile == 3 else 0,
                        pg_w=1.0, pg_t=1.0, slow=1.0, p48_w=5.6 if self.profile == 3 else 0,
                        pavg_w=5.6 if self.profile == 3 else 0,
                        p12_w=1.2 if self.profile == 3 else 0, aref_db=self.vol_db,
                        fifo_min=r.randint(11, 14), max_stall_us=r.randint(40, 90))
        beat = self.t * self.bpm / 60.0
        ph = beat - math.floor(beat)
        kick = math.exp(-ph * 7.0)                       # a kick drum on every beat
        snare = math.exp(-((beat + 0.5) % 2.0) * 9.0)    # backbeat
        swell = 0.75 + 0.25 * math.sin(self.t * 0.37) * math.sin(self.t * 0.11 + 1.0)
        vol = 10 ** (self.vol_db / 20.0) * 2.4
        base = self.loud * swell
        bass = min(1.0, base * self.bassy * (0.35 + 0.65 * kick) * vol * (2.6 if self.hot else 1.6))
        mid = min(1.0, base * (0.25 + 0.2 * snare + 0.1 * r.random()) * vol)
        top = min(1.0, base * (0.12 + 0.25 * snare + 0.12 * r.random()) * vol)
        in_rms = min(1.0, base * (0.18 + 0.1 * kick) * 1.0)
        in_peak = min(1.0, in_rms * r.uniform(2.6, 4.0))

        out = {"playing": 1, "profile": self.profile, "in_rms": in_rms, "in_peak": in_peak,
               "aref_db": self.vol_db, "fifo_min": r.randint(8, 14),
               "max_stall_us": int(r.uniform(50, 140) + (900 if r.random() < 0.003 else 0)),
               "eq_on": 0}
        if r.random() < 0.0008:
            self.underruns += 1
        out["underruns"] = self.underruns

        # woofer
        w_rms = bass * 0.45
        if self.profile == 3:
            xlim = 5.0
            x_ask = bass * 7.5 * (100.0 / max(self.hp, 30.0)) ** 0.5
            if x_ask > xlim * 0.92:                       # pushing: the sliding high-pass rises
                self.hp = min(110.0, self.hp + (x_ask - xlim * 0.92) * 12.0 * dt)
            else:
                self.hp = max(30.0, self.hp - 25.0 * dt)
            x_out = min(x_ask, xlim * (0.9 + 0.1 * (1 - math.exp(-(x_ask - xlim * 0.9) if x_ask > xlim * 0.9 else 0))))
            x_out = min(x_out, xlim)
            if x_ask > x_out:
                w_rms *= x_out / x_ask
            w_rms *= (30.0 / self.hp) ** 0.35
            out.update(x_ask_mm=x_ask, x_out_mm=x_out, xlim_mm=xlim, hp_hz=self.hp)
        w_pk = min(1.0, w_rms * r.uniform(1.4, 1.9))

        # tweeters (slot 4 = front a little hotter, as with a wall placement)
        trms, tpk = [], []
        for k in range(7):
            a = min(1.0, (mid * 0.55 + top * 0.45) * 0.5 * self.tw[k] * (1.12 if k == 3 else 1.0))
            trms.append(a)
            tpk.append(min(1.0, a * r.uniform(2.2, 3.4)))

        if self.profile == 3:
            # power: woofer electrical (39 V, ~3.4 ohm) at 90 %, tweeters 12.6 V / 3.2 ohm at 75 %
            g = 1.0 - 0.6 * self.effort                  # the back-off acts on the woofer drive
            w_rms *= g
            w_pk *= g
            pw = (w_rms * 39.0) ** 2 / 3.4 / 0.9
            p12 = sum((a * 12.6) ** 2 / 3.2 for a in trms) / 0.75 + 1.0
            p48 = pw * r.uniform(0.9, 1.3) + 4.0 + p12 / 0.9
            self.pavg += (p48 - self.pavg) * (1 - math.exp(-dt / 10.0))
            budget = 40.0
            if self.pavg > budget * 0.7:
                self.effort = min(1.0, self.effort + (self.pavg - budget * 0.7) / budget * dt * 3.0)
            else:
                self.effort = max(0.0, self.effort - 0.08 * dt)
            # power limiter (64 ms peaks above the short-term limits)
            self.pgw = min(1.0, self.pgw + 0.6 * dt) if p48 < 70 else max(0.5, 70.0 / p48)
            self.pgt = min(1.0, self.pgt + 0.6 * dt) if p12 < 18 else max(0.5, 18.0 / p12)
            # compressor bands: bass band works first
            lvl = [bass, mid * 0.9, mid * 0.7 + top * 0.3, top]
            for i in range(4):
                thr = (0.42, 0.55, 0.6, 0.6)[i]
                want = -min(9.0, max(0.0, (lvl[i] - thr) * 24.0))
                self.drc[i] += (want - self.drc[i]) * (0.6 if want < self.drc[i] else 0.12)
            hits_w = r.randint(1, 30) if w_pk > 0.3 and r.random() < 0.5 else 0
            hits_t = r.randint(1, 12) if max(tpk) > 0.3 and r.random() < 0.5 else 0
            if hits_w or hits_t:
                self.slow = min(self.slow, r.uniform(0.7, 0.95))
            else:
                self.slow = min(1.0, self.slow + 0.4 * dt)
            out.update(p48_w=p48, p12_w=p12, pavg_w=self.pavg, budget_w=budget, effort=self.effort,
                       pg_w=self.pgw, pg_t=self.pgt, slow=self.slow, lim_w=hits_w, lim_t=hits_t,
                       drc_db=list(self.drc))
        out["drv_rms"] = [w_rms] + trms
        out["drv_peak"] = [w_pk] + tpk
        return out


def main():
    ap = argparse.ArgumentParser(description=__doc__.split("\n")[0])
    ap.add_argument("--path", default="/run/homepod/meter2")
    ap.add_argument("--rate", type=float, default=15.0)
    ap.add_argument("--profile", default="apple3", choices=sorted(PROFILES))
    ap.add_argument("--seconds", type=float, default=0, help="stop after this long (0 = run until killed)")
    ap.add_argument("--seed", type=int, default=None)
    ap.add_argument("--hot", action="store_true")
    ap.add_argument("--idle", action="store_true")
    a = ap.parse_args()
    w = Writer(a.path)
    m = Music(a.rate, a.profile, a.seed, a.hot, a.idle)
    t0 = time.monotonic()
    nxt = t0
    try:
        while not a.seconds or time.monotonic() - t0 < a.seconds:
            w.publish(block(**m.step()))
            nxt += 1.0 / a.rate
            time.sleep(max(0.0, nxt - time.monotonic()))
    except KeyboardInterrupt:
        pass
    w.close()


if __name__ == "__main__":
    main()
