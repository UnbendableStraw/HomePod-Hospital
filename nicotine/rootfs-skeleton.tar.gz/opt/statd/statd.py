#!/usr/bin/env python3
"""homepod-statd: the status daemon behind the web page's Live tab.

Read-only. It never touches hardware: it reads files the other daemons write and the
amplifier daemon's HTTP API, and serves them on TCP port 8081 (all addresses):

  GET /api/meters   server-sent events, one JSON object per event, ~15 a second, built from
                    /run/homepod/meter2 (written by hpfeed). Nothing is read or computed while no
                    client is connected.
  GET /api/status   one JSON document (amplifier state and temperatures, volume, sound settings,
                    now playing, lights, feeder health). Cached for a second.
  GET /api/history  the four amplifier-board temperatures, one point every 10 s, last 2 hours.

Everything else is answered 404 (unknown path) or 405 (any method but GET). No query parameter is
interpreted, no file is served, requests are limited to 2 KiB of headers that must arrive within
5 s. One thread runs a select() loop for all connections and the meter stream; one worker thread
answers /api/status and samples the amplifier daemon every 10 s for the history.

Standard library only (the pod's python 3.14 has no ssl and no sqlite3; neither is used).
"""

import errno
import json
import math
import mmap
import os
import queue
import selectors
import signal
import socket
import struct
import sys
import threading
import time
from collections import deque

RUN = os.environ.get("HOMEPOD_STATD_RUN", "/run/homepod")
ETC = os.environ.get("HOMEPOD_STATD_ETC", "/etc")
METER2 = os.environ.get("HOMEPOD_STATD_METER", RUN + "/meter2")
PORT = int(os.environ.get("HOMEPOD_STATD_PORT", "8081"))
BIND = os.environ.get("HOMEPOD_STATD_BIND", "")            # "" = all addresses (v6 + v4 if possible)
AMP = os.environ.get("HOMEPOD_STATD_AMP", "127.0.0.1:7001")
RATE = float(os.environ.get("HOMEPOD_STATD_RATE", "15"))    # meter events per second
STATE = RUN + "/statd.state"

MAX_CONN = 32            # every open connection, any kind
MAX_SSE = 8              # meter streams
REQ_MAX = 2048           # bytes of request line + headers
REQ_TIME = 5.0           # seconds to deliver them
RESP_TIME = 10.0         # seconds to take a whole non-stream answer
SSE_SNDBUF = 32768      # kernel send buffer per meter client: about 3 s of events
STALL_CLOSE = 15.0       # a meter client that has taken nothing for this long is closed
KEEPALIVE = 5.0          # comment line after this long without an event
STALE = 1.0              # meter2 sequence unchanged this long: the feeder is not running
HIST_STEP = 10.0
HIST_LEN = 720           # 2 hours

# ---------------------------------------------------------------- meter2 (contract B)
M2_SIZE = 216
M2_FMT = struct.Struct("<4I2f8f8f4f12f2I2f3If8f")
assert M2_FMT.size == M2_SIZE
PROFILES = ("flat", "apple", "apple2", "apple3")

# Power estimate per driver: P = (level x V_fullscale)^2 / R, electrical, from the RMS level.
#   tweeters: 12.6 V at full scale into 3.2 ohm (Apple's own constants, apple_pg[3], [6]);
#   woofer:   39 V at full scale into 3.4 ohm, an ASSUMPTION: the real part of Apple's woofer
#             admittance model (apple_adm_fir) is about 0.29 S (3.4 ohm) from 150 to 500 Hz; its DC
#             resistance is 2.8 ohm and near the ~100 Hz resonance the real power is far lower.
# The DSP's own 48 V / 12 V supply figures (p48_w, p12_w) are the better total; these per-driver
# numbers only show how the power is spread and are labelled "estimate" on the page.
V_W, R_W = 39.0, 3.4
V_T, R_T = 12.6, 3.2
K_W = V_W * V_W / R_W
K_T = V_T * V_T / R_T


class MeterReader:
    """Lock-free reader of /run/homepod/meter2: mapped once, re-mapped when the file is replaced,
    shrinks, or disappears (checked at most once a second)."""

    def __init__(self, path=METER2):
        self.path = path
        self.m = None
        self.ident = None
        self.checked = 0.0
        self.retries = 0                  # torn reads seen (for tests and curiosity)

    def close(self):
        if self.m is not None:
            try:
                self.m.close()
            except (OSError, BufferError):
                pass
        self.m = None
        self.ident = None

    def _open(self):
        self.close()
        try:
            fd = os.open(self.path, os.O_RDONLY)
        except OSError:
            return False
        try:
            st = os.fstat(fd)
            if st.st_size < M2_SIZE:
                return False
            self.m = mmap.mmap(fd, M2_SIZE, mmap.MAP_SHARED, mmap.PROT_READ)
            self.ident = (st.st_dev, st.st_ino)
            return True
        except (OSError, ValueError):
            self.m = None
            return False
        finally:
            os.close(fd)

    def check(self, now):
        """Re-validate the mapping (stat) at most once a second. True if mapped."""
        if now - self.checked < 1.0 and self.m is not None:
            return True
        self.checked = now
        try:
            st = os.stat(self.path)
            if self.m is not None and (st.st_dev, st.st_ino) == self.ident and st.st_size >= M2_SIZE:
                return True
        except OSError:
            self.close()
            return False
        return self._open()

    def read(self, now=None):
        """(seq, tuple of fields) of a consistent copy, or None (absent, wrong version, torn)."""
        if now is None:
            now = time.monotonic()
        if not self.check(now):
            return None
        m = self.m
        unpack_from = M2_FMT.unpack_from
        try:
            for _ in range(16):
                s0 = m[0] | m[1] << 8 | m[2] << 16 | m[3] << 24
                if s0 & 1:
                    self.retries += 1
                    time.sleep(0.0002)
                    continue
                b = m[:M2_SIZE]
                if b[0] | b[1] << 8 | b[2] << 16 | b[3] << 24 != s0:
                    self.retries += 1
                    continue
                s1 = m[0] | m[1] << 8 | m[2] << 16 | m[3] << 24
                if s1 != s0:
                    self.retries += 1
                    continue
                f = unpack_from(b)
                if f[1] != 2:
                    return None
                return s0, f
        except (ValueError, IndexError, OSError):   # mapping closed or truncated under us
            self.close()
        return None


def _fin(v):
    return v if -1e9 < v < 1e9 else 0.0      # also turns NaN into 0


def _db(x, log10=math.log10):
    return 20.0 * log10(x) if x > 1e-6 else -120.0


# One event, as a format string: no dict, no json.dumps 15 times a second.
_EV_FMT = ('{"available":true,"running":true,"seq":%d,"playing":%d,"profile":"%s","model":%d,'
           '"in":[%.1f,%.1f],'
           '"db":[' + ",".join(["%.1f"] * 8) + '],'
           '"pk":[' + ",".join(["%.1f"] * 8) + '],'
           '"w":[' + ",".join(["%.3g"] * 8) + '],'
           '"drc":[%.1f,%.1f,%.1f,%.1f],"hp":%.1f,"x":[%.2f,%.2f],"xlim":%.2f,'
           '"p48":%.1f,"p12":%.1f,"pavg":%.1f,"budget":%.1f,"effort":%.3f,'
           '"pg":[%.3f,%.3f],"slow":%.3f,"lim":[%d,%d],"vol_db":%.1f,"muted":%d,'
           '"underruns":%d,"fifo_min":%d,"stall_us":%d,"eq":%d}')


def event_json(f):
    """meter2 fields (tuple from M2_FMT) -> one compact JSON object (str)."""
    (seq, _ver, playing, prof, in_rms, in_pk) = f[0:6]
    rms = f[6:14]
    pk = f[14:22]
    (h0, h1, h2, h3, hp, xa, xo, xl, p48, p12, pavg, bud, eff, pgw, pgt, slow) = [_fin(v) for v in f[22:38]]
    lim_w, lim_t = f[38], f[39]
    aref, muted = _fin(f[40]), _fin(f[41])
    und, fifo, stall = f[42], f[43], f[44]
    eq = _fin(f[45])
    r = [_fin(v) for v in rms]
    p = [_fin(v) for v in pk]
    pname = PROFILES[prof] if prof < 4 else "unknown"
    model = 1 if (prof == 3 and bud > 0) else 0
    return _EV_FMT % (
        seq, playing, pname, model,
        _db(_fin(in_rms)), _db(_fin(in_pk)),
        _db(r[0]), _db(r[1]), _db(r[2]), _db(r[3]), _db(r[4]), _db(r[5]), _db(r[6]), _db(r[7]),
        _db(p[0]), _db(p[1]), _db(p[2]), _db(p[3]), _db(p[4]), _db(p[5]), _db(p[6]), _db(p[7]),
        r[0] * r[0] * K_W, r[1] * r[1] * K_T, r[2] * r[2] * K_T, r[3] * r[3] * K_T,
        r[4] * r[4] * K_T, r[5] * r[5] * K_T, r[6] * r[6] * K_T, r[7] * r[7] * K_T,
        h0, h1, h2, h3, hp, xa, xo, xl,
        p48, p12, pavg, bud, eff,
        pgw, pgt, slow, lim_w, lim_t, aref, 1 if muted >= 0.5 else 0,
        und, fifo, stall, 1 if eq >= 0.5 else 0)


# ---------------------------------------------------------------- small file readers
def read_text(path, cap=8192):
    try:
        with open(path, "rb") as fh:
            return fh.read(cap).decode("utf-8", "replace")
    except OSError:
        return None


def read_kv(path, cap=8192):
    """key=value lines -> dict (comments and blank lines skipped, quotes stripped, last wins)."""
    t = read_text(path, cap)
    if t is None:
        return None
    d = {}
    for line in t.splitlines():
        line = line.strip()
        if not line or line[0] == "#" or "=" not in line:
            continue
        k, v = line.split("=", 1)
        k = k.strip()
        if not k or len(k) > 40 or not all(c.isalnum() or c == "_" for c in k):
            continue
        v = v.strip()
        if " #" in v:
            v = v.split(" #", 1)[0].rstrip()
        if len(v) >= 2 and v[0] == v[-1] and v[0] in "\"'":
            v = v[1:-1]
        d[k] = v[:200]
    return d


def read_json(path, cap=65536):
    t = read_text(path, cap)
    if t is None:
        return None
    try:
        v = json.loads(t)
        return v if isinstance(v, dict) else None
    except ValueError:
        return None


def num(s, default=None):
    try:
        v = float(s)
        return v if math.isfinite(v) else default
    except (TypeError, ValueError):
        return default


def onoff(s):
    return str(s).lower() in ("1", "yes", "on", "true")


def http_get_json(hostport, path, timeout=1.0):
    """Tiny HTTP/1.0 GET over a plain socket (no urllib: less to import, nothing to configure)."""
    host, _, port = hostport.rpartition(":")
    try:
        with socket.create_connection((host, int(port)), timeout=timeout) as s:
            s.settimeout(timeout)
            s.sendall(("GET %s HTTP/1.0\r\nHost: %s\r\n\r\n" % (path, host)).encode())
            data = b""
            deadline = time.monotonic() + timeout
            while len(data) < 262144 and time.monotonic() < deadline:
                c = s.recv(16384)
                if not c:
                    break
                data += c
        head, _, body = data.partition(b"\r\n\r\n")
        if not head.startswith(b"HTTP/1.") or b" 200 " not in head.split(b"\r\n", 1)[0] + b" ":
            return None
        v = json.loads(body.decode("utf-8", "replace"))
        return v if isinstance(v, dict) else None
    except (OSError, ValueError):
        return None


# ---------------------------------------------------------------- status and history
TEMP_KEYS = (("mcu", "temp_mcu"), ("psu", "temp_psu"), ("ntc1", "temp_ntc1"), ("ntc2", "temp_ntc2"))


class Status:
    """Runs in the worker thread only (except history_json, which takes the lock)."""

    def __init__(self):
        self.amp = None
        self.amp_t = -1e9
        self.doc = None
        self.doc_t = -1e9
        self.meter = MeterReader()
        self.hist = deque(maxlen=HIST_LEN)
        self.lock = threading.Lock()

    def amp_status(self, max_age=1.0):
        now = time.monotonic()
        if now - self.amp_t >= max_age:
            self.amp = http_get_json(AMP, "/status")
            self.amp_t = now
        return self.amp

    def sample_history(self):
        a = self.amp_status(max_age=0.5)
        tel = (a or {}).get("telemetry") or {}
        age = (a or {}).get("telemetry_age")
        fresh = isinstance(age, (int, float)) and age <= HIST_STEP + 2.0
        pt = [round(time.time(), 1)]
        for _, k in TEMP_KEYS:
            v = tel.get(k)
            pt.append(round(v / 10.0, 1) if fresh and isinstance(v, (int, float)) else None)
        with self.lock:
            self.hist.append(pt)

    def history_json(self):
        with self.lock:
            pts = list(self.hist)
        return json.dumps({"step": HIST_STEP, "names": [n for n, _ in TEMP_KEYS], "unit": "C",
                           "points": pts}, separators=(",", ":"))

    def build(self):
        now = time.monotonic()
        if self.doc is not None and now - self.doc_t < 1.0:
            return self.doc
        a = self.amp_status()
        dsp = read_kv(RUN + "/dsp.conf") or {}
        conf = read_kv(ETC + "/homepod-audio.conf") or {}
        glow = read_kv(RUN + "/glow.state")
        gconf = read_kv(ETC + "/homepod-glow.conf") or {}
        osr = read_kv(ETC + "/os-release") or {}
        upt = num((read_text("/proc/uptime") or "").split(" ")[0])
        name = (read_text(ETC + "/hostname") or read_text("/proc/sys/kernel/hostname") or "").strip()
        nowp = read_json(RUN + "/nowplaying.json")

        tel = (a or {}).get("telemetry") or {}
        temps = {}
        for n, k in TEMP_KEYS:
            v = tel.get(k)
            temps[n] = round(v / 10.0, 1) if isinstance(v, (int, float)) else None

        r = self.meter.read(now)
        health = None
        meter = {"available": r is not None}
        if r is not None:
            f = r[1]
            health = {"underruns": f[42], "fifo_min": f[43], "max_stall_us": f[44],
                      "control_effort": round(_fin(f[34]), 3),
                      # AirPlay timing (hpfeed -S): error against the group clock while it plays
                      # (+ = late), and how long a packet waits in the feeder to be on time
                      "airplay_sync_ms": round(_fin(f[46]), 2), "airplay_wait_ms": round(_fin(f[47]), 1)}
            meter["playing"] = bool(f[2])
            meter["profile"] = PROFILES[f[3]] if f[3] < 4 else "unknown"

        prof = dsp.get("profile") or conf.get("PROFILE") or None
        aref = num(dsp.get("aref"))
        doc = {
            "t": round(time.time(), 2),
            "system": {"name": name or None, "build": osr.get("VERSION_ID"),
                       "uptime": int(upt) if upt is not None else None},
            "volume": {"percent": num(conf.get("VOLUME_PCT")),
                       "db": aref if prof == "apple3" else num(dsp.get("volume_db")),
                       "muted": onoff(dsp.get("mute", "0"))},
            "sound": {"profile": prof, "dsp": dsp,
                      "settings": {k: v for k, v in conf.items() if k.isupper()}},
            "amp": {"reachable": a is not None,
                    "state": (a or {}).get("amp_state"),
                    "mcu": (a or {}).get("mcu_version"),
                    "playing": (a or {}).get("playing"),
                    "source": (a or {}).get("source"),
                    "temps_c": temps,
                    "telemetry_age": (a or {}).get("telemetry_age"),
                    "underruns": (a or {}).get("underruns"),
                    "uptime": (a or {}).get("uptime"),
                    "error": (a or {}).get("error")},
            "now": nowp,
            "lights": {"enabled": onoff(gconf.get("GLOW_ENABLED", "0")),
                       "brightness": num(gconf.get("GLOW_BRIGHTNESS")),
                       "palette": gconf.get("GLOW_PALETTE"),
                       "touch": not (gconf.get("TOUCH_ENABLED", "1").lower() in ("0", "no", "off", "false")),
                       "state": glow},
            "meter": meter,
            "health": health,
        }
        self.doc = json.dumps(doc, separators=(",", ":"))
        self.doc_t = time.monotonic()
        return self.doc


# ---------------------------------------------------------------- HTTP
CORS = b"Access-Control-Allow-Origin: *\r\n"
REASON = {200: "OK", 400: "Bad Request", 404: "Not Found", 405: "Method Not Allowed",
          431: "Request Header Fields Too Large", 503: "Service Unavailable"}


def response(code, body, ctype="application/json", extra=b""):
    if isinstance(body, str):
        body = body.encode()
    return (("HTTP/1.1 %d %s\r\nContent-Type: %s\r\nContent-Length: %d\r\nCache-Control: no-store\r\n"
             % (code, REASON[code], ctype, len(body))).encode()
            + CORS + extra + b"Connection: close\r\n\r\n" + body)


def err(code, text):
    return response(code, '{"ok":false,"error":"%s"}\n' % text, extra=b"Allow: GET\r\n" if code == 405 else b"")


SSE_HEAD = (b"HTTP/1.1 200 OK\r\nContent-Type: text/event-stream\r\nCache-Control: no-cache\r\n"
            + CORS + b"X-Accel-Buffering: no\r\nConnection: close\r\n\r\nretry: 10000\n\n")
EV_ABSENT = b'data: {"available":false}\n\n'
EV_STOPPED = b'data: {"available":true,"running":false}\n\n'
EV_KEEP = b": keep-alive\n\n"
TOKEN = frozenset(b"ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789!#$%&'*+-.^_`|~")


def parse_request(buf):
    """-> ('ok', path) | ('error', response bytes). buf holds everything up to the blank line."""
    line = buf.split(b"\n", 1)[0].rstrip(b"\r")
    parts = line.split(b" ")
    if len(parts) != 3 or not parts[0] or not set(parts[0]) <= TOKEN:
        return "error", err(400, "bad request")
    method, target, ver = parts
    if ver not in (b"HTTP/1.0", b"HTTP/1.1"):
        return "error", err(400, "bad request")
    if method != b"GET":
        return "error", err(405, "only GET")
    if not target.startswith(b"/"):
        return "error", err(400, "bad request")
    path = target.split(b"?", 1)[0].split(b"#", 1)[0]     # a query string is not interpreted
    if path not in (b"/api/meters", b"/api/status", b"/api/history"):
        return "error", err(404, "not found")
    return "ok", path


class Conn:
    __slots__ = ("sock", "fd", "kind", "rbuf", "deadline", "out", "stuck_since", "last_sent", "dropped", "said")

    def __init__(self, sock, now):
        self.sock = sock
        self.fd = sock.fileno()
        self.kind = "req"          # req -> sse | resp
        self.rbuf = b""
        self.deadline = now + REQ_TIME
        self.out = b""
        self.stuck_since = None
        self.last_sent = now
        self.dropped = 0
        self.said = None           # last state message sent (absent / stopped / None = live)


class Server:
    def __init__(self, port=PORT, bind=BIND):
        self.sel = selectors.DefaultSelector()
        self.lsock = self._listen(bind, port)
        self.port = self.lsock.getsockname()[1]
        self.sel.register(self.lsock, selectors.EVENT_READ, None)
        self.conns = {}
        self.sse = []
        self.meter = MeterReader()
        self.status = Status()
        self.jobs = queue.Queue(maxsize=4)
        self.period = 1.0 / RATE
        self.next_tick = 0.0
        self.last_seq = None
        self.seq_t = 0.0
        self.mstate = "unknown"     # live | stopped | absent
        self.frame = None
        self.stop = False
        self.worker = threading.Thread(target=self._worker, name="statd-worker", daemon=True)

    # ----- setup
    @staticmethod
    def _listen(bind, port):
        s = None
        if bind in ("", "::") and socket.has_ipv6:
            try:
                s = socket.socket(socket.AF_INET6, socket.SOCK_STREAM)
                try:
                    s.setsockopt(socket.IPPROTO_IPV6, socket.IPV6_V6ONLY, 0)
                except (OSError, AttributeError):
                    pass
                s.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
                s.bind(("::", port))
            except OSError:
                if s:
                    s.close()
                s = None
        if s is None:
            s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
            s.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
            s.bind((bind if bind not in ("", "::") else "0.0.0.0", port))
        s.listen(16)
        s.setblocking(False)
        return s

    def write_state(self):
        try:
            tmp = STATE + ".tmp"
            with open(tmp, "w") as fh:
                fh.write("state=running\nport=%d\nclients=%d\nmeter=%s\n"
                         % (self.port, len(self.sse), self.mstate if self.sse else "idle"))
            os.replace(tmp, STATE)
        except OSError:
            pass

    # ----- worker thread: /api/status and the 10 s temperature samples
    def _worker(self):
        nxt = time.monotonic()
        while not self.stop:
            now = time.monotonic()
            if now >= nxt:
                try:
                    self.status.sample_history()
                except Exception as e:      # never die over a bad answer
                    log("history: %r" % e)
                nxt += HIST_STEP
                if nxt < now:
                    nxt = now + HIST_STEP
                continue
            try:
                sock = self.jobs.get(timeout=nxt - now)
            except queue.Empty:
                continue
            if sock is None:
                break
            try:
                try:
                    data = response(200, self.status.build())
                except Exception as e:
                    log("status: %r" % e)
                    data = response(503, '{"ok":false,"error":"status unavailable"}\n')
                sock.setblocking(True)
                sock.settimeout(3.0)
                sock.sendall(data)
            except OSError:
                pass
            finally:
                try:
                    sock.close()
                except OSError:
                    pass

    # ----- connections
    def close(self, c):
        try:
            self.sel.unregister(c.sock)
        except (KeyError, ValueError):
            pass
        try:
            c.sock.close()
        except OSError:
            pass
        if self.conns.get(c.fd) is c:
            del self.conns[c.fd]
        if c in self.sse:
            self.sse.remove(c)
            self.write_state()

    def accept(self, now):
        for _ in range(16):
            try:
                s, _ = self.lsock.accept()
            except (BlockingIOError, InterruptedError):
                return
            except OSError:
                return
            s.setblocking(False)
            if len(self.conns) >= MAX_CONN:
                try:
                    s.send(err(503, "busy"))
                except OSError:
                    pass
                s.close()
                continue
            c = Conn(s, now)
            self.conns[c.fd] = c
            self.sel.register(s, selectors.EVENT_READ, c)

    def readable(self, c, now):
        try:
            d = c.sock.recv(4096)
        except (BlockingIOError, InterruptedError):
            return
        except OSError:
            self.close(c)
            return
        if not d:
            self.close(c)
            return
        if c.kind != "req":
            return                        # a stream client has nothing to say; ignore it
        c.rbuf += d
        end = c.rbuf.find(b"\r\n\r\n")
        if end < 0:
            end = c.rbuf.find(b"\n\n")
        if end < 0:
            if len(c.rbuf) > REQ_MAX:
                self.reply(c, err(431, "request too large"), now)
            return
        if end > REQ_MAX:
            self.reply(c, err(431, "request too large"), now)
            return
        kind, v = parse_request(c.rbuf[:end])
        c.rbuf = b""
        if kind == "error":
            self.reply(c, v, now)
        elif v == b"/api/meters":
            self.start_sse(c, now)
        elif v == b"/api/history":
            self.reply(c, response(200, self.status.history_json()), now)
        else:
            self.sel.unregister(c.sock)
            del self.conns[c.fd]
            try:
                self.jobs.put_nowait(c.sock)
            except queue.Full:
                try:
                    c.sock.send(err(503, "busy"))
                except OSError:
                    pass
                c.sock.close()

    def reply(self, c, data, now):
        c.kind = "resp"
        c.deadline = now + RESP_TIME
        c.out = data
        self.flush(c)
        if c.out:
            try:
                self.sel.modify(c.sock, selectors.EVENT_WRITE, c)
            except (KeyError, ValueError):
                pass
        else:
            self.close(c)

    def flush(self, c):
        """Send what is pending. True if all of it went."""
        try:
            n = c.sock.send(c.out)
        except (BlockingIOError, InterruptedError):
            return False
        except OSError:
            c.out = b""
            self.close(c)
            return False
        c.out = c.out[n:]
        return not c.out

    def start_sse(self, c, now):
        if len(self.sse) >= MAX_SSE:
            self.reply(c, err(503, "too many meter clients"), now)
            return
        c.kind = "sse"
        c.deadline = None
        try:
            c.sock.setsockopt(socket.SOL_SOCKET, socket.SO_SNDBUF, SSE_SNDBUF)
        except OSError:
            pass
        c.out = SSE_HEAD
        c.last_sent = now
        c.said = None
        if not self.sse:
            self.next_tick = now        # first client: start the clock now
            self.last_seq = None
            self.frame = None
            self.mstate = "unknown"
        self.sse.append(c)
        self.flush(c)
        self.write_state()

    def send_sse(self, c, data, now):
        """Queue one event for a stream client; drop it if the client is behind."""
        if c.out:
            if not self.flush(c):
                c.dropped += 1
                if c.stuck_since is None:
                    c.stuck_since = now
                elif now - c.stuck_since > STALL_CLOSE:
                    self.close(c)
                return
        c.stuck_since = None
        c.out = data
        if self.flush(c) or c.out:
            c.last_sent = now

    # ----- the meter clock (runs only while someone listens)
    def tick(self, now):
        r = self.meter.read(now)
        if r is None:
            st = "absent"
        else:
            seq, f = r
            if self.last_seq is None:          # first look: wait for it to move before trusting it
                self.last_seq, self.seq_t, st = seq, now, "pending"
            elif seq != self.last_seq:
                self.last_seq, self.seq_t, st = seq, now, "new"
                self.frame = ("data: " + event_json(f) + "\n\n").encode()
            elif now - self.seq_t > STALE:
                st = "stopped"
            else:
                st = "same"
        m = {"absent": "absent", "stopped": "stopped", "new": "live"}.get(st, self.mstate)
        if m != self.mstate:
            self.mstate = m
            self.write_state()
        for c in list(self.sse):
            if st == "new":
                self.send_sse(c, self.frame, now)
                c.said = None
            elif st in ("absent", "stopped") and c.said != st:
                self.send_sse(c, EV_ABSENT if st == "absent" else EV_STOPPED, now)
                c.said = st
            elif now - c.last_sent >= KEEPALIVE:
                self.send_sse(c, EV_KEEP, now)
            elif c.out:
                self.flush(c)

    # ----- main loop
    def run(self):
        self.worker.start()
        self.write_state()
        log("listening on port %d (meters from %s)" % (self.port, METER2))
        while not self.stop:
            now = time.monotonic()
            timeout = None
            if self.sse:
                if now >= self.next_tick:
                    self.tick(now)
                    self.next_tick += self.period
                    if self.next_tick < now:          # we were late: do not try to catch up
                        self.next_tick = now + self.period
                timeout = max(0.0, self.next_tick - now)
            for c in list(self.conns.values()):
                if c.deadline is not None:
                    if now >= c.deadline:
                        self.close(c)
                    else:
                        t = c.deadline - now
                        timeout = t if timeout is None or t < timeout else timeout
            try:
                events = self.sel.select(timeout)
            except InterruptedError:
                continue
            now = time.monotonic()
            for key, mask in events:
                c = key.data
                if c is None:
                    self.accept(now)
                elif mask & selectors.EVENT_WRITE and c.kind == "resp":
                    if self.flush(c):
                        self.close(c)
                elif mask & selectors.EVENT_READ:
                    self.readable(c, now)
        self.shutdown()

    def shutdown(self):
        self.stop = True
        for c in list(self.conns.values()):
            self.close(c)
        try:
            self.jobs.put_nowait(None)
        except queue.Full:
            pass
        self.lsock.close()
        self.meter.close()
        try:
            with open(STATE, "w") as fh:
                fh.write("state=stopped\n")
        except OSError:
            pass


def log(msg):
    sys.stdout.write("%s statd: %s\n" % (time.strftime("%Y-%m-%d %H:%M:%S"), msg))
    sys.stdout.flush()


def main():
    srv = Server()

    def on_term(*_):
        srv.stop = True
        raise SystemExit(0)

    signal.signal(signal.SIGTERM, on_term)
    signal.signal(signal.SIGINT, on_term)
    signal.signal(signal.SIGPIPE, signal.SIG_IGN) if hasattr(signal, "SIGPIPE") else None
    try:
        srv.run()
    except SystemExit:
        srv.shutdown()
        log("stopped")


if __name__ == "__main__":
    main()
