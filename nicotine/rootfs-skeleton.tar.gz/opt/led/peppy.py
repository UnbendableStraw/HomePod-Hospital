#!/usr/bin/python3
"""peppy.py - talk to the HomePod (1st gen) top-board MCU ("Peppy") from Linux.

Protocol reverse-engineered from Apple's ApplePeppyDriver.kext (audioOS 18.3)
and cross-checked against the MCU firmware B238_PeppyMA_App.bin. NOTHING here
has been run on hardware yet; see FINDINGS.md for what is established and
what is a guess.

Wiring: I2C3 (SoC 0x20A113000), 7-bit address 0x55. No register addresses:
every transfer is one whole frame.

  host -> MCU   [cmd][len][seq][0][data * len][cksum]        (len <= 0x80)
  MCU  -> host  [cmd|0x80][len][seq][status][data * len][cksum]
  cksum makes the 8-bit sum of the whole frame zero. seq is 1..255 on
  commands that expect an answer and 0 on those that do not. status 0 = ok.
  When the answer length is not known, read 5 bytes, then `len` more.

Commands used by Apple's driver:
  0x01 version info (5 bytes back; byte 2 is believed to be the hardware version)
  0x11 LEDs. hw version 4/5: [icon0 BE16][icon1 BE16] and, for a full frame,
       57 more BE16 values = 19 LEDs x (R, G, B), 16-bit PWM. No answer.
  0x15 mode byte, bit0 = touch scanning, bit1 = "AutoLED". 1 byte each way.
  0x20 GPIO control (3 bytes: set, reset, button edges; 1 back)
  0x23 serial number (17 bytes back)      0x28 temperatures (4 bytes back)
  0x2c/0x2d out-of-box flag               0x38/0x39 "CLCG" data (16 bytes)
  0x40 HID report descriptor, 0x41 get report, 0x42 set report,
  0x43 get input report (touch/buttons; Apple reads it when the MCU interrupts)
  0x70..0x72 firmware update. NEVER send these.

Probe order on the pod (1-4 only read; 5+ change what the MCU shows or does,
do them with the user watching):
  1 bus             expect an adapter whose of_node ends in i2c@20a113000
  2 version         5 bytes back = MCU alive and framing right; byte 2 >= 4 means
                    the 118-byte matrix frame applies. I/O errors on every retry =
                    asleep, in reset or in its bootloader: stop, do not touch the
                    reset line (PMIC 0x0426) or boot strap (SoC GPIO 45) yet
  3 serial, temps   two more answer lengths, temperature baseline
  4 hid-descriptor  tests the two-part read; gives the touch report layout
  5 pixel 18 40 40 40   centre LED faintly white
  6 chase, then fill 255 0 0 / 0 255 0 / 0 0 255   LED order and colour order
  7 mode byte (command 0x15), only if frames do not show or get overwritten:
    bit1 "AutoLED" may need clearing. Not implemented here on purpose.
Unknown until probed: hardware version, frame order vs coordinate order, whether
the MCU runs after our boot, what AutoLED does, safe continuous brightness
(MAX_LEVEL below is our own cap), I2C bus speed.

Usage:
  peppy.py bus                 show which /dev/i2c-N is I2C3
  peppy.py version             command 0x01 (read-only)
  peppy.py serial | temps | hid-descriptor | input      (read-only)
  peppy.py mode                read the mode byte WITHOUT changing it is not
                               possible; this prints what `mode N` would send
  peppy.py off                 all LEDs off
  peppy.py fill R G B [LEVEL]  all 19 LEDs one colour (0-255 each, LEVEL 0..1, default 0.1)
  peppy.py pixel N R G B       one LED
  peppy.py chase               walk one dim LED through 0..18 (to learn the order)
  peppy.py meter               level meter on the outer ring (needs /run/homepod/meter)
  peppy.py glow                Sound-Glow-like colour blobs that pulse with the music
"""
import fcntl, json, math, mmap, os, struct, sys, time

ADDR = 0x55
I2C_SLAVE, I2C_SLAVE_FORCE = 0x0703, 0x0706
I2C3_OF = "i2c@20a113000"
NLED = 19
MAX_LEVEL = 0.5          # our own ceiling on global brightness until thermals are known
METER = "/run/homepod/meter"

# LED positions from Apple's device tree (MDXCoords / MDYCoords / MDRingCoords), as
# offsets from the centre in units of the outer radius. Index = position in the frame
# [GUESS: that the frame order equals the device-tree order; `chase` verifies it].
_X = [0xc7e7, 0xe238, 0xe238, 0xc7e7, 0x9a51, 0x65af, 0x3819, 0x1dc8, 0x1dc8, 0x3819, 0x65af, 0x9a51,
      0x9a51, 0xb4a2, 0x9a51, 0x65af, 0x4b5d, 0x65af, 0x8000]
_Y = [0xc7e7, 0x9a51, 0x65af, 0x3819, 0x1dc8, 0x1dc8, 0x3819, 0x65af, 0x9a51, 0xc7e7, 0xe238, 0xe238,
      0xad95, 0x8000, 0x526b, 0x526b, 0x8000, 0xad95, 0x8000]
RING = [2] * 12 + [1] * 6 + [0]
_R = math.hypot(_X[0] - 0x8000, _Y[0] - 0x8000)
POS = [((x - 0x8000) / _R, (y - 0x8000) / _R) for x, y in zip(_X, _Y)]


def find_bus():
    base = "/sys/bus/i2c/devices"
    for d in sorted(os.listdir(base)):
        if not d.startswith("i2c-"):
            continue
        try:
            of = os.path.realpath(os.path.join(base, d, "of_node"))
        except OSError:
            continue
        if of.endswith(I2C3_OF):
            return int(d[4:])
    return None


class Peppy:
    def __init__(self, bus=None):
        if bus is None:
            bus = find_bus()
        if bus is None:
            raise SystemExit("I2C3 (%s) not found under /sys/bus/i2c/devices" % I2C3_OF)
        self.fd = os.open("/dev/i2c-%d" % bus, os.O_RDWR)
        try:
            fcntl.ioctl(self.fd, I2C_SLAVE, ADDR)
        except OSError:
            fcntl.ioctl(self.fd, I2C_SLAVE_FORCE, ADDR)
        self.seq = 1
        self.gamma = None

    # ---- framing -------------------------------------------------------
    @staticmethod
    def _ck(b):
        return (-sum(b)) & 0xFF

    def _send(self, cmd, data=b"", reply=False):
        assert cmd < 0x70, "firmware-update commands are refused"
        assert len(data) <= 0x80
        f = bytes([cmd, len(data), self.seq if reply else 0, 0]) + bytes(data)
        f += bytes([self._ck(f)])
        last = None
        for n in range(12):                      # Apple retries 12 times with a growing pause
            try:
                os.write(self.fd, f)
                return
            except OSError as e:
                last = e
                time.sleep(16e-6 * (1 << n))
        raise last

    def _recv(self, cmd, n=None):
        last = "no answer"
        for attempt in range(12):
            if attempt:
                time.sleep(16e-6 * (1 << attempt))
            try:
                if n is None:
                    r = os.read(self.fd, 5)
                    if len(r) == 5 and r[1]:
                        r += os.read(self.fd, r[1])
                else:
                    r = os.read(self.fd, n + 5)
            except OSError as e:
                last = str(e)
                continue
            if len(r) < 5 or sum(r) & 0xFF:
                last = "bad checksum: " + r.hex()
                continue
            if r[0] != (cmd | 0x80) or r[2] != self.seq:
                last = "not our answer: " + r.hex()
                continue
            if r[3]:
                raise IOError("MCU status 0x%02x for command 0x%02x" % (r[3], cmd))
            return r[4:4 + r[1]]
        raise IOError("command 0x%02x: %s" % (cmd, last))

    def command(self, cmd, data=b"", rlen=None, reply=True):
        self._send(cmd, data, reply)
        if not reply:
            return b""
        try:
            return self._recv(cmd, rlen)
        finally:
            self.seq = self.seq + 1 if self.seq < 255 else 1

    # ---- read-only queries ---------------------------------------------
    def version(self):
        return self.command(0x01, rlen=5)

    def serial(self):
        return self.command(0x23, rlen=0x11)

    def temps(self):
        return self.command(0x28, rlen=4)

    def hid_descriptor(self):
        return self.command(0x40)

    def input_report(self):
        return self.command(0x43)

    # ---- LEDs ----------------------------------------------------------
    def load_gamma(self, path=None):
        """Apple's per-colour table (225 steps, full-brightness column), linear light -> PWM."""
        path = path or os.path.join(os.path.dirname(os.path.abspath(__file__)), "peppy_gamma_lut.json")
        try:
            j = json.load(open(path))
            self.gamma = [[row[6] for row in j["lut"][c]] for c in "RGB"]
        except (OSError, KeyError, ValueError):
            self.gamma = None

    def _pwm(self, v, ch):
        v = 0.0 if v < 0 else 1.0 if v > 1 else v
        if self.gamma:
            x = v * 224.0
            i = int(x)
            t = self.gamma[ch]
            return int(t[i] + (t[min(i + 1, 224)] - t[i]) * (x - i))
        return int(65535 * v ** 2.6)

    def frame(self, rgb, level=1.0, icons=(0.0, 0.0)):
        """rgb: 19 (r, g, b) tuples, 0..1 linear. level: global brightness 0..1 (capped)."""
        level = max(0.0, min(level, MAX_LEVEL))
        out = bytearray()
        for v in icons:
            out += struct.pack(">H", int(65535 * max(0.0, min(v, 1.0)) * level))
        for i in range(NLED):
            for ch in range(3):
                out += struct.pack(">H", int(self._pwm(rgb[i][ch], ch) * level))
        assert len(out) == 0x76
        self.command(0x11, bytes(out), reply=False)

    def off(self):
        self.frame([(0, 0, 0)] * NLED, 0.0)


# ---- audio level from hpfeed (proposed interface, see FINDINGS.md) -------
class Meter:
    """/run/homepod/meter: 32 bytes, little endian, rewritten ~30 times a second:
       u32 seq (odd while being written), u32 playing, f32 rms, peak, low, mid, high, spare."""
    def __init__(self):
        self.m = None
        try:
            fd = os.open(METER, os.O_RDONLY)
            self.m = mmap.mmap(fd, 32, mmap.MAP_SHARED, mmap.PROT_READ)
            os.close(fd)
        except (OSError, ValueError):
            pass

    def read(self):
        if not self.m:
            t = time.time()                       # no hpfeed meter: a slow fake pulse
            v = 0.35 + 0.3 * math.sin(t * 2.1) * math.sin(t * 0.7)
            return {"playing": 1, "rms": v, "peak": v, "low": v, "mid": v * 0.8, "high": v * 0.5}
        for _ in range(4):
            a = self.m[:32]
            s = struct.unpack_from("<I", a)[0]
            if not s & 1 and a == self.m[:32]:
                _, playing, rms, peak, low, mid, high, _ = struct.unpack("<II6f", a)
                return {"playing": playing, "rms": rms, "peak": peak, "low": low, "mid": mid, "high": high}
        return {"playing": 0, "rms": 0, "peak": 0, "low": 0, "mid": 0, "high": 0}


def db_norm(x, floor=-50.0):
    """linear 0..1 amplitude -> 0..1 on a dB scale"""
    if x <= 0:
        return 0.0
    return max(0.0, min(1.0, 1.0 - 20.0 * math.log10(x) / floor))


# ---- demos ---------------------------------------------------------------
def chase(p):
    for i in range(NLED):
        rgb = [(0, 0, 0)] * NLED
        rgb[i] = (1, 1, 1)
        p.frame(rgb, 0.08)
        print("LED %2d  ring %d  x %+.2f  y %+.2f" % (i, RING[i], POS[i][0], POS[i][1]), flush=True)
        time.sleep(0.7)
    p.off()


def meter(p, fps=30):
    m = Meter()
    lvl = 0.0
    while True:
        s = m.read()
        target = db_norm(s["rms"])
        lvl += (target - lvl) * (0.5 if target > lvl else 0.12)
        lit = lvl * 12
        rgb = []
        for i in range(NLED):
            if RING[i] == 2:
                k = max(0.0, min(1.0, lit - i))
                rgb.append((k * (i / 11.0), k * (1 - i / 11.0), 0.05 * k))
            elif RING[i] == 1:
                rgb.append((0, 0, 0.3 * db_norm(s["low"])))
            else:
                rgb.append((db_norm(s["peak"]),) * 3)
        p.frame(rgb, 0.25)
        time.sleep(1.0 / fps)


def glow(p, palette=((1.0, 0.25, 0.1), (0.1, 0.35, 1.0), (0.7, 0.1, 0.9)), fps=30):
    """Two or three soft colour blobs drifting over the surface, swelling with the music.
       palette: later taken from the album artwork (see FINDINGS.md)."""
    m = Meter()
    env = beat = 0.0
    t0 = time.time()
    while True:
        s = m.read()
        low = db_norm(s["low"])
        beat = max(low, beat * 0.86)                    # fast attack, slow release
        env += (db_norm(s["rms"]) - env) * 0.08
        t = time.time() - t0
        rgb = []
        blobs = []
        for k, col in enumerate(palette):
            a = t * (0.35 + 0.11 * k) * (1 + 0.5 * env) + k * 2.094
            r = 0.45 + 0.25 * math.sin(t * 0.23 + k)
            blobs.append((r * math.cos(a), r * math.sin(a), col, 0.55 + 0.35 * beat))
        for i in range(NLED):
            x, y = POS[i]
            acc = [0.0, 0.0, 0.0]
            for bx, by, col, size in blobs:
                w = math.exp(-((x - bx) ** 2 + (y - by) ** 2) / (2 * size * size * 0.35))
                for c in range(3):
                    acc[c] += col[c] * w
            rgb.append(tuple(min(1.0, v) for v in acc))
        p.frame(rgb, (0.06 + 0.3 * env + 0.12 * beat) if s["playing"] else 0.0)
        time.sleep(1.0 / fps)


def main(a):
    if not a or a[0] in ("-h", "--help"):
        print(__doc__)
        return 0
    if a[0] == "bus":
        print(find_bus())
        return 0
    p = Peppy()
    p.load_gamma()
    c = a[0]
    try:
        if c == "version":
            v = p.version()
            print("version info:", v.hex(), "(hardware version believed to be byte 2 = %d)" % v[2])
        elif c == "serial":
            print(p.serial().hex())
        elif c == "temps":
            print(p.temps().hex())
        elif c == "hid-descriptor":
            print(p.hid_descriptor().hex())
        elif c == "input":
            print(p.input_report().hex())
        elif c == "mode":
            print("would send command 0x15 with one byte: bit0 touch scan, bit1 AutoLED (not sent)")
        elif c == "off":
            p.off()
        elif c == "fill":
            r, g, b = (int(x) / 255.0 for x in a[1:4])
            p.frame([(r, g, b)] * NLED, float(a[4]) if len(a) > 4 else 0.1)
        elif c == "pixel":
            rgb = [(0, 0, 0)] * NLED
            rgb[int(a[1])] = tuple(int(x) / 255.0 for x in a[2:5])
            p.frame(rgb, 0.1)
        elif c == "chase":
            chase(p)
        elif c == "meter":
            meter(p)
        elif c == "glow":
            glow(p)
        else:
            print(__doc__)
            return 2
    except KeyboardInterrupt:
        p.off()
    return 0


if __name__ == "__main__":
    sys.exit(main(sys.argv[1:]))
