/*
 * meter2.h - layout of /run/homepod/meter2, written by hpfeed, read by the status daemon.
 *
 * 216 bytes, little endian, every field 4 bytes. Rewritten 15 times a second (every 3200
 * output frames) while the feeder runs, also when idle (levels are then 0).
 *
 * Lock-free, same as /run/homepod/meter: the file is mmap'ed by the writer; `seq` is odd while
 * the writer is updating the block. A reader copies the 216 bytes, and accepts the copy only if
 * seq was even and unchanged before and after the copy (otherwise it tries again).
 *
 * python:  struct.unpack('<4I2f8f8f4f12f2I2f3If8f', buf)
 *
 * Levels are linear, 1.0 = digital full scale. Drivers: [0] woofer, [1..7] tweeters in TDM slot
 * order (slot 4 = front, slots 1 and 7 = the two at the back, next to the power cord).
 * Volts at full scale: woofer 39 V, tweeters 12.6 V; tweeters about 3.2 ohm.
 * For profiles other than apple3 the protection fields (drc_db .. lim_t) are 0.
 */
#ifndef METER2_H
#define METER2_H

#include <stdint.h>
#include <stddef.h>

#define METER2_FILE    "/run/homepod/meter2"
#define METER2_VERSION 2
#define METER2_PERIOD  3200             /* output frames per update: 48000 / 15 */

struct meter2 {
	uint32_t seq;                   /*   0  odd while being written */
	uint32_t version;               /*   4  2 */
	uint32_t playing;               /*   8  0/1, a source is playing */
	uint32_t profile;               /*  12  0 flat, 1 apple, 2 apple2, 3 apple3 */
	float in_rms;                   /*  16  mono mix in front of the DSP (after mute and channels), over the period */
	float in_peak;                  /*  20 */
	float drv_rms[8];               /*  24  per driver at the DAC, over the period */
	float drv_peak[8];              /*  56  per driver, peak over the period (at most the hard ceiling) */
	float drc_db[4];                /*  88  compressor gain per band, dB (<= 0) */
	float hp_hz;                    /* 104  sliding high-pass position (30 = full bass extension) */
	float x_ask_mm;                 /* 108  woofer excursion the music asked for, peak over the period */
	float x_out_mm;                 /* 112  excursion after the limiter, peak over the period */
	float xlim_mm;                  /* 116  the excursion limit in force */
	float p48_w;                    /* 120  48 V supply power, 64 ms window, peak over the period */
	float p12_w;                    /* 124  12 V rail power, 64 ms window, peak over the period */
	float pavg_w;                   /* 128  10 s average supply power */
	float budget_w;                 /* 132  long-term budget (40) */
	float effort;                   /* 136  control effort 0..1 (0 = no back-off) */
	float pg_w;                     /* 140  power-limiter gain, woofer (1 = idle) */
	float pg_t;                     /* 144  power-limiter gain, tweeters */
	float slow;                     /* 148  slowest peak-limiter gain (1 = idle) */
	uint32_t lim_w;                 /* 152  woofer peak-limiter hits (samples) in the period */
	uint32_t lim_t;                 /* 156  tweeter peak-limiter hits, all seven summed, in the period */
	float aref_db;                  /* 160  input gain = the volume in dB (-90 = mute); other profiles: volume_db */
	float muted;                    /* 164  0/1 */
	uint32_t underruns;             /* 168  since start */
	uint32_t fifo_min;              /* 172  lowest hardware FIFO level in the period, frames (words / 8; full = 14) */
	uint32_t max_stall_us;          /* 176  longest gap between two polls of the FIFO in the period */
	float eq_on;                    /* 180  0/1, the user EQ is in the signal path */
	float sync_err_ms;              /* 184  sync source (AirPlay): timing error, ms (+ = late); 0 when idle */
	float sync_wait_ms;             /* 188  ...and the time a packet waits in the ring to be on time, ms */
	float reserved[6];              /* 192  zero */
};

_Static_assert(sizeof(struct meter2) == 216, "meter2 must be 216 bytes");
_Static_assert(offsetof(struct meter2, drv_rms) == 24, "meter2 layout");
_Static_assert(offsetof(struct meter2, drc_db) == 88, "meter2 layout");
_Static_assert(offsetof(struct meter2, lim_w) == 152, "meter2 layout");
_Static_assert(offsetof(struct meter2, underruns) == 168, "meter2 layout");
_Static_assert(offsetof(struct meter2, eq_on) == 180, "meter2 layout");

#endif
