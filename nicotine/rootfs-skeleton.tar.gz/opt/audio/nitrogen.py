#!/usr/bin/env python3
"""
nitrogen.py - Communication with the Nitrogen (STM32L051) MCU on HomePod.

The MCU sits between the A8 SoC and all audio amplifiers/DACs.
It speaks ASCII commands over UART8 at 460800 baud, 8N1.

Protocol:
  Send: [CMD,args...]   (brackets included, newline terminated)
  Recv: <cmd,data...>   (angle brackets, newline terminated)

This script provides:
  1. /dev/ttyS* based communication (if UART8 is exposed by kernel)
  2. MMIO-based UART access via /dev/mem (if UART8 is disabled in DTS)
  3. Interactive command mode
  4. Automated probe/status dump

Usage:
  nitrogen.py probe       - Auto-detect UART and query MCU identity
  nitrogen.py status      - Get temperature, telemetry, version
  nitrogen.py cmd [CMD]   - Send a raw command (e.g., nitrogen.py cmd "[SV]")
  nitrogen.py interactive - Interactive command shell
  nitrogen.py mmio-init   - Initialize UART8 via MMIO and probe
"""

import os
import sys
import time
import struct
import select
import termios
import fcntl

# Add script directory to path for mmio import
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

# ============================================================
# Apple A8 UART8 hardware definitions
# ============================================================

UART8_BASE = 0x20a0e0000  # Physical address of UART8

# Samsung/Apple UART register offsets
ULCON    = 0x000  # Line control
UCON     = 0x004  # Control
UFCON    = 0x008  # FIFO control
UMCON    = 0x00C  # Modem control
UTRSTAT  = 0x010  # TX/RX status
UERSTAT  = 0x014  # Error status
UFSTAT   = 0x018  # FIFO status
UMSTAT   = 0x01C  # Modem status
UTXH     = 0x020  # TX holding register
URXH     = 0x024  # RX holding register
UBRDIV   = 0x028  # Baud rate divisor (integer)
UFRACVAL = 0x02C  # Baud rate fractional value

# ULCON bits
ULCON_8N1     = 0x03  # 8-bit word, no parity, 1 stop bit

# UCON bits
UCON_RX_INT   = (1 << 0)   # RX interrupt/polling mode
UCON_TX_INT   = (1 << 2)   # TX interrupt/polling mode
UCON_RX_POLL  = (1 << 0)   # RX polling mode
UCON_TX_POLL  = (1 << 2)   # TX polling mode

# UFCON bits
UFCON_FIFO_EN = (1 << 0)   # FIFO enable
UFCON_RX_RST  = (1 << 1)   # RX FIFO reset
UFCON_TX_RST  = (1 << 2)   # TX FIFO reset

# UTRSTAT bits
UTRSTAT_RX_READY = (1 << 0)  # RX buffer has data
UTRSTAT_TX_EMPTY = (1 << 1)  # TX buffer empty
UTRSTAT_TX_DONE  = (1 << 2)  # Transmitter empty (shifted out)

# UFSTAT bits
UFSTAT_RX_COUNT_MASK = 0xFF        # RX FIFO count (bits 0-7)
UFSTAT_RX_FULL       = (1 << 8)    # RX FIFO full
UFSTAT_TX_COUNT_MASK = (0xFF << 16)  # TX FIFO count (bits 16-23)
UFSTAT_TX_FULL       = (1 << 24)   # TX FIFO full

# Baud rate settings for various source clocks
# Format: {clock_hz: (ubrdiv, ufracval)} for 460800 baud
BAUD_CONFIGS = {
    24000000:  (2, 4),    # 24MHz crystal
    48000000:  (5, 8),    # 48MHz
    96000000:  (12, 0),   # 96MHz
    192000000: (25, 1),   # 192MHz
}

TARGET_BAUD = 460800


class NitrogenMMIO:
    """Talk to Nitrogen MCU via direct UART8 MMIO access."""

    def __init__(self, base=UART8_BASE, clock_hz=24000000):
        import mmio
        self.mmio = mmio
        self.base = base
        self.clock_hz = clock_hz
        self._initialized = False

    def _reg(self, offset):
        return self.base + offset

    def init_uart(self):
        """Initialize UART8 for 460800 baud 8N1."""
        print(f"[MMIO] Initializing UART8 at 0x{self.base:09x}")
        print(f"[MMIO] Assuming source clock: {self.clock_hz/1e6:.1f} MHz")

        # Read current state
        ulcon = self.mmio.read32(self._reg(ULCON))
        ucon = self.mmio.read32(self._reg(UCON))
        print(f"[MMIO] Current ULCON=0x{ulcon:08x} UCON=0x{ucon:08x}")

        # Check if UART appears mapped (read a known register)
        test = self.mmio.read32(self._reg(UTRSTAT))
        print(f"[MMIO] UTRSTAT=0x{test:08x}")
        if test == 0xFFFFFFFF or test == 0xDEADBEEF:
            print("[MMIO] WARNING: UART8 may not be clocked/powered!")
            print("[MMIO] Reads return 0xFFFFFFFF - clock gate may be off")
            return False

        # Configure line control: 8N1
        self.mmio.write32(self._reg(ULCON), ULCON_8N1)

        # Reset and enable FIFOs
        self.mmio.write32(self._reg(UFCON),
                          UFCON_FIFO_EN | UFCON_RX_RST | UFCON_TX_RST)
        time.sleep(0.01)
        self.mmio.write32(self._reg(UFCON), UFCON_FIFO_EN)

        # Set baud rate
        if self.clock_hz in BAUD_CONFIGS:
            ubrdiv, ufrac = BAUD_CONFIGS[self.clock_hz]
        else:
            # Calculate from clock
            divisor = self.clock_hz / (16.0 * TARGET_BAUD)
            ubrdiv = int(divisor) - 1
            ufrac = round((divisor - int(divisor)) * 16)
        print(f"[MMIO] Baud config: UBRDIV={ubrdiv}, UFRACVAL={ufrac}")
        self.mmio.write32(self._reg(UBRDIV), ubrdiv)
        self.mmio.write32(self._reg(UFRACVAL), ufrac)

        # Enable TX and RX in polling mode
        self.mmio.write32(self._reg(UCON), UCON_RX_POLL | UCON_TX_POLL)

        # Clear modem control
        self.mmio.write32(self._reg(UMCON), 0)

        # Verify
        ulcon = self.mmio.read32(self._reg(ULCON))
        ucon = self.mmio.read32(self._reg(UCON))
        ubrd = self.mmio.read32(self._reg(UBRDIV))
        ufr = self.mmio.read32(self._reg(UFRACVAL))
        print(f"[MMIO] After init: ULCON=0x{ulcon:08x} UCON=0x{ucon:08x}")
        print(f"[MMIO] After init: UBRDIV=0x{ubrd:08x} UFRACVAL=0x{ufr:08x}")

        self._initialized = True
        return True

    def tx_ready(self):
        """Check if TX FIFO has space."""
        stat = self.mmio.read32(self._reg(UFSTAT))
        return not (stat & UFSTAT_TX_FULL)

    def rx_ready(self):
        """Check if RX FIFO has data."""
        stat = self.mmio.read32(self._reg(UTRSTAT))
        return bool(stat & UTRSTAT_RX_READY)

    def write_byte(self, b):
        """Write a single byte, waiting for TX ready."""
        timeout = time.time() + 0.1
        while not self.tx_ready():
            if time.time() > timeout:
                print("[MMIO] TX timeout!", file=sys.stderr)
                return False
            time.sleep(0.0001)
        self.mmio.write32(self._reg(UTXH), b & 0xFF)
        return True

    def read_byte(self, timeout_s=0.5):
        """Read a single byte, with timeout."""
        deadline = time.time() + timeout_s
        while time.time() < deadline:
            if self.rx_ready():
                val = self.mmio.read32(self._reg(URXH))
                return val & 0xFF
            time.sleep(0.0001)
        return None

    def send_command(self, cmd):
        """Send a command string (adds newline)."""
        if not cmd.endswith('\n'):
            cmd += '\n'
        for ch in cmd:
            if not self.write_byte(ord(ch)):
                return False
        return True

    def read_response(self, timeout_s=2.0):
        """Read response line(s) until timeout."""
        buf = bytearray()
        deadline = time.time() + timeout_s
        while time.time() < deadline:
            b = self.read_byte(timeout_s=0.05)
            if b is not None:
                buf.append(b)
                if b == ord('\n'):
                    # Got a complete line - check if more coming
                    deadline = time.time() + 0.2  # Short wait for more
            else:
                if buf:
                    break  # Have data and no more coming
        return buf.decode('ascii', errors='replace').strip()

    def command(self, cmd, timeout_s=2.0):
        """Send command and return response."""
        print(f"  TX: {cmd}")
        self.send_command(cmd)
        resp = self.read_response(timeout_s)
        if resp:
            for line in resp.split('\n'):
                print(f"  RX: {line}")
        return resp

    def dump_state(self):
        """Dump all UART8 registers."""
        print(f"\n=== UART8 Register Dump (0x{self.base:09x}) ===")
        regs = [
            ("ULCON",    ULCON),
            ("UCON",     UCON),
            ("UFCON",    UFCON),
            ("UMCON",    UMCON),
            ("UTRSTAT",  UTRSTAT),
            ("UERSTAT",  UERSTAT),
            ("UFSTAT",   UFSTAT),
            ("UMSTAT",   UMSTAT),
            ("UBRDIV",   UBRDIV),
            ("UFRACVAL", UFRACVAL),
        ]
        for name, off in regs:
            val = self.mmio.read32(self._reg(off))
            print(f"  {name:10s} [0x{off:03x}] = 0x{val:08x}")


class NitrogenSerial:
    """Talk to Nitrogen MCU via /dev/ttyS* serial port."""

    def __init__(self, port=None):
        self.port = port
        self.fd = None

    def find_port(self):
        """Try to find the UART8 serial device."""
        # Try common serial device names
        candidates = []
        for prefix in ['/dev/ttyS', '/dev/ttySAC', '/dev/ttyAMA',
                       '/dev/ttyAPPLE', '/dev/serial/by-path/']:
            for i in range(16):
                path = f"{prefix}{i}"
                if os.path.exists(path):
                    candidates.append(path)

        # Also check for any tty devices
        if os.path.isdir('/dev'):
            for f in sorted(os.listdir('/dev')):
                if f.startswith('tty') and f not in ('tty', 'console'):
                    path = f'/dev/{f}'
                    if path not in candidates:
                        candidates.append(path)

        if not candidates:
            return None

        print(f"[Serial] Found serial ports: {candidates}")

        # The console UART is typically ttyS0 or the first one.
        # UART8 would be ttyS8 or similar. Try to identify by index.
        for c in candidates:
            if '8' in c.split('/')[-1]:
                print(f"[Serial] Likely UART8 candidate: {c}")
                return c

        print("[Serial] No obvious UART8 found. Candidates:")
        for c in candidates:
            print(f"  {c}")
        return None

    def open(self, port=None):
        """Open and configure the serial port."""
        if port:
            self.port = port
        if not self.port:
            self.port = self.find_port()
            if not self.port:
                print("[Serial] No suitable serial port found")
                return False

        print(f"[Serial] Opening {self.port} at {TARGET_BAUD} baud")
        try:
            self.fd = os.open(self.port, os.O_RDWR | os.O_NOCTTY | os.O_NONBLOCK)
        except (PermissionError, FileNotFoundError) as e:
            print(f"[Serial] Cannot open {self.port}: {e}")
            return False

        # Configure with termios
        try:
            attrs = termios.tcgetattr(self.fd)

            # Input flags: no parity check, no strip, no flow control
            attrs[0] = 0  # iflag

            # Output flags: raw
            attrs[1] = 0  # oflag

            # Control flags: 8N1, enable receiver, local mode
            # CS8 | CREAD | CLOCAL
            attrs[2] = termios.CS8 | termios.CREAD | termios.CLOCAL

            # Local flags: raw mode
            attrs[3] = 0  # lflag

            # Set baud rate
            # termios might not have B460800 on all systems
            try:
                baud_const = termios.B460800
            except AttributeError:
                # Try setting with BOTHER/c_ispeed/c_ospeed via ioctl
                baud_const = 0o010010  # B460800 = 0x1008 on many Linux
                print(f"[Serial] Using raw baud constant 0o{baud_const:o}")

            attrs[4] = baud_const  # ispeed
            attrs[5] = baud_const  # ospeed

            # Control characters
            attrs[6][termios.VMIN] = 0
            attrs[6][termios.VTIME] = 5  # 0.5s timeout

            termios.tcsetattr(self.fd, termios.TCSANOW, attrs)
            termios.tcflush(self.fd, termios.TCIOFLUSH)
        except Exception as e:
            print(f"[Serial] termios config failed: {e}")
            print("[Serial] Continuing anyway (may work with default settings)")

        # Clear non-blocking for reads with timeout
        flags = fcntl.fcntl(self.fd, fcntl.F_GETFL)
        fcntl.fcntl(self.fd, fcntl.F_SETFL, flags & ~os.O_NONBLOCK)

        print(f"[Serial] Port {self.port} configured")
        return True

    def send_command(self, cmd):
        """Send a command string."""
        if not cmd.endswith('\n'):
            cmd += '\n'
        try:
            os.write(self.fd, cmd.encode('ascii'))
            return True
        except Exception as e:
            print(f"[Serial] Write error: {e}")
            return False

    def read_response(self, timeout_s=2.0):
        """Read response with timeout using select."""
        buf = bytearray()
        deadline = time.time() + timeout_s
        while time.time() < deadline:
            remaining = deadline - time.time()
            if remaining <= 0:
                break
            r, _, _ = select.select([self.fd], [], [], min(remaining, 0.1))
            if r:
                try:
                    data = os.read(self.fd, 256)
                    if data:
                        buf.extend(data)
                        if b'\n' in data:
                            deadline = time.time() + 0.2  # Brief wait for more
                except Exception:
                    break
        return buf.decode('ascii', errors='replace').strip()

    def command(self, cmd, timeout_s=2.0):
        """Send command and return response."""
        print(f"  TX: {cmd}")
        self.send_command(cmd)
        resp = self.read_response(timeout_s)
        if resp:
            for line in resp.split('\n'):
                print(f"  RX: {line}")
        return resp

    def close(self):
        if self.fd is not None:
            os.close(self.fd)
            self.fd = None


def probe_mcu(mcu):
    """Run full probe sequence on MCU."""
    print("\n" + "=" * 60)
    print("  NITROGEN MCU PROBE")
    print("=" * 60)

    print("\n--- Firmware Version ---")
    sv = mcu.command("[SV]")

    print("\n--- MCU ID ---")
    mcuid = mcu.command("[MCUID]")

    print("\n--- Help (Command List) ---")
    help_text = mcu.command("[HELP]", timeout_s=5.0)

    print("\n--- Temperature ---")
    temp = mcu.command("[TEMP]")

    print("\n--- Telemetry Level 1 ---")
    telem = mcu.command("[TELEM,1]")

    print("\n--- Current Amp State ---")
    # Try reading some tweeter registers to see state
    for i in range(1, 8):
        print(f"\n  Tweeter {i}:")
        mcu.command(f"[TRI,{i},0]")   # Power/mute register
        mcu.command(f"[TRI,{i},5]")   # Slot assignment register

    print("\n" + "=" * 60)
    print("  PROBE COMPLETE")
    print("=" * 60)

    return {
        'version': sv,
        'mcuid': mcuid,
        'help': help_text,
        'temp': temp,
        'telem': telem,
    }


def get_mcu(method='auto', port=None, clock_hz=24000000):
    """Get an MCU communication object.

    method: 'auto', 'serial', 'mmio'
    port: serial port path (for serial method)
    clock_hz: UART source clock (for mmio method)
    """
    if method == 'auto':
        # Try serial first, fall back to MMIO
        serial = NitrogenSerial(port)
        found_port = serial.find_port()
        if found_port:
            serial.port = found_port
            if serial.open():
                print("[Auto] Using serial port")
                return serial
            serial.close()
        print("[Auto] No serial port, falling back to MMIO")
        method = 'mmio'

    if method == 'serial':
        serial = NitrogenSerial(port)
        if serial.open(port):
            return serial
        return None

    if method == 'mmio':
        mmio_uart = NitrogenMMIO(clock_hz=clock_hz)
        # Try multiple clock rates
        for clk in [24000000, 48000000, 192000000, 96000000]:
            mmio_uart.clock_hz = clk
            mmio_uart.dump_state()
            if mmio_uart.init_uart():
                # Quick test: send [SV] and see if we get anything back
                print(f"\n[MMIO] Testing with {clk/1e6:.0f}MHz clock...")
                mmio_uart.send_command("[SV]")
                resp = mmio_uart.read_response(timeout_s=1.0)
                if resp and '<' in resp:
                    print(f"[MMIO] Got response with {clk/1e6:.0f}MHz clock!")
                    return mmio_uart
                elif resp:
                    print(f"[MMIO] Got data but no valid response: {repr(resp)}")
                else:
                    print(f"[MMIO] No response with {clk/1e6:.0f}MHz clock")

        # Return the last config even if no response (for debugging)
        print("[MMIO] WARNING: No valid response from MCU. Returning MMIO handle for debugging.")
        return mmio_uart

    return None


def interactive_mode(mcu):
    """Interactive command shell."""
    print("\n" + "=" * 60)
    print("  NITROGEN INTERACTIVE SHELL")
    print("  Type commands like [SV] or [AMP,A]")
    print("  Type 'quit' or Ctrl-C to exit")
    print("  Type 'probe' for full probe")
    print("  Type 'ESTOP' for emergency shutdown")
    print("=" * 60 + "\n")

    try:
        while True:
            try:
                cmd = input("nitro> ").strip()
            except EOFError:
                break

            if not cmd:
                continue
            if cmd.lower() == 'quit':
                break
            if cmd.lower() == 'probe':
                probe_mcu(mcu)
                continue
            if cmd.upper() == 'ESTOP':
                print("!!! EMERGENCY STOP !!!")
                mcu.command("[AMP,X]")
                mcu.command("[WFR,N]")
                print("Amps shut down.")
                continue

            # Send raw command
            if not cmd.startswith('['):
                cmd = f'[{cmd}]'
            mcu.command(cmd, timeout_s=3.0)
    except KeyboardInterrupt:
        print("\nExiting.")


def main():
    import argparse

    parser = argparse.ArgumentParser(description='Nitrogen MCU communication tool')
    parser.add_argument('action', nargs='?', default='probe',
                        choices=['probe', 'status', 'cmd', 'interactive',
                                 'mmio-init', 'dump-uart'],
                        help='Action to perform')
    parser.add_argument('command', nargs='?', help='Command for "cmd" action')
    parser.add_argument('--port', '-p', help='Serial port path')
    parser.add_argument('--method', '-m', default='auto',
                        choices=['auto', 'serial', 'mmio'],
                        help='Communication method')
    parser.add_argument('--clock', '-c', type=int, default=24000000,
                        help='UART source clock in Hz (for MMIO)')
    args = parser.parse_args()

    if args.action == 'dump-uart':
        # Just dump UART8 registers without trying to communicate
        uart = NitrogenMMIO(clock_hz=args.clock)
        uart.dump_state()
        return

    mcu = get_mcu(method=args.method, port=args.port, clock_hz=args.clock)
    if mcu is None:
        print("ERROR: Could not establish MCU communication")
        sys.exit(1)

    if args.action == 'probe':
        probe_mcu(mcu)

    elif args.action == 'status':
        print("\n--- Status ---")
        mcu.command("[SV]")
        mcu.command("[TEMP]")
        mcu.command("[TELEM,1]")

    elif args.action == 'cmd':
        if not args.command:
            print("Usage: nitrogen.py cmd '[COMMAND]'")
            sys.exit(1)
        mcu.command(args.command, timeout_s=5.0)

    elif args.action == 'interactive':
        interactive_mode(mcu)

    elif args.action == 'mmio-init':
        if isinstance(mcu, NitrogenMMIO):
            print("MMIO UART initialized.")
            probe_mcu(mcu)
        else:
            print("Already using serial port, no MMIO init needed.")
            probe_mcu(mcu)


if __name__ == '__main__':
    main()
