#!/usr/bin/env python3
"""
test_tone.py - Generate a test tone through the HomePod speakers via MCA3 PIO.

This writes audio samples directly to the MCA3 TX FIFO register using /dev/mem,
bypassing any kernel audio subsystem. This is the most bare-metal approach
possible for initial audio bring-up.

SAFETY WARNINGS:
  - Without Apple's DSP, there is NO crossover, NO limiter, NO protection.
  - Start at VERY LOW volume (-30dB or lower).
  - Test ONLY tweeters first (slots 1-7). The woofer (slot 0) needs a
    high-pass filter at minimum 30Hz to avoid damage.
  - Keep telemetry monitoring running in another shell.
  - Have emergency_stop.sh ready to run.

Audio format:
  MCA3 TDM: 8 slots, 32-bit per slot, 48kHz frame rate
  Total bit rate: 8 * 32 * 48000 = 12.288 Mbit/s
  MCLK: 256fs = 12.288 MHz (from NCO)
  BCLK: 256fs = 12.288 MHz (same as MCLK for this config)

Crossover requirements (for future full implementation):
  Woofer:  LPF 400Hz LR4 + HPF 30Hz (subsonic protection)
  Tweeter: HPF 400Hz LR4
  Total:   400Hz Linkwitz-Riley 4th order crossover
"""

import os
import sys
import math
import time
import struct
import signal
import argparse

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import mmio

# ============================================================
# MCA3 hardware configuration
# ============================================================

MCA3_BASE       = 0x20a0ac000
NCO_BASE        = 0x20e011000
I2S_SWITCH_BASE = 0x20a003000

# MCA register offsets (from Asahi driver, may need adjustment for A8)
REG_STATUS          = 0x000
REG_MCLK_CONF       = 0x004
REG_SYNCGEN_STATUS  = 0x100
REG_SYNCGEN_MCLK    = 0x104
REG_SYNCGEN_HI      = 0x108
REG_SYNCGEN_LO      = 0x10C
REG_TX_SERDES_CONF     = 0x200
REG_TX_SERDES_BITSTART = 0x204
REG_TX_SERDES_SLOTMASK = 0x208
REG_TX_SERDES_SLOTS    = 0x20C
REG_TX_PORT_CONF    = 0x400
REG_TX_PORT_CTL     = 0x404
REG_TX_PORT_FIFO    = 0x408
REG_TX_PORT_DATA    = 0x40C
REG_PORT_ENABLES    = 0x600
REG_PORT_CLK_SEL    = 0x604
REG_PORT_DATA_SEL   = 0x608

# Audio parameters
SAMPLE_RATE = 48000
NUM_SLOTS   = 8
BITS_PER_SLOT = 32
MCLK_RATIO  = 256   # MCLK = 256 * fs = 12.288 MHz

# NCO register offsets (per channel, stride TBD)
NCO_CTL  = 0x00
NCO_INC  = 0x04
NCO_ACCU = 0x08

# Safety limits
MAX_AMPLITUDE_DB = -20  # Absolute maximum amplitude
DEFAULT_DB = -30        # Default safe amplitude
ABSOLUTE_MIN_DB = -60   # Minimum useful amplitude


def db_to_linear(db):
    """Convert dB to linear amplitude (0.0 to 1.0)."""
    return 10.0 ** (db / 20.0)


def generate_sine(freq_hz, amplitude_db, duration_s, sample_rate=SAMPLE_RATE):
    """Generate 32-bit signed integer sine wave samples.

    Returns list of 32-bit signed integers.
    """
    if amplitude_db > MAX_AMPLITUDE_DB:
        print(f"SAFETY: Clamping amplitude from {amplitude_db}dB to {MAX_AMPLITUDE_DB}dB")
        amplitude_db = MAX_AMPLITUDE_DB

    amplitude = db_to_linear(amplitude_db)
    max_val = 0x7FFFFFFF  # 32-bit signed max

    num_samples = int(duration_s * sample_rate)
    samples = []

    for i in range(num_samples):
        t = i / sample_rate
        val = amplitude * math.sin(2 * math.pi * freq_hz * t)
        sample = int(val * max_val)
        # Clamp to 32-bit signed range
        sample = max(-0x80000000, min(0x7FFFFFFF, sample))
        samples.append(sample)

    return samples


def generate_silence(duration_s, sample_rate=SAMPLE_RATE):
    """Generate silence samples."""
    return [0] * int(duration_s * sample_rate)


def signed_to_unsigned32(val):
    """Convert signed 32-bit to unsigned for register write."""
    if val < 0:
        return val + 0x100000000
    return val & 0xFFFFFFFF


class MCAController:
    """Direct MCA3 register controller for PIO audio output."""

    def __init__(self, base=MCA3_BASE):
        self.base = base
        self._running = False

    def _reg(self, offset):
        return self.base + offset

    def read_status(self):
        """Read current MCA state."""
        status = mmio.read32(self._reg(REG_STATUS))
        mclk = mmio.read32(self._reg(REG_MCLK_CONF))
        port_en = mmio.read32(self._reg(REG_PORT_ENABLES))
        tx_conf = mmio.read32(self._reg(REG_TX_PORT_CONF))
        tx_fifo = mmio.read32(self._reg(REG_TX_PORT_FIFO))

        print(f"  MCA3 STATUS:     0x{status:08x}")
        print(f"  MCA3 MCLK_CONF:  0x{mclk:08x}")
        print(f"  MCA3 PORT_EN:    0x{port_en:08x}")
        print(f"  MCA3 TX_CONF:    0x{tx_conf:08x}")
        print(f"  MCA3 TX_FIFO:    0x{tx_fifo:08x}")

        return status

    def check_clocked(self):
        """Check if MCA3 appears clocked and accessible."""
        val = mmio.read32(self._reg(REG_STATUS))
        if val == 0xFFFFFFFF:
            print("ERROR: MCA3 reads as 0xFFFFFFFF - not clocked!")
            print("The audio power domain or clock gate may need enabling.")
            print("Check PMGR registers or device tree for audio clock gates.")
            return False
        return True

    def configure_syncgen(self):
        """Configure the sync generator for 48kHz TDM.

        The syncgen divides MCLK to create the frame sync (LRCK/WS)
        and bit clock (BCLK) for the I2S/TDM interface.

        For 8-slot 32-bit TDM at 48kHz:
          Frame = 8 * 32 = 256 bits
          BCLK = 48000 * 256 = 12.288 MHz
          With 256fs MCLK: BCLK = MCLK (no division needed)
        """
        print("\n  Configuring syncgen for 48kHz 8-slot TDM...")

        # SYNCGEN period: total frame length in MCLK cycles
        # For 256fs MCLK and 256-bit TDM frame: 1 MCLK per bit
        frame_bits = NUM_SLOTS * BITS_PER_SLOT  # 256
        hi_period = frame_bits // 2   # 128 MCLK high
        lo_period = frame_bits // 2   # 128 MCLK low

        mmio.write32(self._reg(REG_SYNCGEN_HI), hi_period)
        mmio.write32(self._reg(REG_SYNCGEN_LO), lo_period)

        # MCLK divider for syncgen
        mmio.write32(self._reg(REG_SYNCGEN_MCLK), 1)  # Divide by 1

        # Enable syncgen
        mmio.write32(self._reg(REG_SYNCGEN_STATUS), 1)

        print(f"    Frame: {frame_bits} bits ({hi_period}/{lo_period} hi/lo)")
        print(f"    BCLK = MCLK / 1 = 12.288 MHz")

    def configure_tx_serdes(self, slot_mask=0xFE):
        """Configure TX serializer for TDM output.

        slot_mask: bitmask of active slots (default 0xFE = slots 1-7, NO woofer)
                   0xFF = all 8 slots including woofer (slot 0)
        """
        print(f"\n  Configuring TX SERDES (slot mask 0x{slot_mask:02x})...")

        # SERDES configuration:
        # - TDM mode (not I2S left-justified)
        # - 32-bit slot width
        # - MSB first
        # These are guesses based on the Asahi driver - values may need adjustment

        # TX SERDES config register (format TBD, try Asahi-like values)
        # On M1: bit 0 = enable, bits 4-7 = format, bits 8-12 = slot width
        serdes_conf = (1 << 0)   # Enable
        serdes_conf |= (0 << 4)  # Format 0 = I2S/TDM
        # Slot width might be encoded differently
        mmio.write32(self._reg(REG_TX_SERDES_CONF), serdes_conf)

        # Bit start: which bit position starts the first slot
        mmio.write32(self._reg(REG_TX_SERDES_BITSTART), 0)

        # Slot mask: which slots are active
        mmio.write32(self._reg(REG_TX_SERDES_SLOTMASK), slot_mask)

        # Active slots count
        active_count = bin(slot_mask).count('1')
        mmio.write32(self._reg(REG_TX_SERDES_SLOTS), active_count)

        print(f"    Active slots: {active_count}")
        slots = [i for i in range(8) if slot_mask & (1 << i)]
        print(f"    Slot list: {slots}")

    def configure_tx_port(self):
        """Configure the TX port for PIO mode (write samples to FIFO register)."""
        print("\n  Configuring TX port for PIO mode...")

        # TX port configuration
        # On M1: various mode bits for DMA vs PIO, FIFO thresholds, etc.
        # For PIO: we just need to enable the port and write to the data register

        # Try basic enable
        tx_conf = (1 << 0)  # Enable TX port
        mmio.write32(self._reg(REG_TX_PORT_CONF), tx_conf)

        # TX control: start TX
        mmio.write32(self._reg(REG_TX_PORT_CTL), 1)

        # Reset FIFO
        mmio.write32(self._reg(REG_TX_PORT_FIFO), 0x02)  # Reset
        time.sleep(0.001)
        mmio.write32(self._reg(REG_TX_PORT_FIFO), 0x01)  # Enable

    def configure_port_routing(self):
        """Configure port enables and routing."""
        print("\n  Configuring port routing...")

        # Enable TX port
        port_en = mmio.read32(self._reg(REG_PORT_ENABLES))
        port_en |= (1 << 0)  # Enable TX
        mmio.write32(self._reg(REG_PORT_ENABLES), port_en)

        # Clock select: use internal syncgen
        mmio.write32(self._reg(REG_PORT_CLK_SEL), 0)

        # Data select: route TX data to output pins
        mmio.write32(self._reg(REG_PORT_DATA_SEL), 0)

    def configure_nco(self, target_freq=12288000):
        """Configure NCO for MCLK generation.

        target_freq: desired MCLK frequency in Hz
                     12.288 MHz = 256 * 48000 Hz
        """
        print(f"\n  Configuring NCO for {target_freq/1e6:.3f} MHz MCLK...")

        # NCO generates a clock by accumulating a phase increment.
        # Output freq = (increment / 2^32) * source_clock
        # We need to know the NCO source clock to calculate the increment.

        # Common NCO source clocks on Apple SoCs:
        # - 24 MHz (crystal)
        # - PLL output (varies)

        # For now, dump NCO state and try to figure out the source clock
        nco_ctl = mmio.read32(NCO_BASE + NCO_CTL)
        nco_inc = mmio.read32(NCO_BASE + NCO_INC)
        nco_accu = mmio.read32(NCO_BASE + NCO_ACCU)

        print(f"    NCO CTL:  0x{nco_ctl:08x}")
        print(f"    NCO INC:  0x{nco_inc:08x}")
        print(f"    NCO ACCU: 0x{nco_accu:08x}")

        if nco_inc != 0:
            print(f"    NCO already configured (increment = {nco_inc})")
            # Try to reverse-engineer the source clock
            # If output is 12.288MHz: src_clk = 12288000 * 2^32 / increment
            inferred_src = (12288000.0 * (2**32)) / nco_inc
            print(f"    Inferred source clock: {inferred_src/1e6:.3f} MHz")
            return

        # Try setting up NCO for 12.288 MHz
        # Assume 24 MHz source: increment = 12288000 * 2^32 / 24000000
        for src_clk in [24000000, 48000000, 192000000]:
            inc = int((target_freq * (2**32)) / src_clk)
            if 0 < inc < 2**32:
                print(f"    Trying {src_clk/1e6:.0f}MHz source: increment = 0x{inc:08x}")
                break

        # Enable NCO and set increment
        mmio.write32(NCO_BASE + NCO_INC, inc)
        mmio.write32(NCO_BASE + NCO_CTL, 1)  # Enable

        # Verify
        time.sleep(0.01)
        accu1 = mmio.read32(NCO_BASE + NCO_ACCU)
        time.sleep(0.001)
        accu2 = mmio.read32(NCO_BASE + NCO_ACCU)
        if accu1 != accu2:
            print(f"    NCO running (accumulator changing: 0x{accu1:08x} -> 0x{accu2:08x})")
        else:
            print(f"    WARNING: NCO may not be running (accumulator static: 0x{accu1:08x})")

    def enable_cluster(self):
        """Enable the MCA3 cluster."""
        print("\n  Enabling MCA3 cluster...")

        # Set MCLK configuration
        mmio.write32(self._reg(REG_MCLK_CONF), 1)  # Enable MCLK

        # Enable cluster
        status = mmio.read32(self._reg(REG_STATUS))
        status |= 1
        mmio.write32(self._reg(REG_STATUS), status)

        time.sleep(0.01)
        new_status = mmio.read32(self._reg(REG_STATUS))
        print(f"    Status after enable: 0x{new_status:08x}")

    def write_frame(self, samples_per_slot):
        """Write one TDM frame (8 slots) to the TX FIFO.

        samples_per_slot: list of 8 32-bit sample values (one per slot)
        """
        for slot in range(NUM_SLOTS):
            val = signed_to_unsigned32(samples_per_slot[slot])
            mmio.write32(self._reg(REG_TX_PORT_DATA), val)

    def full_setup(self, slot_mask=0xFE, configure_clocks=True):
        """Full MCA3 configuration for TDM audio output.

        slot_mask: which slots to enable (0xFE = tweeters only)
        configure_clocks: whether to touch NCO/MCLK (may already be set)
        """
        print("\n" + "=" * 60)
        print("  MCA3 CONFIGURATION")
        print("=" * 60)

        if not self.check_clocked():
            return False

        print("\n  Current state:")
        self.read_status()

        if configure_clocks:
            self.configure_nco()

        self.enable_cluster()
        self.configure_syncgen()
        self.configure_tx_serdes(slot_mask)
        self.configure_tx_port()
        self.configure_port_routing()

        print("\n  Final state:")
        self.read_status()

        return True

    def stop(self):
        """Stop MCA3 output."""
        self._running = False
        # Disable TX port
        mmio.write32(self._reg(REG_TX_PORT_CTL), 0)
        # Disable TX port
        mmio.write32(self._reg(REG_TX_PORT_CONF), 0)
        print("  MCA3 TX stopped")


def play_tone(mca, freq_hz=1000, amplitude_db=DEFAULT_DB, duration_s=1.0,
              target_slot=1, slot_mask=None):
    """Play a sine wave through a specific TDM slot.

    freq_hz: tone frequency in Hz (default 1000)
    amplitude_db: amplitude in dB (default -30, max -20)
    duration_s: duration in seconds
    target_slot: which TDM slot (1-7 for tweeters, 0 for woofer)
    slot_mask: custom slot mask (default: only target_slot)

    SAFETY: slot 0 (woofer) is blocked unless explicitly unblocked
    """
    # Safety checks
    if target_slot == 0:
        print("SAFETY: Slot 0 (woofer) is BLOCKED.")
        print("The woofer needs crossover protection (HPF at 30Hz minimum).")
        print("Use --allow-woofer to override (AT YOUR OWN RISK).")
        return False

    if amplitude_db > MAX_AMPLITUDE_DB:
        print(f"SAFETY: Clamping amplitude to {MAX_AMPLITUDE_DB}dB")
        amplitude_db = MAX_AMPLITUDE_DB

    if freq_hz < 100 or freq_hz > 20000:
        print(f"WARNING: Frequency {freq_hz}Hz is outside normal tweeter range")

    if slot_mask is None:
        slot_mask = 1 << target_slot

    print(f"\n{'=' * 60}")
    print(f"  TEST TONE")
    print(f"  Frequency: {freq_hz} Hz")
    print(f"  Amplitude: {amplitude_db} dB ({db_to_linear(amplitude_db):.6f} linear)")
    print(f"  Duration:  {duration_s}s")
    print(f"  Slot:      {target_slot} (mask 0x{slot_mask:02x})")
    print(f"{'=' * 60}")

    # Generate samples
    print(f"\n  Generating {freq_hz}Hz sine at {amplitude_db}dB...")
    samples = generate_sine(freq_hz, amplitude_db, duration_s)
    print(f"  Generated {len(samples)} samples")

    # PIO output: write samples frame-by-frame
    # Each frame has 8 slots. We put the tone in the target slot
    # and silence in all others.
    print(f"\n  Starting PIO output ({len(samples)} frames)...")
    print(f"  (This is CPU-intensive PIO - timing may not be perfect)")
    print(f"  Press Ctrl+C for immediate stop\n")

    frame = [0] * NUM_SLOTS
    mca._running = True
    frames_written = 0
    start_time = time.time()

    # Target time per frame: 1/48000 = ~20.83 microseconds
    frame_period = 1.0 / SAMPLE_RATE

    try:
        for i, sample in enumerate(samples):
            if not mca._running:
                break

            # Build frame with tone in target slot, silence elsewhere
            frame[target_slot] = sample

            # Write frame to FIFO
            mca.write_frame(frame)
            frames_written += 1

            # Crude timing (Python can't do 48kHz accurately, but
            # the FIFO should absorb the jitter)
            # Only sleep if we're ahead of schedule
            expected_time = start_time + (i * frame_period)
            now = time.time()
            if now < expected_time:
                # We're ahead - this won't happen often in Python
                pass
            elif now > expected_time + 0.1:
                # We've fallen way behind - this is normal for PIO
                pass

    except KeyboardInterrupt:
        print("\n\n  INTERRUPTED - stopping output")
        mca._running = False

    elapsed = time.time() - start_time
    actual_rate = frames_written / elapsed if elapsed > 0 else 0
    print(f"\n  Wrote {frames_written} frames in {elapsed:.3f}s")
    print(f"  Effective rate: {actual_rate:.0f} Hz (target: {SAMPLE_RATE})")
    if actual_rate < SAMPLE_RATE * 0.5:
        print(f"  WARNING: Rate well below 48kHz - PIO too slow!")
        print(f"  Audio will sound lower-pitched and distorted.")
        print(f"  This is expected for Python PIO - C version will be faster.")

    return True


# Signal handler for clean shutdown
_mca_global = None

def _sigint_handler(signum, frame):
    print("\n\nSIGINT - emergency stop!")
    if _mca_global:
        _mca_global.stop()
    sys.exit(1)


def main():
    global _mca_global

    parser = argparse.ArgumentParser(
        description='HomePod test tone generator (MCA3 PIO)',
        epilog="""
SAFETY: This tool has NO crossover protection. Only use with tweeters (slots 1-7).
The woofer (slot 0) needs a high-pass filter that this tool does not implement.
Start at low volume (-30dB or lower) and gradually increase.
        """)
    parser.add_argument('action', nargs='?', default='info',
                        choices=['info', 'setup', 'tone', 'sweep', 'all-slots'],
                        help='Action to perform')
    parser.add_argument('--freq', '-f', type=int, default=1000,
                        help='Tone frequency in Hz (default 1000)')
    parser.add_argument('--db', '-d', type=float, default=DEFAULT_DB,
                        help=f'Amplitude in dB (default {DEFAULT_DB}, max {MAX_AMPLITUDE_DB})')
    parser.add_argument('--duration', '-t', type=float, default=1.0,
                        help='Duration in seconds (default 1.0)')
    parser.add_argument('--slot', '-s', type=int, default=1,
                        help='Target TDM slot (1-7 for tweeters, default 1)')
    parser.add_argument('--allow-woofer', action='store_true',
                        help='Allow slot 0 (woofer) - DANGEROUS')
    parser.add_argument('--no-setup', action='store_true',
                        help='Skip MCA setup (if already configured)')
    args = parser.parse_args()

    signal.signal(signal.SIGINT, _sigint_handler)

    mca = MCAController()
    _mca_global = mca

    try:
        if args.action == 'info':
            print("MCA3 current state:")
            if mca.check_clocked():
                mca.read_status()
            else:
                print("MCA3 not accessible - check clock gates")

        elif args.action == 'setup':
            # Just configure MCA3, don't play anything
            mca.full_setup(slot_mask=0xFE)

        elif args.action == 'tone':
            if not args.no_setup:
                if not mca.full_setup(slot_mask=(1 << args.slot)):
                    print("Setup failed!")
                    return

            if args.slot == 0 and not args.allow_woofer:
                print("BLOCKED: Use --allow-woofer to enable slot 0")
                return

            play_tone(mca, freq_hz=args.freq, amplitude_db=args.db,
                      duration_s=args.duration, target_slot=args.slot)
            mca.stop()

        elif args.action == 'sweep':
            # Frequency sweep through one tweeter
            if not args.no_setup:
                if not mca.full_setup(slot_mask=(1 << args.slot)):
                    return

            freqs = [200, 500, 1000, 2000, 4000, 8000, 12000, 16000]
            print(f"\nFrequency sweep on slot {args.slot}:")
            for f in freqs:
                print(f"\n  --- {f} Hz ---")
                play_tone(mca, freq_hz=f, amplitude_db=args.db,
                          duration_s=0.5, target_slot=args.slot)
                time.sleep(0.2)
            mca.stop()

        elif args.action == 'all-slots':
            # Test each tweeter slot individually
            if not args.no_setup:
                if not mca.full_setup(slot_mask=0xFE):
                    return

            print("\nTesting each tweeter slot:")
            for slot in range(1, 8):
                print(f"\n  === Slot {slot} (Tweeter {slot}) ===")
                play_tone(mca, freq_hz=1000, amplitude_db=args.db,
                          duration_s=0.5, target_slot=slot,
                          slot_mask=(1 << slot))
                time.sleep(0.3)
            mca.stop()

    except Exception as e:
        print(f"\nERROR: {e}")
        import traceback
        traceback.print_exc()
    finally:
        mca.stop()
        mmio.cleanup()


if __name__ == '__main__':
    main()
