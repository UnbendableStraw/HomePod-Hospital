/*
 * hpfeed - real-time 8-slot TDM feeder for the HomePod (1st gen) MCA3.
 *
 * Userspace, /dev/mem.  Expects the hardware to be initialised already
 * (homepod-audio.py: power domains, NCO at 48 kHz, MCA3 TX running, amps).
 *
 * Slot map: word 0 of every frame = woofer, words 1..7 = tweeters.
 * The MCA pops one FIFO word per enabled slot with no frame atomicity, so
 * word<->slot alignment is established once by align() and is lost on any
 * underrun.  An underrun is detected from the status register; the feeder
 * then mutes (zeros) and re-aligns before any audio is sent again.
 *
 * Input: raw PCM, S16LE interleaved, on stdin or a FIFO (-i).  It is mixed
 * to mono, resampled to 48 kHz, split by a 4th-order Linkwitz-Riley
 * crossover (woofer low-pass, tweeters high-pass) and hard-limited.
 */
#define _GNU_SOURCE
#include <errno.h>
#include <fcntl.h>
#include <math.h>
#include <sched.h>
#include <signal.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/mman.h>
#include <time.h>
#include <unistd.h>
#include <poll.h>
#include <pthread.h>
#include <sys/stat.h>
#include <time.h>
#include "hpdsp.h"
#include "hpdsp2.h"
#include "hpdsp3.h"                     /* profile apple3 */
#include "hpxtc.h"                      /* multichannel source: the stage in front of it */
#include "meter2.h"                     /* /run/homepod/meter2 layout */

#define MCA3_BASE 0x20A0AC000ULL
#define PMGR_BASE 0x20E000000ULL
#define PS_MCA3   0x20148

#define R_CTRL    (0x0C / 4)
#define R_TXCTRL  (0x18 / 4)
#define R_MASK    (0x24 / 4)
#define R_DATA    (0x28 / 4)
#define R_STAT    (0x40 / 4)
#define ST_LEVEL  0xff
#define ST_UNDER  0x1000   /* W1C: a slot popped an empty FIFO */
#define ST_OVER   0x2000   /* W1C: write to a full FIFO */

#define RATE      48000
#define SLOTS     8
#define FIFO_HIGH 112      /* of 128 words; always a multiple of 8 */
#define FULL24    8388607.0

static volatile uint32_t *mca;
static volatile sig_atomic_t g_stop;
static uint64_t tfreq;                 /* counter ticks per second */

static inline uint64_t ticks(void)
{
	uint64_t v;
	__asm__ volatile("isb\n\tmrs %0, cntvct_el0" : "=r"(v));
	return v;
}
static inline uint64_t us2t(double us) { return (uint64_t)(us * (double)tfreq / 1e6); }
static inline void spin_until(uint64_t t) { while (ticks() < t) ; }
static inline uint32_t level(void) { return mca[R_STAT] & ST_LEVEL; }

static void on_sig(int s) { (void)s; g_stop = 1; }

/* ------------------------------------------------------------------ align */
/*
 * Establish word<->slot alignment without stopping TX (so no pops), using
 * zeros only.  With mask=0x01 one word pops per frame, at slot 0; that pop
 * gives the frame phase.  Slots 5..7 are then enabled early in the same
 * frame (3 pad words pop), slots 1..4 late in that frame, so from the next
 * frame on all 8 slots pop and the FIFO head is word 0.  Every window is
 * several microseconds wide; the pop counts are verified from the FIFO level
 * in the two following frames.  Returns 0 or a negative reason code.
 */
static int align_once(int *d1, int *d2)
{
	const uint64_t frame = tfreq / RATE;
	uint64_t t0, t, phi = 0, P;
	uint32_t l0, l1, v;
	int i, k, x, e;

	mca[R_MASK] = 0x01;
	t0 = ticks();
	while (level() != 0)
		if (ticks() - t0 > tfreq / 50)
			return -1;                    /* FIFO does not drain */
	for (i = 0; i < 4 + 8 * 8; i++)
		mca[R_DATA] = 0;
	mca[R_STAT] = ST_UNDER | ST_OVER;

	/*
	 * Frame phase: the earliest observation of the slot-0 pop over six
	 * frames.  A register read costs most of a microsecond, so a single
	 * observation is not good enough; the minimum rejects late ones.
	 */
	l0 = level();
	t0 = ticks();
	for (k = 0; k < 6; ) {
		l1 = level();
		t = ticks();
		if (l1 < l0) {
			if (k)
				phi += frame * (l0 - l1);
			if (!k || t < phi)
				phi = t;
			k++;
			l0 = l1;
		}
		if (t - t0 > tfreq / 500)
			return -2;                    /* no pops: TX stopped? */
	}

	/* frame F: the next slot-0 pop that is at least 3 us away */
	t = ticks();
	P = phi + frame * ((t + us2t(3.0) - phi) / frame + 1);
	spin_until(P + us2t(1.0));
	l1 = level();
	if (ticks() - P > us2t(4.0))
		return -3;                            /* we were interrupted */
	x = (8 - ((int)(l1 + 8 - 3) % 8)) % 8;        /* pad so (l1+x-3) % 8 == 0 */
	for (i = 0; i < x; i++)
		mca[R_DATA] = 0;
	mca[R_MASK] = 0xE1;
	if (ticks() - P > us2t(9.0))
		return -5;
	e = (int)l1 + x - 3;

	spin_until(P + us2t(16.5));
	mca[R_MASK] = 0xFF;
	if (ticks() - P > us2t(18.4))
		return -6;

	spin_until(P + us2t(18.6));
	v = level();
	t = ticks();
	*d1 = (int)v; *d2 = e;
	if (t - P > us2t(19.8))
		return -7;
	if ((int)v != e)
		return -8;                            /* wrong pop count in frame F */

	spin_until(P + frame + us2t(18.6));
	v = level();
	t = ticks();
	*d1 = (int)v; *d2 = e - 8;
	if (t - P > frame + us2t(19.8))
		return -9;
	if ((int)v != e - 8)
		return -10;                           /* not 8 pops per frame */

	if (mca[R_STAT] & ST_UNDER)
		return -11;
	return 0;
}

static int align(int verbose)
{
	int i, r = 0, d1 = 0, d2 = 0, hist[12] = {0};

	for (i = 0; i < 200 && !g_stop; i++) {
		r = align_once(&d1, &d2);
		if (r == 0) {
			if (verbose)
				fprintf(stderr, "hpfeed: aligned after %d retr%s\n",
					i, i == 1 ? "y" : "ies");
			return i;
		}
		if (-r < 12)
			hist[-r]++;
	}
	fprintf(stderr, "hpfeed: ALIGN FAILED (last %d, level %d expected %d); reasons:",
		r, d1, d2);
	for (i = 1; i < 12; i++)
		if (hist[i])
			fprintf(stderr, " -%d x%d", i, hist[i]);
	fprintf(stderr, "\n");
	mca[R_MASK] = 0x01;                           /* slot 0 only, zeros */
	return -1;
}

/* -------------------------------------------------------------------- DSP */
struct biquad { double b0, b1, b2, a1, a2, z1, z2; };

static void bq_set(struct biquad *q, int highpass, double fc, double Q)
{
	double w = 2.0 * M_PI * fc / RATE, c = cos(w), al = sin(w) / (2.0 * Q);
	double a0 = 1.0 + al;

	if (highpass) {
		q->b0 = (1.0 + c) / 2.0 / a0; q->b1 = -(1.0 + c) / a0; q->b2 = q->b0;
	} else {
		q->b0 = (1.0 - c) / 2.0 / a0; q->b1 = (1.0 - c) / a0; q->b2 = q->b0;
	}
	q->a1 = -2.0 * c / a0; q->a2 = (1.0 - al) / a0;
	q->z1 = q->z2 = 0.0;
}
static inline double bq(struct biquad *q, double x)
{
	double y = q->b0 * x + q->z1;

	q->z1 = q->b1 * x - q->a1 * y + q->z2;
	q->z2 = q->b2 * x - q->a2 * y;
	return y;
}

static struct biquad w_sub, w_lp1, w_lp2, t_hp1, t_hp2;
static double g_woofer = 1.0, g_tweeter = 1.0, g_ceiling;
static long g_clipped;

static inline int32_t to_word(double v)
{
	if (v > g_ceiling) { v = g_ceiling; g_clipped++; }
	else if (v < -g_ceiling) { v = -g_ceiling; g_clipped++; }
	return (int32_t)lrint(v * FULL24) * 256;
}

/*
 * Speaker tuning. profile 1 = modelled on Apple's own speaker graph (hpdsp.h),
 * profile 0 = the old flat two-way split at -x Hz. Settings can be changed
 * while running through DSPCONF ("key=value" lines, re-read when the file
 * changes): profile=apple|apple2|flat position=free|wall|book
 * loud=<dB|off|auto> woofer_db= tweeter_db= delay=<samples> subsonic=<Hz>
 * volume_db=<master volume, written by "homepod-audio volume"> loud_ref=<dB>
 *
 * profile 2 = "apple2" (hpdsp2.h): stereo, beamformer, compressor, limiters,
 * woofer excursion guard. Its extra keys:
 *   front=<deg>      where the direct beam's "front" points, from tweeter 1
 *   order=1234567    ring position (1..7, counting round the ring) of the
 *                    tweeter on TDM slot 1,2,..7
 *   solo=<0..7>      only that slot's tweeter plays (to find the order)
 *   drc= limit= guard=  0|1  compressor / peak limiters / excursion guard
 *   bass_reduce=0|1  Apple's "reduce bass"
 *   effort=<0..1>    thermal back-off (raises the woofer high-pass, lowers the
 *                    excursion limit) as in PuffinPowerParameterMapping
 *   xlim=<mm> ambient_db= out_db= wdelay=<samples> tw_invert=0|1
 *
 * Web UI keys (any profile unless noted; a missing key means its default):
 *   channels=stereo|mono|left|right   in front of the DSP, 20 ms ramp (ch_set/ch_run)
 *   eq=0|1 eq_pre=<-12..0 dB> eq0..eq9=<peak|lowshelf|highshelf>,<Hz>,<dB>,<Q>|off
 *                    user EQ, apple2/apple3 only (hpdsp3.h a3_eq_*): RBJ cookbook
 *                    sections on mid and side after the input gain; ramped, never stepped
 */
#define DSPCONF "/run/homepod/dsp.conf"
static struct hpdsp g_dsp;
static struct hpdsp2 g_a2;
static struct hpdsp3 g_a3;              /* apple3; its cfg is copied from g_a2.cfg in dsp_apply() */
static int g_a3_init;
static int g_profile = 1, g_position = 0, g_twdelay = 0, g_loud_auto = 0, g_a2_init = 0;
static double g_sync_trim;             /* dsp.conf sync_ms, seconds: + = a sync source plays later */
static float g_sync_err_ms, g_sync_wait_ms;   /* for meter2: the sync source's timing error and its wait */
static double g_loud = -9.0, g_subsonic = 40.0, g_wdb = 0.0, g_tdb = 0.0;
static double g_volume_db = -10.0, g_loud_ref = 1.0;
static int g_mute;                      /* dsp.conf mute=1: fade the programme out (touch "pause") */
static double g_mgain = 1.0;            /* current mute gain, ramped over about 60 ms */

/* CH-BEGIN (compiled out of this file by the host test, tests/run_tests_dsp.sh) */
/*
 * dsp.conf channels=stereo|mono|left|right. A matrix on the programme in front of the DSP:
 * mid += ch_b * side, side *= ch_d (stereo 0/1, mono 0/0, left 1/0, right -1/0), moved linearly
 * over 20 ms on a change. At stereo, once settled, it is out of the path (g_ch_on = 0).
 */
#define CH_RAMP 960
static int g_chan, g_ch_n, g_ch_on;     /* mode; samples left in the ramp; matrix in the path */
static double g_ch_b, g_ch_d = 1.0, g_ch_bt, g_ch_dt = 1.0, g_ch_db, g_ch_dd;

static const char *const chan_name[4] = { "stereo", "mono", "left", "right" };

static void ch_set(int mode)
{
	if (mode == g_chan)
		return;
	g_chan = mode;
	g_ch_bt = mode == 2 ? 1.0 : mode == 3 ? -1.0 : 0.0;
	g_ch_dt = mode == 0 ? 1.0 : 0.0;
	g_ch_db = (g_ch_bt - g_ch_b) / CH_RAMP;
	g_ch_dd = (g_ch_dt - g_ch_d) / CH_RAMP;
	g_ch_n = CH_RAMP;
	g_ch_on = 1;
}

static inline void ch_run(double *m, double *s)
{
	if (g_ch_n) {
		g_ch_b += g_ch_db; g_ch_d += g_ch_dd;
		if (--g_ch_n == 0) {
			g_ch_b = g_ch_bt; g_ch_d = g_ch_dt;
			g_ch_on = !(g_ch_b == 0.0 && g_ch_d == 1.0);
		}
	}
	*m += g_ch_b * *s;
	*s *= g_ch_d;
}

/*
 * A multichannel source (-c 8: FL FR C LFE SL SR HL HR, what a HomePod asks an AirPlay sender for)
 * adds three programme signals to mid and side, per sample: g_x[0] = C + LFE, g_x[1] / g_x[2] = what
 * the surround and height channels put on the left / right speaker feed (hpxtc.h). ext_mix() gives
 * them to this speaker's role the way Apple's beamMix presets do (b238a_speaker_{solo,lt,rt}_*):
 *   g_et   added to everything (the woofer, and the direct beam of a free-standing speaker)
 *   g_ed   added to the direct beam near a wall / on a shelf
 *   g_ea1, g_ea2   the two ambient beams there
 * all in the "L + R" scale (twice the mid). A left / right speaker of a pair plays its own side at
 * twice the level, like channels=left|right does with the front pair.
 */
static float g_mix[8];                   /* dsp.conf mix=: gains for FL FR C LFE SL SR HL HR; */
static int g_mix_on;                    /* the sum plays as this speaker's one channel (no ambience, no surround stage) */
static float g_mixc[3][8];              /* [1] mix_stereo=, [2] mix_surround=: the same, for streams without sound in that channel */
static int g_mixc_on[3];
static unsigned char g_class0;
static volatile unsigned char *g_class = &g_class0;   /* /run/homepod/feed.class: 0 bed, 1 stereo, 2 surround */
static double g_x[3], g_et, g_ed, g_ea1, g_ea2;
static uint64_t g_t_conf, g_t_pump, g_t_sleep, g_t_dsp;   /* the last loop iteration, for the underrun report */
static uint64_t g_t_read; static int g_t_read_src, g_t_read_n;   /* the longest read() in it, its source and result */
static int g_has_mc;                    /* a multichannel source is attached */

static inline void ext_mix(void)
{
	const double c = g_x[0], ul = g_x[1], ur = g_x[2];

	switch (g_chan) {
	case 1:  g_et = g_ed = c + ul + ur; g_ea1 = g_ea2 = 0.0; break;                    /* mono: no ambience */
	case 2:  g_et = 2.0 * (c + ul); g_ed = 2.0 * c; g_ea1 = g_ea2 = 2.0 * ul; break;   /* left of a pair */
	case 3:  g_et = 2.0 * (c + ur); g_ed = 2.0 * c; g_ea1 = g_ea2 = 2.0 * ur; break;   /* right of a pair */
	default: g_et = c + ul + ur; g_ed = c; g_ea1 = ul; g_ea2 = ur; break;
	}
	/* near a wall Apple gives a pair's left speaker only the first ambient beam and its right speaker only
	 * the second (the 'ca' gains in b238a_speaker_lt_wall / rt_wall); on a shelf both stay on */
	if (g_position == 1) {
		if (g_chan == 2) g_ea2 = 0.0;
		else if (g_chan == 3) g_ea1 = 0.0;
	}
}

/* eqN=<peak|lowshelf|highshelf>,<Hz>,<dB>,<Q> or off; numbers are clamped to the documented ranges */
static void eq_band_parse(const char *v, struct a3_eqband *b)
{
	char *e;
	double f, g, q;
	int t = !strncmp(v, "peak,", 5) ? A3_EQ_PEAK : !strncmp(v, "lowshelf,", 9) ? A3_EQ_LOWSHELF :
		!strncmp(v, "highshelf,", 10) ? A3_EQ_HIGHSHELF : A3_EQ_OFF;

	memset(b, 0, sizeof(*b));
	if (t == A3_EQ_OFF)
		return;
	v = strchr(v, ',') + 1;
	f = strtod(v, &e); if (*e != ',') return;
	g = strtod(e + 1, &e); if (*e != ',') return;
	q = strtod(e + 1, &e); if (*e && *e != ' ') return;
	if (!(f >= 20.0)) f = 20.0;                     /* also catches NaN */
	if (f > 20000.0) f = 20000.0;
	if (!(g >= -12.0)) g = -12.0;
	if (g > 6.0) g = 6.0;
	if (!(q >= 0.3)) q = 0.3;
	if (q > 10.0) q = 10.0;
	b->type = t; b->f = f; b->g = g; b->q = q;
}
/* CH-END */

static int profile_id(const char *v)
{
	return !strcmp(v, "flat") ? 0 : !strcmp(v, "apple3") ? 3 : !strcmp(v, "apple2") ? 2 : 1;
}

static void dsp_apply(void)
{
	/*
	 * loud=auto: the loudness curve follows the volume. Apple (AULoudnessWarrior in the VAD
	 * graph): position = volume dB + 7, clamped to the anchors. With apple3 the volume is the
	 * input gain (aref); with the older profiles it is the amplifier volume.
	 */
	double loud = g_loud_auto ? (g_profile == 3 && g_a3_init ? g_a3.aref_db : g_volume_db) + g_loud_ref : g_loud;

	dsp_configure(&g_dsp, g_position, loud, g_subsonic, g_wdb, g_tdb, g_twdelay);
	if (!g_a2_init) {
		a2_defaults(&g_a2.cfg);
		/*
		 * "Front" is the tweeter opposite the power cord: TDM slot 4, three steps of
		 * 360/7 degrees from slot 1 (confirmed on the pod with solo=4). Without this
		 * the stereo image is centred on a rear tweeter. dsp.conf front= overrides it.
		 */
		g_a2.cfg.front_deg = 3.0 * 360.0 / 7.0;
		a2_clear(&g_a2);
		g_a2_init = 1;
	}
	g_a2.cfg.position = g_position;
	g_a2.cfg.loud_db = loud;
	g_a2.cfg.subsonic_hz = g_subsonic;
	g_a2.cfg.woofer_db = g_wdb;
	g_a2.cfg.tweeter_db = g_tdb;
	g_a2.cfg.tw_delay = g_twdelay;
	g_a2.cfg.volume_db = g_volume_db;
	if (g_profile != 3)                     /* apple3 configures its own copy below */
		a2_configure(&g_a2);
	if (!g_a3_init) {
		a3_defaults(&g_a3);
		a3_clear(&g_a3);
		g_a3_init = 1;
	}
	if (g_profile == 3) {                   /* apple3 shares every apple2 setting */
		g_a3.a.cfg = g_a2.cfg;
		g_a3.a.cfg.surround = g_has_mc;         /* wall / shelf: Apple's three separately fed beams */
		a3_configure(&g_a3);
	}
}

static void dsp_reload(int verbose)
{
	static time_t last_m;
	static long last_ns;
	struct stat st;
	char line[128];
	FILE *f;
	struct a3_eqset es;             /* eq keys: a missing key is "off" */
	int chan = 0, eq_new, mix_seen = 0;       /* a missing mix= is "off" */
	int mixc_seen[3] = { 0, 0, 0 };

	if (stat(DSPCONF, &st) || (st.st_mtime == last_m && st.st_mtim.tv_nsec == last_ns))
		return;
	last_m = st.st_mtime; last_ns = st.st_mtim.tv_nsec;
	f = fopen(DSPCONF, "r");
	if (!f)
		return;
	memset(&es, 0, sizeof(es));
	while (fgets(line, sizeof(line), f)) {
		char *v = strchr(line, '=');
		double x;

		if (!v) continue;
		*v++ = 0;
		v[strcspn(v, "\r\n")] = 0;
		x = atof(v);
		if (!strcmp(line, "profile")) {
			int np = profile_id(v);
			if (np == 2 && g_profile != 2 && g_a2_init)
				a2_clear(&g_a2);            /* stale filter state */
			if (np == 3 && g_profile != 3 && g_a3_init)
				a3_clear(&g_a3);
			g_profile = np;
		}
		else if (!strcmp(line, "position")) g_position = !strcmp(v, "wall") ? 1 : !strcmp(v, "book") ? 2 : 0;
		else if (!strcmp(line, "loud")) {
			g_loud_auto = !strcmp(v, "auto");
			if (!g_loud_auto) g_loud = !strcmp(v, "off") ? 1000.0 : x;
		}
		else if (!strcmp(line, "volume_db") && x >= -80 && x <= 0) g_volume_db = x;
		else if (!strcmp(line, "loud_ref") && x >= -30 && x <= 30) g_loud_ref = x;
		else if (!strcmp(line, "mute")) g_mute = x != 0;
		else if (!strcmp(line, "front") && x >= -360 && x <= 360) g_a2.cfg.front_deg = x;
		else if (!strcmp(line, "order") && strlen(v) == A2_NDRV) {
			int seen = 0, k;
			for (k = 0; k < A2_NDRV; k++)
				if (v[k] >= '1' && v[k] <= '7') seen |= 1 << (v[k] - '1');
			if (seen == 0x7f)
				for (k = 0; k < A2_NDRV; k++) g_a2.cfg.order[k] = v[k] - '1';
		}
		else if (!strcmp(line, "solo") && x >= 0 && x <= 7) g_a2.cfg.solo = (int)x;
		else if (!strcmp(line, "drc")) g_a2.cfg.drc = x != 0;
		else if (!strcmp(line, "limit")) g_a2.cfg.limit = x != 0;
		else if (!strcmp(line, "guard")) g_a2.cfg.guard = x != 0;
		else if (!strcmp(line, "bass_reduce")) g_a2.cfg.bass_reduce = x != 0;
		else if (!strcmp(line, "tw_invert")) g_a2.cfg.tw_invert = x != 0;
		else if (!strcmp(line, "effort") && x >= 0 && x <= 1) g_a2.cfg.effort = x;
		else if (!strcmp(line, "xlim") && x >= 1 && x <= 8) g_a2.cfg.xlim_mm = x;
		else if (!strcmp(line, "ambient_db") && x >= -40 && x <= 6) g_a2.cfg.ambient_db = x;
		else if (!strcmp(line, "out_db") && x >= -40 && x <= 0) g_a2.cfg.out_db = x;
		else if (!strcmp(line, "wdelay") && x >= 0 && x < A2_DLY) g_a2.cfg.wf_delay = (int)x;
		else if (!strcmp(line, "aref") && x >= -90 && x <= 0) g_a3.aref_db = x;        /* apple3 only */
		else if (!strcmp(line, "xlim3") && x >= 1 && x <= 8) g_a3.xlim_mm = x;
		else if (!strcmp(line, "power")) g_a3.power = x != 0;
		else if (!strcmp(line, "pbudget") && x >= 10 && x <= 60) g_a3.pbudget_w = x;
		else if (!strcmp(line, "woofer_db") && x >= -40 && x <= 12) g_wdb = x;
		else if (!strcmp(line, "tweeter_db") && x >= -40 && x <= 12) g_tdb = x;
		else if (!strcmp(line, "delay") && x >= 0 && x < DSP_MAXDELAY) g_twdelay = (int)x;
		else if (!strcmp(line, "subsonic") && x >= 20 && x <= 120) g_subsonic = x;
		else if (!strcmp(line, "sync_ms") && x >= -150 && x <= 300) g_sync_trim = x / 1000.0;
		else if (!strcmp(line, "mix") || !strcmp(line, "mix_stereo") || !strcmp(line, "mix_surround")) {
			float t[8], *dst = !line[3] ? g_mix : g_mixc[line[5] == 't' ? 1 : 2];

			if (sscanf(v, "%f,%f,%f,%f,%f,%f,%f,%f", &t[0], &t[1], &t[2], &t[3], &t[4], &t[5], &t[6], &t[7]) == 8) {
				int k;

				for (k = 0; k < 8; k++) dst[k] = t[k] < -4.0f ? -4.0f : t[k] > 4.0f ? 4.0f : t[k];
				if (!line[3]) mix_seen = 1; else mixc_seen[line[5] == 't' ? 1 : 2] = 1;
			}
		}
		else if (!strcmp(line, "channels"))
			chan = !strcmp(v, "mono") ? 1 : !strcmp(v, "left") ? 2 : !strcmp(v, "right") ? 3 : 0;
		else if (!strcmp(line, "eq")) es.on = x != 0;
		else if (!strcmp(line, "eq_pre")) es.pre_db = !(x >= -12) ? -12 : x > 0 ? 0 : x;     /* also NaN */
		else if (line[0] == 'e' && line[1] == 'q' && line[2] >= '0' && line[2] <= '9' && !line[3])
			eq_band_parse(v, &es.b[line[2] - '0']);
	}
	fclose(f);
	dsp_apply();
	/* user EQ: redesigned (ten sections at most) only when its keys changed; ramps, no step */
	eq_new = a3_eq_set(&g_a3.eq, &es);
	if (verbose && (eq_new || chan != g_chan)) {
		int k, nb = 0;

		for (k = 0; k < A3_EQ_N; k++)
			nb += es.b[k].type != A3_EQ_OFF && es.b[k].g != 0.0;
		fprintf(stderr, "hpfeed: eq=%d pre=%gdB bands=%d channels=%s\n", es.on, es.pre_db, es.on ? nb : 0, chan_name[chan]);
	}
	ch_set(chan);
	g_mix_on = mix_seen;
	g_mixc_on[1] = mixc_seen[1]; g_mixc_on[2] = mixc_seen[2];
	if (verbose) {
		/* say it once per real change: the volume (aref) and the loudness position that
		 * follows it move with every step of a slider and are not listed */
		static char last[320];
		char now[320], loud[24];

		if (g_loud_auto) snprintf(loud, sizeof(loud), "auto");
		else snprintf(loud, sizeof(loud), "%g", g_a2.cfg.loud_db);
		snprintf(now, sizeof(now), "hpfeed: dsp profile=%s position=%d loud=%s woofer=%+gdB tweeter=%+gdB delay=%d subsonic=%gHz "
			"volume=%gdB front=%g solo=%d drc=%d limit=%d guard=%d effort=%g beams=%d mute=%d\n",
			g_profile == 3 ? "apple3" : g_profile == 2 ? "apple2" : g_profile ? "apple" : "flat", g_position,
			loud, g_wdb, g_tdb, g_twdelay, g_subsonic, g_volume_db, g_a2.cfg.front_deg, g_a2.cfg.solo,
			g_a2.cfg.drc, g_a2.cfg.limit, g_a2.cfg.guard, g_a2.cfg.effort, g_a2.nf, g_mute);
		if (strcmp(now, last)) {
			fputs(now, stderr);
			strcpy(last, now);
		}
	}
}

/* M2-BEGIN
 * /run/homepod/meter2 (layout and reader rules: meter2.h), 15 times a second. Levels are
 * accumulated where they are produced: m2_in() on the mono mix next to meter_tap(), m2_drv()
 * on each of the eight output values in frame_from() (1 square-add and 1 compare each). The
 * protection figures come from a3_peek(), which resets nothing that the 5 s status line uses;
 * limiter hits are counted as differences of the counters that a3_meters() zeroes, and
 * m2_fold_hits() must run just before a3_meters() so that no hit is lost. Publishing is a
 * few dozen stores into the locked mapping: no system call. The host test (tests/run_tests_dsp.sh)
 * compiles this section out of this file. */
static volatile struct meter2 *g_meter2;
static struct {
	double in_s2, in_pk, s2[8], pk[8];
	int ni, nd, frames;
	long prev_w, prev_t, pend_w, pend_t;   /* limiter hit counters as last seen, and hits folded in */
} g_m2;

static volatile struct meter2 *m2_open(const char *path)
{
	int fd = open(path, O_RDWR | O_CREAT, 0644);
	void *p = MAP_FAILED;

	if (fd < 0)
		return NULL;
	if (ftruncate(fd, sizeof(struct meter2)) == 0) {
		p = mmap(NULL, sizeof(struct meter2), PROT_READ | PROT_WRITE, MAP_SHARED, fd, 0);
		if (p != MAP_FAILED) {
			memset(p, 0, sizeof(struct meter2));      /* also faults the page in */
			((struct meter2 *)p)->version = METER2_VERSION;
		}
	}
	close(fd);
	return p == MAP_FAILED ? NULL : p;
}

static inline void m2_in(double x)
{
	double a = fabs(x);

	g_m2.in_s2 += x * x;
	if (a > g_m2.in_pk) g_m2.in_pk = a;
	g_m2.ni++;
}

static inline void m2_drv(int k, double v)
{
	double a = fabs(v);

	g_m2.s2[k] += v * v;
	if (a > g_m2.pk[k]) g_m2.pk[k] = a;
}

static long m2_hits(int tw)
{
	long n = 0;
	int k;

	if (!tw) return g_a3.cf[0].hits;
	for (k = 1; k < 8; k++) n += g_a3.cf[k].hits;
	return n;
}

static void m2_fold_hits(void)                 /* a3_meters() is about to zero the counters */
{
	long w = m2_hits(0), t = m2_hits(1);

	g_m2.pend_w += w >= g_m2.prev_w ? w - g_m2.prev_w : w;
	g_m2.pend_t += t >= g_m2.prev_t ? t - g_m2.prev_t : t;
	g_m2.prev_w = g_m2.prev_t = 0;
}

/* once per METER2_PERIOD frames; fifo_min_words / stall_us are the loop's figures for the period */
static void m2_publish(volatile struct meter2 *m, int playing, long underruns, int fifo_min_words, double stall_us)
{
	double nd = g_m2.nd > 0 ? g_m2.nd : 1, ni = g_m2.ni > 0 ? g_m2.ni : 1;
	long w = 0, t = 0;
	uint32_t seq;
	int k;

	if (g_profile == 3) {
		long cw = m2_hits(0), ct = m2_hits(1);

		w = g_m2.pend_w + (cw >= g_m2.prev_w ? cw - g_m2.prev_w : cw);
		t = g_m2.pend_t + (ct >= g_m2.prev_t ? ct - g_m2.prev_t : ct);
		g_m2.prev_w = cw; g_m2.prev_t = ct;
	}
	g_m2.pend_w = g_m2.pend_t = 0;
	if (m) {
		seq = m->seq | 1;
		m->seq = seq;
		__sync_synchronize();
		m->version = METER2_VERSION;
		m->playing = playing ? 1 : 0;
		m->profile = (uint32_t)g_profile;
		m->in_rms = (float)sqrt(g_m2.in_s2 / ni);
		m->in_peak = (float)g_m2.in_pk;
		for (k = 0; k < 8; k++) {
			m->drv_rms[k] = (float)sqrt(g_m2.s2[k] / nd);
			m->drv_peak[k] = (float)(g_m2.pk[k] < g_ceiling ? g_m2.pk[k] : g_ceiling);
		}
		if (g_profile == 3) {
			struct a3_peekv v;

			a3_peek(&g_a3, &v);
			for (k = 0; k < 4; k++) m->drc_db[k] = (float)v.gr[k];
			m->hp_hz = (float)v.hp; m->x_ask_mm = (float)v.xask; m->x_out_mm = (float)v.xout;
			m->xlim_mm = (float)v.xlim; m->p48_w = (float)v.p48; m->p12_w = (float)v.p12;
			m->pavg_w = (float)v.pavg; m->budget_w = (float)v.budget; m->effort = (float)v.effort;
			m->pg_w = (float)v.gw; m->pg_t = (float)v.gt; m->slow = (float)v.slow;
		} else {
			for (k = 0; k < 4; k++) m->drc_db[k] = 0.0f;
			m->hp_hz = m->x_ask_mm = m->x_out_mm = m->xlim_mm = m->p48_w = m->p12_w = 0.0f;
			m->pavg_w = m->budget_w = m->effort = m->pg_w = m->pg_t = m->slow = 0.0f;
		}
		m->lim_w = (uint32_t)w;
		m->lim_t = (uint32_t)t;
		m->aref_db = (float)(g_profile == 3 ? g_a3.aref_db : g_volume_db);
		m->muted = g_mute ? 1.0f : 0.0f;
		m->underruns = (uint32_t)underruns;
		m->fifo_min = (uint32_t)(fifo_min_words < 0 ? 0 : fifo_min_words / 8);
		m->max_stall_us = (uint32_t)(stall_us + 0.5);
		m->eq_on = g_a3.eq.set.on && g_profile >= 2 ? 1.0f : 0.0f;
		m->sync_err_ms = g_sync_err_ms;
		m->sync_wait_ms = g_sync_wait_ms;
		for (k = 0; k < 6; k++) m->reserved[k] = 0.0f;
		__sync_synchronize();
		m->seq = seq + 1;
	}
	memset(&g_m2, 0, offsetof(__typeof__(g_m2), prev_w));   /* levels and counts; keep the hit bookkeeping */
}
/* M2-END */

/* one sample, x = (L+R)/2 and sd = (L-R)/2, each -1..1 -> one 8-word frame */
static inline void frame_from(double x, double sd, uint32_t *w)
{
	double lo, hi;
	uint32_t t;
	int i;

	if (g_profile >= 2) {
		double tw[A2_NDRV];

		if (g_profile == 3) {                                    /* user EQ inside, after the input gain */
			if (g_a3.a.cfg.surround && g_a3.a.cfg.position != 0 && !g_a3.a.cfg.solo)
				a3_run_sur(&g_a3, 2.0 * x + g_et, 2.0 * x + g_ed, 2.0 * sd + g_ea1, g_ea2 - 2.0 * sd, &lo, tw);
			/* (near a wall, a member of a pair has only its outward ambient beam: ext_mix) */
			else
				a3_run(&g_a3, g_et != 0.0 ? x + 0.5 * g_et : x, sd, &lo, tw);
		} else {
			if (g_et != 0.0) x += 0.5 * g_et;
			if (g_a3.eq.run) {              /* apple2 has no input gain: the EQ goes first */
				double xs[2] = { x, sd };

				a3_eq_run(&g_a3.eq, xs);
				x = xs[0]; sd = xs[1];
			}
			a2_run(&g_a2, x, sd, &lo, tw);
		}
		lo *= g_woofer;
		m2_drv(0, lo);
		w[0] = (uint32_t)to_word(lo);
		for (i = 1; i < SLOTS; i++) {
			double v = tw[i - 1] * g_tweeter;

			m2_drv(i, v);
			w[i] = (uint32_t)to_word(v);
		}
		g_m2.nd++;
		return;
	}
	if (g_et != 0.0) x += 0.5 * g_et;
	if (g_profile) {
		dsp_run(&g_dsp, x, &lo, &hi);
		lo *= g_woofer;
		hi *= g_tweeter;
	} else {
		/*
		 * The old sound at the old loudness, for comparison. It was tuned
		 * with the amplifiers at -12 dB (tweeters) / -20 dB (woofer) and a
		 * -10 dB trim; the amplifiers now sit at a common master volume
		 * (-10 dB by default), so the difference is applied here. Without
		 * it the unequalised tweeters would come up about 30 dB louder
		 * than in the Apple profile.
		 */
		lo = bq(&w_lp2, bq(&w_lp1, bq(&w_sub, x))) * g_woofer * 0.1;      /* -20 dB */
		hi = bq(&t_hp2, bq(&t_hp1, x)) * g_tweeter * 0.2512;              /* -12 dB */
	}
	t = (uint32_t)to_word(hi);

	w[0] = (uint32_t)to_word(lo);
	for (i = 1; i < SLOTS; i++)
		w[i] = t;
	m2_drv(0, lo);
	for (i = 1; i < SLOTS; i++)
		m2_drv(i, hi);
	g_m2.nd++;
}

/* ------------------------------------------------------------------ input */
/*
 * Up to MAXSRC PCM sources (AirPlay FIFO, Bluetooth FIFO, ...). Each has its
 * own ring, resampler and rate servo; whatever is playing is summed.
 */
#define RING   (1 << 17)
#define MAXSRC 4

struct src {
	const char *path, *ratefile;       /* ratefile: re-read when a stream starts */
	int fd, ch, rate;
	float *ring, *sring;               /* mid (L+R)/2 and side (L-R)/2 */
	/* -c 8: a helper thread moves the FIFO into this byte ring (single writer, single reader) */
	unsigned char *tb;
	volatile unsigned tb_w, tb_r;
	pthread_t thr;
	float *xr[5];                      /* -c 8 only: C+LFE (aligned), then SL SR HL HR as they came */
	struct xtc *xtc;
	unsigned head, tail, last_head;    /* write / read positions */
	unsigned char rem[8];
	int remn;
	double pos, step, adj, fade;
	int playing, announced;
	unsigned prebuf;
	uint64_t last_in, wake_t0, next_amp;
	long starved;
	/* sync source (-S): see "sources that are clocked by their sender" below */
	int sync, pre_ok, resnap;
	double lead;                       /* seconds from a packet's arrival to the moment it is due */
	unsigned target;                   /* samples a packet has to wait in the ring to be on time */
	unsigned hold;                     /* output samples of inserted silence still to go */
	double pre_avg, integ, want;       /* smoothed wait (samples); PI state */
	uint64_t last_push, last_pkt;
	long snaps;
};
static struct src srcs[MAXSRC];
static int nsrc;

static inline unsigned s_fill(const struct src *s) { return (s->head - s->tail) & (RING - 1); }

/* SYNC-BEGIN
 * Sources that are clocked by their sender (-S MS; AirPlay).
 *
 * The receiver (shairport-sync, pipe backend) hands over every packet exactly MS milliseconds
 * before the moment its first frame has to be HEARD: general.audio_backend_buffer_desired_length
 * in its configuration, which must be the same figure. The frame is on time if it waits in the
 * ring for
 *     MS  -  the DSP chain  -  the hardware FIFO  +  dsp.conf sync_ms (a trim, default 0)
 * so that wait is controlled here, to a fraction of a millisecond, instead of "about 150 ms":
 *  - the wait is measured where it is defined: the ring's fill just before a packet is pushed;
 *  - a stream starts on a packet boundary with exactly that wait (older audio, normally the
 *    receiver's lead-in silence, is dropped);
 *  - while it plays, a PI loop on the smoothed wait trims the resampler by at most 0.5 %; that
 *    also absorbs the difference between the sender's clock and ours for good (no residual
 *    offset: the integrator carries the drift);
 *  - an error of more than 40 ms, or a change of the trim, is not chased but corrected at once:
 *    skip ahead, or insert silence, with a 20 ms fade-in.
 * Other sources (Bluetooth) keep the plain "about 150 ms" buffer further down.
 */
#define SYNC_HW      10                 /* frames in the hardware FIFO on average (7..14) */
#define SYNC_KP      0.4                /* 1/s */
#define SYNC_KI      0.04               /* 1/s^2 */
#define SYNC_SNAP    0.040              /* seconds */

static int amp_ready(void);

static int dsp_latency(void)            /* frames at 48 kHz, input of the chain to the DAC */
{
	return g_profile == 3 ? 1288 : g_profile ? 256 : 0;
}

static void src_sync_target(struct src *s)
{
	double t, lo, hi;
	unsigned n;

	if (!s->sync)
		return;
	t = (s->lead + g_sync_trim) * s->rate - (dsp_latency() + SYNC_HW) * s->step - 1.0 - (s->xtc ? XTC_DELAY : 0);
	lo = 0.02 * s->rate; hi = 0.5 * s->rate;
	n = (unsigned)(t < lo ? lo : t > hi ? hi : t);
	if (n != s->target) {
		if (s->target && s->playing && (n > s->target ? n - s->target : s->target - n) > (unsigned)(0.005 * s->rate))
			s->resnap = 1;
		s->target = n;
	}
}

/* correct the wait by e samples at once (e > 0: too much is waiting) */
static void src_snap(struct src *s, double e)
{
	if (e > 0) {
		unsigned n = (unsigned)(e + 0.5), f = s_fill(s);

		if (n + 8 > f) n = f > 8 ? f - 8 : 0;
		s->tail = (s->tail + n) & (RING - 1);
	} else {
		s->hold = (unsigned)(-e / s->step + 0.5);
	}
	s->fade = 0.0;
	s->pre_avg = s->target;
	s->resnap = 0;
	s->snaps++;
}

/* one packet has been pushed; `pre` = the ring's fill before it, `frames` its length */
static void src_sync_packet(struct src *s, unsigned pre, int frames, uint64_t now)
{
	int cont = s->last_push && now - s->last_push < tfreq / 500;   /* rest of a packet the pipe split */
	double a, e, dt;

	s->last_push = now;
	if (cont)
		return;
	if (!s->playing) {
		unsigned hb = (s->head - (unsigned)frames) & (RING - 1);

		if (pre < s->target)
			return;                                   /* still collecting */
		if (now >= s->next_amp) {
			s->next_amp = now + tfreq / 50;
			if (amp_ready() || now - s->wake_t0 > 3 * tfreq) {
				s->tail = (hb - s->target) & (RING - 1);   /* this packet waits exactly `target` */
				s->playing = 1; s->pos = 0.0; s->fade = 0.0; s->hold = 0;
				s->pre_avg = s->target; s->pre_ok = 1; s->resnap = 0;
				s->want = s->adj = s->integ;              /* the drift learned so far */
				s->last_pkt = now;
				return;
			}
		}
		if (pre > s->target + (unsigned)(s->rate * 0.3))      /* amplifiers not up yet: stay close to live */
			s->tail = (hb - s->target) & (RING - 1);
		return;
	}
	dt = (double)(now - s->last_pkt) / (double)tfreq;
	s->last_pkt = now;
	if (s->hold)
		return;                                           /* silence is being inserted: the wait is in motion */
	a = frames * (s->xtc ? 4 : 1) / (0.3 * s->rate);      /* a multichannel block arrives in quarters */
	if (a > 1.0) a = 1.0;
	if (!s->pre_ok) { s->pre_avg = pre; s->pre_ok = 1; }
	else s->pre_avg += ((double)pre - s->pre_avg) * a;
	e = s->pre_avg - (double)s->target;
	g_sync_err_ms = (float)(e * 1000.0 / s->rate);
	g_sync_wait_ms = (float)(s->target * 1000.0 / s->rate);
	if (s->resnap || fabs(e) > SYNC_SNAP * s->rate) {
		src_snap(s, e);
		g_sync_err_ms = 0.0f;
		return;
	}
	e /= s->rate;                                         /* seconds */
	if (dt > 0.1) dt = 0.1;
	s->integ += SYNC_KI * e * dt;
	if (s->integ > 0.003) s->integ = 0.003;
	if (s->integ < -0.003) s->integ = -0.003;
	s->want = SYNC_KP * e + s->integ;
	if (s->want > 0.005) s->want = 0.005;
	if (s->want < -0.005) s->want = -0.005;
}
/* SYNC-END */

static void src_set_rate(struct src *s, int rate)
{
	if (rate < 8000 || rate > 96000)
		return;
	s->rate = rate;
	s->step = (double)rate / 48000.0;
	s->prebuf = (unsigned)(rate * 0.15);
	src_sync_target(s);
}

static void src_reload_rate(struct src *s)
{
	char b[16] = "";
	int fd, n;

	if (!s->ratefile)
		return;
	fd = open(s->ratefile, O_RDONLY);
	if (fd < 0)
		return;
	n = read(fd, b, sizeof(b) - 1);
	close(fd);
	if (n > 0 && atoi(b) != s->rate) {
		src_set_rate(s, atoi(b));
		fprintf(stderr, "hpfeed: %s now %d Hz\n", s->path, s->rate);
	}
}

#define TBUF (1u << 20)                 /* bytes; 1.4 s of 8-channel audio */

/* A stream without sound for this speaker's channel (stereo music and a height speaker, say): its one channel is
 * made from what there is, g_mixc[cls]. The feeder applies mix= afterwards, so every channel of the frame gets
 * m / sum(mix): mix= of that is m again. */
static void class_remix(unsigned char *p, int frames, int cls)
{
	float gs = 0.0f, g[8];
	int c, i;

	for (c = 0; c < 8; c++) { gs += g_mix[c]; g[c] = g_mixc[cls][c]; }
	if (gs < 1e-4f)
		return;
	for (c = 0; c < 8; c++) g[c] /= gs;
	for (i = 0; i < frames; i++, p += 16) {
		float m = 0.0f;
		int v;

		for (c = 0; c < 8; c++)
			m += g[c] * (float)(int16_t)(p[2 * c] | (p[2 * c + 1] << 8));
		v = (int)lrintf(m);
		v = v > 32767 ? 32767 : v < -32768 ? -32768 : v;
		for (c = 0; c < 8; c++) { p[2 * c] = (unsigned char)v; p[2 * c + 1] = (unsigned char)(v >> 8); }
	}
}

static void *src_reader(void *arg)
{
	struct src *s = arg;
	struct sched_param sp = { 0 };
	cpu_set_t cs;
	unsigned char tmp[4096 + 16];
	int carry = 0;                          /* bytes of a frame that has not arrived completely (8 channels only) */

	/* an ordinary thread on the other core: nothing in here may hold up the feeder */
	pthread_setschedparam(pthread_self(), SCHED_OTHER, &sp);
	CPU_ZERO(&cs); CPU_SET(0, &cs);
	pthread_setaffinity_np(pthread_self(), sizeof(cs), &cs);
	while (!g_stop) {
		struct pollfd pf = { s->fd, POLLIN, 0 };
		unsigned w, room, k;
		int n;

		if (poll(&pf, 1, 200) <= 0)
			continue;
		w = s->tb_w;
		room = TBUF - 1 - ((w - s->tb_r) & (TBUF - 1));
		if (room < sizeof(tmp)) { usleep(1000); continue; }        /* never in practice: the feeder empties it every 0.5 ms */
		n = read(s->fd, tmp + carry, 4096);
		if (n <= 0)
			continue;
		n += carry; carry = 0;
		if (s->ch == 8) {
			int cls = *g_class;             /* read after the data: the relay sets it before it writes a block */

			carry = n & 15; n -= carry;     /* whole frames only */
			if (g_mix_on && (cls == 1 || cls == 2) && g_mixc_on[cls])
				class_remix(tmp, n / 16, cls);
		}
		k = TBUF - w < (unsigned)n ? TBUF - w : (unsigned)n;
		memcpy(s->tb + w, tmp, k);
		memcpy(s->tb, tmp + k, (unsigned)n - k);
		__atomic_store_n(&s->tb_w, (w + (unsigned)n) & (TBUF - 1), __ATOMIC_RELEASE);
		if (carry)
			memmove(tmp, tmp + n, carry);
	}
	return NULL;
}

/* what read() would give, from the helper thread's ring */
static int src_take(struct src *s, unsigned char *dst, unsigned max)
{
	unsigned r = s->tb_r, w = __atomic_load_n(&s->tb_w, __ATOMIC_ACQUIRE), have = (w - r) & (TBUF - 1), k;

	if (!have)
		return 0;
	if (have > max) have = max;
	k = TBUF - r < have ? TBUF - r : have;
	memcpy(dst, s->tb + r, k);
	memcpy(dst + k, s->tb, have - k);
	__atomic_store_n(&s->tb_r, (r + have) & (TBUF - 1), __ATOMIC_RELEASE);
	return (int)have;
}

static void pump_input(struct src *s, uint64_t now)
{
	static unsigned char buf[16384 + 8];
	int bps = 2 * s->ch, n, i, c, frames;
	unsigned space = RING - 1 - s_fill(s), pre = s_fill(s);

	if (s->fd < 0 || space < 8192)
		return;
	memcpy(buf, s->rem, s->remn);
	{
		uint64_t t0 = ticks(), t1;

		/* 8 channels: 256 frames a pass (src_sync_packet joins the pieces), and no system call */
		n = s->tb ? src_take(s, buf + s->remn, 4096) : (int)read(s->fd, buf + s->remn, 16384);
		t1 = ticks() - t0;
		if (t1 > g_t_read) { g_t_read = t1; g_t_read_src = (int)(s - srcs); g_t_read_n = n; }
	}
	if (n <= 0)
		return;
	n += s->remn;
	frames = n / bps;
	if (s->xtc) {                           /* FL FR C LFE SL SR HL HR */
		for (i = 0; i < frames; i++) {
			float in[8];

			for (c = 0; c < 8; c++)
				in[c] = (float)(int16_t)(buf[i * bps + 2 * c] | (buf[i * bps + 2 * c + 1] << 8)) / 32768.0f;
			if (g_mix_on) {
				float mm = 0.0f;

				for (c = 0; c < 8; c++) { mm += g_mix[c] * in[c]; in[c] = 0.0f; }
				in[0] = in[1] = mm;             /* like channels=left|right: the one channel, on the direct beam */
			}
			xtc_in(s->xtc, in, &s->ring[s->head], &s->sring[s->head], &s->xr[0][s->head]);
			s->xr[1][s->head] = in[4]; s->xr[2][s->head] = in[5]; s->xr[3][s->head] = in[6]; s->xr[4][s->head] = in[7];
			s->head = (s->head + 1) & (RING - 1);
		}
	} else
	for (i = 0; i < frames; i++) {
		int acc = 0;
		for (c = 0; c < s->ch; c++)
			acc += (int16_t)(buf[i * bps + 2 * c] | (buf[i * bps + 2 * c + 1] << 8));
		s->ring[s->head] = (float)acc / (32768.0f * s->ch);
		s->sring[s->head] = s->ch == 2 ? (float)((int16_t)(buf[i * bps] | (buf[i * bps + 1] << 8)) -
						       (int16_t)(buf[i * bps + 2] | (buf[i * bps + 3] << 8))) / 65536.0f : 0.0f;
		s->head = (s->head + 1) & (RING - 1);
	}
	s->remn = n - frames * bps;
	memcpy(s->rem, buf + frames * bps, s->remn);
	if (s->sync && frames > 0)
		src_sync_packet(s, pre, frames, now);
}

/* next output sample of one source (0 while it is not playing) */
static inline double src_sample(struct src *s, double *side)
{
	unsigned fill = s_fill(s);
	double v;
	int adv;

	if (!s->playing && !s->sync && fill >= s->prebuf) {
		uint64_t now = ticks();
		if (now >= s->next_amp) {
			s->next_amp = now + tfreq / 50;
			if (amp_ready() || now - s->wake_t0 > 3 * tfreq) {
				s->playing = 1; s->pos = 0.0; s->fade = 0.0;
			}
		}
		if (!s->playing && fill > 2 * s->prebuf)       /* stay close to live */
			s->tail = (s->head - s->prebuf) & (RING - 1);
	}
	if (s->playing && fill < 4) {
		s->playing = 0; s->starved++; s->fade = 0.0; s->wake_t0 = ticks();
		s->pre_ok = 0; s->hold = 0;
	}
	if (!s->playing)
		return 0.0;
	if (s->hold) {                         /* sync source: silence inserted to get back on time */
		s->hold--;
		return 0.0;
	}
	{
		/* 4-point Hermite resampler */
		float y0 = s->ring[s->tail], y1 = s->ring[(s->tail + 1) & (RING - 1)];
		float y2 = s->ring[(s->tail + 2) & (RING - 1)], y3 = s->ring[(s->tail + 3) & (RING - 1)];
		double c0 = y1, c1 = 0.5 * (y2 - y0);
		double c2 = y0 - 2.5 * y1 + 2.0 * y2 - 0.5 * y3;
		double c3 = 0.5 * (y3 - y0) + 1.5 * (y1 - y2);

		v = ((c3 * s->pos + c2) * s->pos + c1) * s->pos + c0;
	}
	if (g_profile >= 2 || g_ch_on || s->xtc) {   /* channels=left|right need the side in every profile */
		float y0 = s->sring[s->tail], y1 = s->sring[(s->tail + 1) & (RING - 1)];
		float y2 = s->sring[(s->tail + 2) & (RING - 1)], y3 = s->sring[(s->tail + 3) & (RING - 1)];
		double c0 = y1, c1 = 0.5 * (y2 - y0);
		double c2 = y0 - 2.5 * y1 + 2.0 * y2 - 0.5 * y3;
		double c3 = 0.5 * (y3 - y0) + 1.5 * (y1 - y2);
		double sv = ((c3 * s->pos + c2) * s->pos + c1) * s->pos + c0;

		*side += s->fade < 1.0 ? sv * s->fade : sv;
	}
	if (s->xtc) {                         /* C + LFE, and the surround / height channels through their filters */
		float xv[5];
		double ul, ur, f = s->fade < 1.0 ? s->fade : 1.0;
		int k;

		for (k = 0; k < 5; k++) {
			const float *r = s->xr[k];
			float y0 = r[s->tail], y1 = r[(s->tail + 1) & (RING - 1)];
			float y2 = r[(s->tail + 2) & (RING - 1)], y3 = r[(s->tail + 3) & (RING - 1)];
			double c0 = y1, c1 = 0.5 * (y2 - y0);
			double c2 = y0 - 2.5 * y1 + 2.0 * y2 - 0.5 * y3;
			double c3 = 0.5 * (y3 - y0) + 1.5 * (y1 - y2);

			xv[k] = (float)(((c3 * s->pos + c2) * s->pos + c1) * s->pos + c0);
		}
		xtc_out(s->xtc, g_chan >= 2, xv + 1, &ul, &ur);      /* a member of a pair uses the pair's filter set */
		g_x[0] += f * xv[0]; g_x[1] += f * ul; g_x[2] += f * ur;
	}
	if (s->fade < 1.0) { v *= s->fade; s->fade += 1.0 / 960.0; }
	s->pos += s->step * (1.0 + s->adj);
	adv = (int)s->pos;
	s->pos -= adv;
	s->tail = (s->tail + adv) & (RING - 1);
	return v;
}

/* keep about `prebuf` samples buffered: +-0.5 % at most */
static inline void src_servo(struct src *s)
{
	double err, want;

	if (!s->playing)
		return;
	if (s->sync) {                         /* the PI loop in src_sync_packet decides */
		s->adj += (s->want - s->adj) * 0.0005;
		if (s_fill(s) > s->target + (unsigned)(s->rate * 0.6))     /* cannot happen; never run away */
			s->tail = (s->head - s->target) & (RING - 1);
		return;
	}
	err = ((double)s_fill(s) - s->prebuf) / s->prebuf;
	want = err * 0.002;
	if (want > 0.005) want = 0.005;
	if (want < -0.005) want = -0.005;
	s->adj += (want - s->adj) * 0.0005;
	if (s_fill(s) > (unsigned)(s->rate * 0.6))             /* far too much: skip ahead */
		s->tail = (s->head - s->prebuf) & (RING - 1);
}

/* ------------------------------------------------- amplifier hand-shake */
#define FEED_STATE "/run/homepod/feed.state"   /* we write: play / idle */
#define AMP_STATE  "/run/homepod/amp.state"    /* homepod-audio.py writes: off / standby / active */

static void feed_state(const char *st)
{
	int fd = open(FEED_STATE, O_WRONLY | O_CREAT | O_TRUNC, 0644);

	if (fd >= 0) {
		if (write(fd, st, strlen(st)) < 0) { /* nothing useful to do */ }
		close(fd);
	}
}

/* 1 = amplifiers active, or nobody is managing them (no state file) */
static int amp_ready(void)
{
	char b[16] = "";
	int fd = open(AMP_STATE, O_RDONLY), n;

	if (fd < 0)
		return 1;
	n = read(fd, b, sizeof(b) - 1);
	close(fd);
	return n >= 6 && !memcmp(b, "active", 6);
}

/* ------------------------------------------------- level meter (display) */
/* METER-BEGIN
 * /run/homepod/meter: 32 bytes, little endian, rewritten 30 times a second:
 *   u32 seq      odd while the block is being rewritten (read again)
 *   u32 playing  1 while a source is playing
 *   f32 rms, peak            full band, linear, 1.0 = full scale
 *   f32 low, mid, high       rms below 250 Hz / 250 Hz..2 kHz / above 2 kHz
 *   f32 onset                0..1, how far this block jumps above the recent level
 * Measured on the mono programme before the DSP and before the master volume.
 * (AirPlay applies the sender's volume to the samples upstream of us, so
 * readers still have to normalise; "onset" is a ratio and needs no scaling.)
 * The file lives on tmpfs and is mapped and locked at start, so publishing
 * is a few stores: no system call, nothing that can block the audio loop. */
#define METER_FILE   "/run/homepod/meter"
#define METER_PERIOD 1600                  /* frames per update: 48000 / 30 */
#define METER_K_LOW  0.032195              /* 1 - exp(-2 pi 250 / 48000) */
#define METER_K_MID  0.230338              /* 1 - exp(-2 pi 2000 / 48000) */

struct meter_out { uint32_t seq, playing; float rms, peak, low, mid, high, onset; };
static volatile struct meter_out *g_meter;
static struct {
	double lp1, lp2;                   /* one-pole low-passes at 250 Hz and 2 kHz */
	double s_all, s_low, s_mid, s_high, peak;
	double avg;                        /* slow mean square, for the onset ratio */
	int n;
} g_m;

static void meter_open(void)
{
	int fd = open(METER_FILE, O_RDWR | O_CREAT, 0644);
	void *p;

	if (fd < 0)
		return;
	if (ftruncate(fd, sizeof(struct meter_out)) == 0) {
		p = mmap(NULL, sizeof(struct meter_out), PROT_READ | PROT_WRITE, MAP_SHARED, fd, 0);
		if (p != MAP_FAILED) {
			memset(p, 0, sizeof(struct meter_out));   /* also faults the page in */
			g_meter = p;
		}
	}
	close(fd);
}

/* once per output frame: 2 one-pole filters, 4 squares, 1 compare */
static inline void meter_tap(double x)
{
	double a = fabs(x), mi, hi;

	g_m.lp1 += METER_K_LOW * (x - g_m.lp1) + 1e-25;   /* the constant keeps denormals out */
	g_m.lp2 += METER_K_MID * (x - g_m.lp2) + 1e-25;
	mi = g_m.lp2 - g_m.lp1;
	hi = x - g_m.lp2;
	g_m.s_all += x * x;
	g_m.s_low += g_m.lp1 * g_m.lp1;
	g_m.s_mid += mi * mi;
	g_m.s_high += hi * hi;
	if (a > g_m.peak) g_m.peak = a;
	g_m.n++;
}

/* once per METER_PERIOD frames, after the FIFO has been filled */
static void meter_publish(int playing)
{
	volatile struct meter_out *m = g_meter;
	double n = g_m.n, ms = g_m.s_all / n, on = 0.0;
	uint32_t seq;

	/* onset: this block against the mean of the last ~0.3 s; scale-free.
	 * Sound starting out of digital silence counts as a full onset. */
	if (ms > 1e-9) {
		on = g_m.avg > 1e-10 ? (sqrt(ms / g_m.avg) - 1.25) * 0.8 : 1.0;
		if (on < 0.0) on = 0.0;
		if (on > 1.0) on = 1.0;
	}
	g_m.avg += 0.12 * (ms - g_m.avg);
	if (m) {
		seq = m->seq | 1;
		m->seq = seq;
		__sync_synchronize();
		m->playing = playing ? 1 : 0;
		m->rms = (float)sqrt(ms);
		m->peak = (float)g_m.peak;
		m->low = (float)sqrt(g_m.s_low / n);
		m->mid = (float)sqrt(g_m.s_mid / n);
		m->high = (float)sqrt(g_m.s_high / n);
		m->onset = (float)on;
		__sync_synchronize();
		m->seq = seq + 1;
	}
	g_m.s_all = g_m.s_low = g_m.s_mid = g_m.s_high = g_m.peak = 0.0;
	g_m.n = 0;
}
/* METER-END */

/* -------------------------------------------------------------------- main */
static void usage(void)
{
	fprintf(stderr,
"usage: hpfeed [options]\n"
"  -i PATH        PCM input (S16LE), may be given up to 4 times; inputs are mixed.\n"
"                 Default stdin. A FIFO is opened read/write.\n"
"  -r RATE        sample rate of the input named last (default 44100)\n"
"  -R FILE        ...or a file holding its rate, re-read whenever a stream starts\n"
"  -c CH          channels of the input named last (default 2)\n"
"  -S MS          the input named last is clocked by its sender (AirPlay): every packet\n"
"                 arrives MS ms before it is due; kept in sync (dsp.conf sync_ms trims)\n"
"  -p apple|apple2|apple3|flat  speaker tuning (apple3: pass 3, Apple's dynamics):\n"
"  -p apple|apple2|flat  speaker tuning: pass 1 (default), pass 2 (stereo, beams,\n"
"                 dynamics) or the old flat split\n"
"  -P free|wall|book  placement for the Apple tuning (default free)\n"
"  -L DB|off      loudness curve: playback level relative to reference (default -9)\n"
"  -D N           extra tweeter delay in samples (default 0)\n"
"  -H HZ          woofer subsonic high-pass (default 40)\n"
"  -x HZ          crossover frequency (default 2000)\n"
"  -W DB / -T DB  woofer / tweeter digital trim in dB (default 0)\n"
"  -l DBFS        hard limit (default -3)\n"
"  -t F:DBFS:SEC:WHERE  test tone instead of input; WHERE = w (woofer word only),\n"
"                 t (tweeter words only), a (through the crossover), or 0..7 (one word)\n"
"  -A N           run the alignment procedure N times, report, exit (silent)\n"
"  -s US          sleep this long when the FIFO is full (default 0 = busy poll)\n"
"  -q             no periodic statistics\n");
	exit(2);
}

int main(int argc, char **argv)
{
	int have_in = 0;
	double xover = 2000.0, limit_db = -3.0, wtrim = 0.0, ttrim = 0.0;
	double tone_f = 0, tone_db = -30, tone_s = 0;
	int tone_where = -2, align_test = 0, sleep_us = 0, quiet = 0, opt, fd;
	volatile uint32_t *pmgr;
	struct sched_param sp = { .sched_priority = 80 };
	cpu_set_t cs;

	if (!xtc_load(XTC_FILE))
		fprintf(stderr, "hpfeed: no %s: surround and height channels are played without the virtual-surround filters\n", XTC_FILE);
	{       /* the room relay's word on what kind of stream it is handing over */
		int cfd = open("/run/homepod/feed.class", O_RDWR | O_CREAT, 0644);
		struct stat cst;

		if (cfd >= 0) {
			void *m;

			if (!fstat(cfd, &cst) && cst.st_size < 1 && ftruncate(cfd, 1))
				perror("feed.class");
			m = mmap(NULL, 1, PROT_READ, MAP_SHARED, cfd, 0);
			if (m != MAP_FAILED)
				g_class = m;
			close(cfd);
		}
	}
	while ((opt = getopt(argc, argv, "i:r:R:c:S:x:W:T:l:t:A:s:qp:P:L:D:H:")) != -1) {
		switch (opt) {
		case 'i':
			if (nsrc >= MAXSRC) usage();
			srcs[nsrc].path = optarg; srcs[nsrc].fd = -1; srcs[nsrc].ch = 2;
			src_set_rate(&srcs[nsrc], 44100);
			nsrc++;
			break;
		case 'r':
			if (!nsrc || atoi(optarg) < 8000 || atoi(optarg) > 96000) usage();
			src_set_rate(&srcs[nsrc - 1], atoi(optarg));
			break;
		case 'R':
			if (!nsrc) usage();
			srcs[nsrc - 1].ratefile = optarg;
			break;
		case 'c':
			if (!nsrc || (atoi(optarg) != 1 && atoi(optarg) != 2 && atoi(optarg) != 8)) usage();
			srcs[nsrc - 1].ch = atoi(optarg);
			if (atoi(optarg) == 8) g_has_mc = 1;
			break;
		case 'S':
			if (!nsrc || atof(optarg) < 50 || atof(optarg) > 500) usage();
			srcs[nsrc - 1].sync = 1;
			srcs[nsrc - 1].lead = atof(optarg) / 1000.0;
			src_sync_target(&srcs[nsrc - 1]);
			break;
		case 'x': xover = atof(optarg); break;
		case 'p': g_profile = profile_id(optarg); break;
		case 'P': g_position = !strcmp(optarg, "wall") ? 1 : !strcmp(optarg, "book") ? 2 : 0; break;
		case 'L': g_loud = !strcmp(optarg, "off") ? 1000.0 : atof(optarg); break;
		case 'D': g_twdelay = atoi(optarg); break;
		case 'H': g_subsonic = atof(optarg); break;
		case 'W': wtrim = atof(optarg); break;
		case 'T': ttrim = atof(optarg); break;
		case 'l': limit_db = atof(optarg); break;
		case 'A': align_test = atoi(optarg); break;
		case 's': sleep_us = atoi(optarg); break;
		case 'q': quiet = 1; break;
		case 't': {
			char where[8] = "";
			if (sscanf(optarg, "%lf:%lf:%lf:%7s", &tone_f, &tone_db, &tone_s, where) != 4)
				usage();
			if (where[0] == 'w') tone_where = 0;
			else if (where[0] == 't') tone_where = -3;
			else if (where[0] == 'a') tone_where = -1;
			else tone_where = atoi(where);
			break;
		}
		default: usage();
		}
	}
	if (xover < 200 || xover > 8000 || limit_db > 0 || wtrim > 12 || ttrim > 12)
		usage();
	/* test tones are capped: -20 dBFS, and nothing below 800 Hz on a tweeter word */
	if (tone_where != -2) {
		if (tone_db > -20) tone_db = -20;
		if (tone_where != 0 && tone_where != -1 && tone_f < 800) {
			fprintf(stderr, "hpfeed: refusing %g Hz on a tweeter\n", tone_f);
			return 2;
		}
	}

	fd = open("/dev/mem", O_RDWR | O_SYNC);
	if (fd < 0) { perror("/dev/mem"); return 1; }
	pmgr = mmap(NULL, 0x30000, PROT_READ, MAP_SHARED, fd, PMGR_BASE);
	if (pmgr == MAP_FAILED) { perror("mmap pmgr"); return 1; }
	if (((pmgr[PS_MCA3 / 4] >> 4) & 0xF) != 0xF) {
		fprintf(stderr, "hpfeed: MCA3 power domain is off; run the audio init first\n");
		return 1;
	}
	mca = mmap(NULL, 0x1000, PROT_READ | PROT_WRITE, MAP_SHARED, fd, MCA3_BASE);
	if (mca == MAP_FAILED) { perror("mmap mca"); return 1; }
	if (!(mca[R_TXCTRL] & 1) || !(mca[R_CTRL] & 2)) {
		fprintf(stderr, "hpfeed: MCA3 TX is not running (ctrl %08x tx %08x)\n",
			mca[R_CTRL], mca[R_TXCTRL]);
		return 1;
	}
	__asm__ volatile("mrs %0, cntfrq_el0" : "=r"(tfreq));

	signal(SIGINT, on_sig); signal(SIGTERM, on_sig); signal(SIGHUP, on_sig);
	signal(SIGPIPE, SIG_IGN);
	meter_open();
	g_meter2 = m2_open(METER2_FILE);
	mlockall(MCL_CURRENT | MCL_FUTURE);
	CPU_ZERO(&cs); CPU_SET(1, &cs);
	sched_setaffinity(0, sizeof(cs), &cs);
	if (sched_setscheduler(0, SCHED_FIFO, &sp))
		perror("hpfeed: SCHED_FIFO");

	if (align_test > 0) {
		int i, ok = 0, retries = 0, r, maxretry = 0;
		uint64_t ta = ticks(), tb;
		volatile uint32_t sink = 0;
		for (i = 0; i < 2000; i++) sink += mca[R_STAT];
		tb = ticks();
		fprintf(stderr, "hpfeed: one status read = %.2f us (counter %llu Hz)\n",
			(double)(tb - ta) * 1e6 / (double)tfreq / 2000.0, (unsigned long long)tfreq);
		for (i = 0; i < align_test && !g_stop; i++) {
			r = align(0);
			if (r >= 0) { ok++; retries += r; if (r > maxretry) maxretry = r; }
			/* run aligned for 20 ms on zeros and make sure it holds */
			uint64_t end = ticks() + tfreq / 50;
			while (ticks() < end) {
				int n = (FIFO_HIGH - (int)level()) & ~7;
				while (n-- > 0) mca[R_DATA] = 0;
			}
			if (mca[R_STAT] & ST_UNDER) { ok--; fprintf(stderr, "underrun after align\n"); }
		}
		fprintf(stderr, "hpfeed: align test: %d/%d ok, %d retries total, worst %d\n",
			ok, align_test, retries, maxretry);
		mca[R_MASK] = 0x02;
		return ok == align_test ? 0 : 1;
	}

	g_ceiling = pow(10.0, limit_db / 20.0);
	g_woofer = pow(10.0, wtrim / 20.0);
	g_tweeter = pow(10.0, ttrim / 20.0);
	bq_set(&w_sub, 1, 35.0, 0.7071);
#ifdef __aarch64__
	{
		/* flush-to-zero: recursive filters decaying into subnormals must never cost time */
		unsigned long fpcr;
		__asm__ volatile("mrs %0, fpcr" : "=r"(fpcr));
		fpcr |= 1ul << 24;
		__asm__ volatile("msr fpcr, %0" : : "r"(fpcr));
	}
#endif
	if (g_subsonic < 20 || g_subsonic > 120) g_subsonic = 40;
	dsp_apply();
	dsp_clear(&g_dsp);
	dsp_reload(1);
	bq_set(&w_lp1, 0, xover, 0.7071); bq_set(&w_lp2, 0, xover, 0.7071);
	bq_set(&t_hp1, 1, xover, 0.7071); bq_set(&t_hp2, 1, xover, 0.7071);

	if (tone_where == -2) {
		int j;

		if (!nsrc) {                                   /* stdin */
			srcs[0].path = "stdin"; srcs[0].ch = 2;
			src_set_rate(&srcs[0], 44100);
			nsrc = 1;
			srcs[0].fd = 0;
			fcntl(0, F_SETFL, fcntl(0, F_GETFL) | O_NONBLOCK);
		}
		for (j = 0; j < nsrc; j++) {
			struct src *q = &srcs[j];

			if (q->fd != 0 || strcmp(q->path, "stdin")) {
				q->fd = open(q->path, O_RDWR | O_NONBLOCK);
				if (q->fd < 0) { perror(q->path); return 1; }
			}
			q->ring = calloc(RING, sizeof(float));
			q->sring = calloc(RING, sizeof(float));
			if (!q->sring) { perror("calloc"); return 1; }
			if (q->ch == 8) {
				int k;

				for (k = 0; k < 5; k++)
					if (!(q->xr[k] = calloc(RING, sizeof(float)))) { perror("calloc"); return 1; }
				if (posix_memalign((void **)&q->xtc, 16, sizeof(struct xtc))) { perror("calloc"); return 1; }
				memset(q->xtc, 0, sizeof(struct xtc));
				{
					pthread_attr_t at;

					pthread_attr_init(&at);
					pthread_attr_setstacksize(&at, 256 * 1024);   /* memory is locked: keep it small */
					if (!(q->tb = malloc(TBUF)) || pthread_create(&q->thr, &at, src_reader, q)) { perror("reader"); return 1; }
				}
			}
			if (!q->ring) { perror("calloc"); return 1; }
		}
		have_in = 1;
	}

	if (align(1) < 0)
		return 1;
	if (have_in)
		feed_state("idle\n");

	{
		uint32_t wbuf[FIFO_HIGH];
		double ph = 0.0, tone_amp = pow(10.0, tone_db / 20.0);
		long long frames = 0, tone_total = (long long)(tone_s * RATE);
		long underruns = 0, realigns = 0;
		int minlvl = 255, i, j, k, announced = 0;
		uint64_t next_conf = 0;
		uint64_t next_stat = ticks() + 5 * tfreq, next_in = 0;

		uint64_t tlast = ticks(), maxgap = 0, m2gap = 0;
		int m2lvl = 255;                         /* the same two figures over one meter2 period */

		while (!g_stop) {
			uint32_t st = mca[R_STAT];
			int lvl = (int)(st & ST_LEVEL), nfr;
			uint64_t tnow = ticks(), gap = tnow - tlast;

			tlast = tnow;
			if (gap > maxgap) maxgap = gap;
			if (!(st & ST_UNDER)) g_t_conf = g_t_pump = g_t_sleep = g_t_dsp = g_t_read = 0;   /* per iteration; kept for the report */
			if (gap > m2gap) m2gap = gap;
			if (st & ST_UNDER) {
				underruns++;
				if (!quiet)
					fprintf(stderr, "hpfeed: UNDERRUN #%ld: loop stalled %.0f us (uptime %.3f s; before it: settings %.0f us, input %.0f us, sleep %.0f us, audio %.0f us; longest read %.0f us on input %d, returned %d)\n",
						underruns, (double)gap * 1e6 / (double)tfreq,
						(double)tnow / (double)tfreq, (double)g_t_conf * 1e6 / (double)tfreq, (double)g_t_pump * 1e6 / (double)tfreq,
						(double)g_t_sleep * 1e6 / (double)tfreq, (double)g_t_dsp * 1e6 / (double)tfreq,
						(double)g_t_read * 1e6 / (double)tfreq, g_t_read_src, g_t_read_n);
				if (align(0) < 0)
					return 1;
				realigns++;
				for (j = 0; j < nsrc; j++) srcs[j].fade = 0.0;
				tlast = ticks();
				continue;
			}
			if (lvl < minlvl) minlvl = lvl;
			if (lvl < m2lvl) m2lvl = lvl;
			nfr = (FIFO_HIGH - lvl) >> 3;
			if (nfr <= 0) {
				uint64_t now = ticks();
				if (have_in && now >= next_in) {
					int any = 0;

					next_in = now + tfreq / 2000;
					if (now >= next_conf) {
						static int tick;

						/* 20 times a second: the volume lives in this file and must follow a slider */
						next_conf = now + tfreq / 20;
						dsp_reload(1);
						g_t_conf = 1;                    /* marked; timed below */
						for (j = 0; j < nsrc; j++)
							src_sync_target(&srcs[j]);   /* profile or trim changed */
						if (++tick >= 20) {
							tick = 0;
							if (g_profile == 3)
								a3_power_loop(&g_a3);   /* once a second */
						}
					}
					if (g_t_conf) g_t_conf = ticks() - now;
					{ uint64_t t0 = ticks();
					for (j = 0; j < nsrc; j++) pump_input(&srcs[j], now);
					g_t_pump = ticks() - t0; }
					for (j = 0; j < nsrc; j++) {
						struct src *q = &srcs[j];

						if (q->head != q->last_head) {
							q->last_head = q->head;
							q->last_in = now;
							if (!q->announced) {
								q->announced = 1;
								q->wake_t0 = now;
								src_reload_rate(q);
							}
						} else if (q->announced && !q->playing && now - q->last_in > tfreq / 2) {
							/* nothing new for half a second and nothing playing */
							q->announced = 0;
							q->tail = q->head;
						}
						any |= q->announced;
					}
					if (any != announced) {
						feed_state(any ? "play\n" : "idle\n");
						announced = any;
					}
				} else if (sleep_us > 0) {
					struct timespec ts = { 0, sleep_us * 1000L };
					uint64_t t0 = ticks();
					nanosleep(&ts, NULL);
					g_t_sleep = ticks() - t0;
				}
				if (!quiet && now >= next_stat) {
					fprintf(stderr, "hpfeed: %s frames=%lld underruns=%ld clipped=%ld "
						"minlevel=%d maxstall=%.0fus",
						announced ? "play" : "idle", frames, underruns, g_clipped,
						minlvl, (double)maxgap * 1e6 / (double)tfreq);
					for (j = 0; j < nsrc; j++) {
						fprintf(stderr, " | %d:%s in=%ums starved=%ld adj=%+.4f%%", j,
							srcs[j].playing ? "play" : "idle",
							s_fill(&srcs[j]) * 1000u / srcs[j].rate,
							srcs[j].starved, srcs[j].adj * 100.0);
						if (srcs[j].sync)
							fprintf(stderr, " sync=%+.2fms wait=%.1fms snaps=%ld",
								srcs[j].playing && srcs[j].pre_ok ?
								(srcs[j].pre_avg - srcs[j].target) * 1000.0 / srcs[j].rate : 0.0,
								srcs[j].target * 1000.0 / srcs[j].rate, srcs[j].snaps);
					}
					if (g_profile == 3) {
						m2_fold_hits();
						a3_meters(&g_a3);
						fprintf(stderr, " | drc %.1f/%.1f/%.1f/%.1f dB hp=%.0fHz x=%.1f>%.1fmm P48=%.0fW P12=%.0fW avg=%.0fW eff=%.2f pg=%.2f/%.2f slow=%.2f lim w=%ld t=%ld",
							g_a3.m_gr[0], g_a3.m_gr[1], g_a3.m_gr[2], g_a3.m_gr[3], g_a3.m_hp, g_a3.m_xmm, g_a3.m_xout,
							g_a3.m_p48, g_a3.m_p12, g_a3.pg.pavg,
							g_a3.a.cfg.effort > g_a3.p_eff ? g_a3.a.cfg.effort : g_a3.p_eff,
							g_a3.m_gw, g_a3.m_gt, g_a3.m_slow, g_a3.m_wlim, g_a3.m_tlim);
					}
					if (g_profile == 2) {
						fprintf(stderr, " | drc %.1f/%.1f/%.1f/%.1f dB hp=%.0fHz x=%.1fmm xg=%.2f lim w=%ld t=%ld",
							g_a2.m_gr[0], g_a2.m_gr[1], g_a2.m_gr[2], g_a2.m_gr[3],
							g_a2.m_fc, g_a2.m_xmm, g_a2.m_xgr, g_a2.m_wlim, g_a2.m_tlim);
						g_a2.m_wlim = g_a2.m_tlim = 0;
					}
					if (g_a3.eq.set.on && g_profile >= 2)
						fputs(" | eq on", stderr);
					if (g_chan)
						fprintf(stderr, " | channels=%s", chan_name[g_chan]);
					fputc('\n', stderr);
					minlvl = 255; maxgap = 0; tlast = ticks();
					next_stat = now + 5 * tfreq;
				}
				continue;
			}

			for (i = 0; i < nfr; i++) {
				uint32_t *w = &wbuf[i * SLOTS];

				if (tone_where != -2) {
					double env = 1.0, s;
					long long left = tone_total - frames - i;
					if (frames + i < 480) env = (frames + i) / 480.0;
					if (left < 480) env = left > 0 ? left / 480.0 : 0.0;
					s = sin(ph) * tone_amp * env;
					ph += 2.0 * M_PI * tone_f / RATE;
					if (ph > 2.0 * M_PI) ph -= 2.0 * M_PI;
					if (tone_where == -1) {
						frame_from(s, 0.0, w);
					} else {
						uint32_t v = (uint32_t)to_word(s);
						for (k = 0; k < SLOTS; k++)
							w[k] = (tone_where == -3) ? (k ? v : 0)
							     : (k == tone_where ? v : 0);
					}
					continue;
				}

				/* stream: sum of every source that is playing */
				{
					double mix = 0.0, side = 0.0;

					g_x[0] = g_x[1] = g_x[2] = 0.0;
					for (j = 0; j < nsrc; j++)
						mix += src_sample(&srcs[j], &side);
					if (g_mute ? g_mgain > 0.0 : g_mgain < 1.0) {
						g_mgain += g_mute ? -1.0 / 2880.0 : 1.0 / 2880.0;
						if (g_mgain < 0.0) g_mgain = 0.0;
						if (g_mgain > 1.0) g_mgain = 1.0;
					}
					mix *= g_mgain; side *= g_mgain;
					if (g_ch_on)
						ch_run(&mix, &side);
					if (g_has_mc) {
						g_x[0] *= g_mgain; g_x[1] *= g_mgain; g_x[2] *= g_mgain;
						ext_mix();
					}
					meter_tap(mix);
					m2_in(mix);
					frame_from(mix, side, w);
				}
			}
			for (i = 0; i < nfr * SLOTS; i++)
				mca[R_DATA] = wbuf[i];
			g_t_dsp = ticks() - tnow;
			frames += nfr;
			if (g_m.n >= METER_PERIOD)
				meter_publish(announced);
			g_m2.frames += nfr;
			if (g_m2.frames >= METER2_PERIOD) {
				m2_publish(g_meter2, announced, underruns, m2lvl, (double)m2gap * 1e6 / (double)tfreq);
				m2lvl = 255; m2gap = 0;
			}

			if (tone_where != -2 && frames >= tone_total + 960)
				break;
			for (j = 0; j < nsrc; j++)
				src_servo(&srcs[j]);
		}

		if (have_in)
			feed_state("idle\n");
		/* leave quietly: ramp is in the data path already; flush zeros, stay aligned */
		{
			uint64_t end = ticks() + tfreq / 50;
			while (ticks() < end) {
				int n = (FIFO_HIGH - (int)level()) & ~7;
				while (n-- > 0) mca[R_DATA] = 0;
			}
		}
		if (!quiet)
			fprintf(stderr, "hpfeed: exit frames=%lld underruns=%ld realigns=%ld clipped=%ld\n",
				frames, underruns, realigns, g_clipped);
	}
	mca[R_MASK] = 0x02;      /* back to the single-slot default; FIFO drains to silence */
	return 0;
}
