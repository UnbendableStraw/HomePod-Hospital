/*
 * hpxtc.h - the "virtual surround" stage in front of the speaker processing, for a multichannel
 * (5.1.2) source: audioOS renders the surround and height pairs through a pair of FIR filters each
 * (AUSpatialMixer, built-in speaker output, with the crosstalk-cancellation set b238a_XTCIR_default_*).
 * The filters themselves are Apple's and are not in this source: xtc_load() reads them at start from the file
 * the build makes out of the user's own audioOS. [set][input][output][tap], set 0 = one speaker ("_5"),
 * set 1 = a member of a stereo pair ("_20"); inputs SL, SR, HL, HR; outputs left, right.
 * Front, centre and LFE are not filtered, only delayed by XTC_DELAY to stay aligned (spatDelayComp*).
 */
#ifndef HPXTC_H
#define HPXTC_H
#define XTC_TAPS 128
#define XTC_DELAY 32
#define XTC_GAIN_SOLO 1.6788f          /* AUSMChannelOverrides Gain, multichannel_music_solo_* */
#define XTC_GAIN_PAIR 1.4125f          /* multichannel_music_lt_* / rt_* */
#define XTC_FILE "/usr/lib/nicotine/xtc.bin"
static float xtc_fir[2][4][2][XTC_TAPS] __attribute__((aligned(16)));

/* The filters, from the file the build made out of the user's audioOS (tools/extract_xtc.py):
 * "NICXTC1\0", u32 taps, float32 [set][input][output][tap]. Returns 1 if they were loaded. Otherwise every
 * input goes to its own side through a plain delay, at the level the filters would leave it. */
static int xtc_load(const char *path)
{
	FILE *f = fopen(path, "rb");
	unsigned char head[12];
	int set, i, ok = 0;

	if (f) {
		ok = fread(head, 1, 12, f) == 12 && !memcmp(head, "NICXTC1", 8) &&
		     (head[8] | head[9] << 8 | head[10] << 16 | (unsigned)head[11] << 24) == XTC_TAPS &&
		     fread(xtc_fir, sizeof(float), 2 * 4 * 2 * XTC_TAPS, f) == 2 * 4 * 2 * XTC_TAPS;
		fclose(f);
	}
	if (!ok) {
		memset(xtc_fir, 0, sizeof(xtc_fir));
		for (set = 0; set < 2; set++)
			for (i = 0; i < 4; i++)
				xtc_fir[set][i][i & 1][XTC_DELAY] = 1.0f / (set ? XTC_GAIN_PAIR : XTC_GAIN_SOLO);
	}
	return ok;
}
struct xtc { float h[4][XTC_TAPS * 2]; int p; float dl[3][XTC_DELAY]; int dp; };

/* input side, per frame as it arrives (cheap): in = FL FR C LFE SL SR HL HR, -1..1.
 * m, s, c = (FL+FR)/2, (FL-FR)/2, C+LFE, delayed by XTC_DELAY; the four surround/height samples are passed on as they are. */
static inline void xtc_in(struct xtc *x, const float *in, float *m, float *s, float *c)
{
	int dp = x->dp;
	float fl = x->dl[0][dp], fr = x->dl[1][dp];

	*c = x->dl[2][dp];
	x->dl[0][dp] = in[0]; x->dl[1][dp] = in[1]; x->dl[2][dp] = in[2] + in[3];
	x->dp = dp + 1 == XTC_DELAY ? 0 : dp + 1;
	*m = 0.5f * (fl + fr); *s = 0.5f * (fl - fr);
}

/* output side, once per output sample (this is where the work is, so that it is spread evenly):
 * sur = SL SR HL HR; ul / ur = what they put on the left / right speaker feed. */
static inline void xtc_out(struct xtc *x, int set, const float *sur, double *ul, double *ur)
{
	const float g = set ? XTC_GAIN_PAIR : XTC_GAIN_SOLO;
	float l = 0.0f, r = 0.0f;
	int i, p = x->p = (x->p + XTC_TAPS - 1) & (XTC_TAPS - 1);

	for (i = 0; i < 4; i++) {
		x->h[i][p] = x->h[i][p + XTC_TAPS] = sur[i];
		l += a2_fir(xtc_fir[set][i][0], &x->h[i][p], XTC_TAPS);
		r += a2_fir(xtc_fir[set][i][1], &x->h[i][p], XTC_TAPS);
	}
	*ul = g * l; *ur = g * r;
}
#endif
