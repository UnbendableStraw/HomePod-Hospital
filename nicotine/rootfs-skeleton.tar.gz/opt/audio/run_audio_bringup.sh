#!/bin/sh
#
# run_audio_bringup.sh - Master script for Nicotine audio bring-up.
#
# Run this step-by-step. Each step verifies the previous one worked
# before proceeding. Abort at any step if something looks wrong.
#
# BEFORE RUNNING:
#   1. Read SAFETY.txt
#   2. Have emergency_stop.sh ready in another terminal
#   3. Know that you can physically unplug the HomePod if needed
#

SCRIPT_DIR="$(cd "$(dirname "$0")" && pwd)"
PYTHON="python3"

# Check Python is available
if ! command -v $PYTHON >/dev/null 2>&1; then
    echo "Python3 not found. Some scripts require it."
    echo "Minimal functions available via shell scripts only."
    PYTHON=""
fi

# Logging
LOG_DIR="$SCRIPT_DIR/logs"
mkdir -p "$LOG_DIR"
LOG="$LOG_DIR/bringup_$(date +%Y%m%d_%H%M%S).log"

log() {
    echo "$@" | tee -a "$LOG"
}

run_py() {
    if [ -z "$PYTHON" ]; then
        log "ERROR: Python3 required for $1"
        return 1
    fi
    log ">>> $PYTHON $SCRIPT_DIR/$@"
    $PYTHON "$SCRIPT_DIR/$@" 2>&1 | tee -a "$LOG"
    return ${PIPESTATUS[0]}
}

separator() {
    log ""
    log "================================================================"
    log "  STEP $1: $2"
    log "================================================================"
}

pause() {
    log ""
    log "Review the output above. Press Enter to continue or Ctrl+C to abort."
    read dummy
}

# ========================================================
# Step 0: Check prerequisites
# ========================================================
separator 0 "Prerequisites"

log "Script directory: $SCRIPT_DIR"
log "Log file: $LOG"
log "Date: $(date)"
log "Kernel: $(uname -a)"
log ""

# Check /dev/mem
if [ ! -c /dev/mem ]; then
    log "WARNING: /dev/mem not found. Trying to create..."
    mknod /dev/mem c 1 1 2>/dev/null
    if [ ! -c /dev/mem ]; then
        log "ERROR: Cannot create /dev/mem. MMIO access won't work."
    fi
fi

# Check for serial devices
log "Serial devices:"
ls -la /dev/tty* 2>/dev/null | head -20 | tee -a "$LOG"

pause

# ========================================================
# Step 1: Check peripheral clock states
# ========================================================
separator 1 "Check Peripheral Clocks"

log "Checking if audio peripherals are clocked..."
run_py find_clocks.py check

log ""
log "If any peripheral shows NOT_CLOCKED, we need to enable its clock gate."
log "Run: python3 find_clocks.py discover   (to try auto-discovery)"
log "  or: python3 find_clocks.py gates      (to see all clock gates)"

pause

# ========================================================
# Step 2: Probe Nitrogen MCU
# ========================================================
separator 2 "Probe Nitrogen MCU"

log "Attempting to communicate with Nitrogen MCU..."
log "(This tries serial port first, then MMIO UART fallback)"
run_py nitrogen.py probe

log ""
log "Expected: firmware version string, MCU ID, command list."
log "If no response: UART8 may not be clocked, or baud rate is wrong."

pause

# ========================================================
# Step 3: Dump MCA registers
# ========================================================
separator 3 "MCA Register Dump"

log "Scanning audio register blocks..."
run_py mca_dump.py scan

log ""
log "Detailed MCA3 dump:"
run_py mca_dump.py mca3

log ""
log "NCO state:"
run_py mca_dump.py nco

log ""
log "I2S switch:"
run_py mca_dump.py i2s

pause

# ========================================================
# Step 4: Power up audio chain
# ========================================================
separator 4 "Power Up Audio Chain"

log "IMPORTANT: This powers up the amplifiers."
log "- Tweeters will be initialized but MUTED"
log "- Woofer will NOT be powered (needs crossover protection)"
log "- Emergency stop: run emergency_stop.sh in another terminal"
log ""
log "Proceed with power-up? Press Enter or Ctrl+C to skip."
read dummy

run_py audio_powerup.py powerup

log ""
log "Check telemetry output above for any faults or warnings."

pause

# ========================================================
# Step 5: Start telemetry monitor (background)
# ========================================================
separator 5 "Telemetry Monitor"

log "Starting telemetry monitor in background..."
log "(This will monitor temperature and faults while we test audio)"
log ""

if [ -n "$PYTHON" ]; then
    $PYTHON "$SCRIPT_DIR/telemetry_monitor.py" --interval 5 >> "$LOG_DIR/telemetry.log" 2>&1 &
    TELEM_PID=$!
    log "Telemetry monitor PID: $TELEM_PID"
    log "Log: $LOG_DIR/telemetry.log"
else
    log "Skipping (no Python)"
    TELEM_PID=""
fi

pause

# ========================================================
# Step 6: Attempt test tone (STRETCH GOAL)
# ========================================================
separator 6 "Test Tone (Stretch Goal)"

log "This attempts to play a test tone through tweeter 1."
log "The MCA must be properly configured and clocked for this to work."
log ""
log "Parameters:"
log "  Frequency: 1000 Hz"
log "  Amplitude: -30 dB (very quiet)"
log "  Duration:  1 second"
log "  Slot:      1 (first tweeter)"
log ""
log "This is a STRETCH GOAL - the MCA setup may not be complete"
log "enough for this to produce audible output."
log ""
log "Proceed? Press Enter or Ctrl+C to skip."
read dummy

run_py test_tone.py tone --freq 1000 --db -30 --duration 1.0 --slot 1

pause

# ========================================================
# Step 7: Shutdown
# ========================================================
separator 7 "Shutdown"

log "Shutting down audio chain..."
run_py audio_powerup.py shutdown

# Kill telemetry monitor
if [ -n "$TELEM_PID" ]; then
    kill $TELEM_PID 2>/dev/null
    log "Telemetry monitor stopped."
fi

log ""
log "================================================================"
log "  AUDIO BRING-UP COMPLETE"
log "  Logs saved to: $LOG_DIR"
log "================================================================"
