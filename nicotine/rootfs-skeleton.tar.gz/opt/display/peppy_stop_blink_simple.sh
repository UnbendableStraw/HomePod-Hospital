#!/bin/sh
# peppy_stop_blink_simple.sh -- RUN ON THE HOMEPOD (not on the Mac).
#
# Stops the top-LED blinking by telling the peppy MCU (Cypress PSoC, I2C
# address 0x55 on I2C3 = MMIO 0x20a113000) to leave AutoLED mode:
#
#     i2cset -y BUS 0x55 0x15 0x01
#
# You do not need to know BUS: this script works it out.
#
# Usage:
#   sh peppy_stop_blink_simple.sh          auto-detect the bus
#   sh peppy_stop_blink_simple.sh 3        force bus number 3
#
# From the Mac, in one step:
#   ./run_on_pod.sh display/peppy_stop_blink_simple.sh

ADDR=0x55
CMD=0x15
VAL=0x01
I2C3_MMIO=20a113000
SYS="${SYS:-/sys}"        # overridable for testing

have() { command -v "$1" >/dev/null 2>&1; }

if [ "$(uname -s)" != "Linux" ]; then
    echo "ERROR: this script must run ON the HomePod, not on $(uname -s)."
    echo "From the Mac use:  ./run_on_pod.sh display/peppy_stop_blink_simple.sh"
    exit 1
fi

# ---- 1. List buses ---------------------------------------------------------
echo "=== I2C buses (i2cdetect -l) ==="
if have i2cdetect; then
    i2cdetect -l 2>&1
else
    echo "(i2cdetect not available; listing $SYS/class/i2c-adapter instead)"
    for a in $SYS/class/i2c-adapter/i2c-*; do
        [ -e "$a" ] && echo "${a##*/}  $(cat "$a/name" 2>/dev/null)"
    done
fi
echo ""

BUSES=""
for dev in /dev/i2c-*; do
    [ -c "$dev" ] && BUSES="$BUSES ${dev#/dev/i2c-}"
done
if [ -z "$BUSES" ]; then
    echo "ERROR: no /dev/i2c-* devices. The kernel has no I2C adapters (or no"
    echo "i2c-dev support), so there is nothing to send the command to."
    exit 1
fi

# ---- 2. Work out which bus has the peppy MCU --------------------------------
# Which Linux bus number is I2C3 (0x20a113000)? sysfs tells us without
# touching the bus.
I2C3_BUS=""
for n in $BUSES; do
    path=$(readlink -f "$SYS/class/i2c-adapter/i2c-$n" 2>/dev/null)
    case "$path" in
        *"$I2C3_MMIO"*) I2C3_BUS="$n" ;;
    esac
done

probe() {   # probe BUS -> 0 if something answers at 0x55
    have i2cdetect || return 1
    i2cdetect -y -r "$1" "$ADDR" "$ADDR" 2>/dev/null | grep -q "^50:.* 55"
}

BUS="${1:-}"
if [ -n "$BUS" ]; then
    echo "Using bus $BUS (given on command line)."
else
    # Try I2C3 first, then everything else.
    ORDER="$I2C3_BUS"
    for n in $BUSES; do
        [ "$n" = "$I2C3_BUS" ] || ORDER="$ORDER $n"
    done
    for n in $ORDER; do
        printf 'Probing bus %s for 0x55 ... ' "$n"
        if probe "$n"; then
            echo "found"
            BUS="$n"
            break
        else
            echo "no answer"
        fi
    done

    if [ -z "$BUS" ] && [ -n "$I2C3_BUS" ]; then
        echo ""
        echo "Nothing answered at 0x55, but bus $I2C3_BUS is I2C3 (0x$I2C3_MMIO),"
        echo "where the peppy MCU lives. Trying the command there anyway."
        BUS="$I2C3_BUS"
    fi
fi

if [ -z "$BUS" ]; then
    echo ""
    echo "ERROR: could not find the peppy MCU (0x55) on any bus, and no adapter"
    echo "maps to I2C3 (0x$I2C3_MMIO). Run scripts/i2c_debug.sh for details."
    exit 1
fi

[ -n "$I2C3_BUS" ] && echo "Note: I2C3 (0x$I2C3_MMIO) is Linux bus $I2C3_BUS."
echo ""

# ---- 3. Send the stop-blink command -----------------------------------------
send_i2cset()      { i2cset -y "$BUS" "$ADDR" "$CMD" "$VAL"; }
send_i2ctransfer() { i2ctransfer -y "$BUS" "w2@$ADDR" "$CMD" "$VAL"; }
send_python() {
    python3 - "$BUS" <<'PYEOF'
import fcntl, os, sys
fd = os.open("/dev/i2c-" + sys.argv[1], os.O_RDWR)
fcntl.ioctl(fd, 0x0703, 0x55)          # I2C_SLAVE
os.write(fd, bytes([0x15, 0x01]))
os.close(fd)
PYEOF
}

OK=0
TRIED=0
for method in i2cset i2ctransfer python3; do
    have "$method" || continue
    TRIED=1
    case "$method" in
        i2cset)      echo "Sending: i2cset -y $BUS $ADDR $CMD $VAL" ;;
        i2ctransfer) echo "Sending: i2ctransfer -y $BUS w2@$ADDR $CMD $VAL" ;;
        python3)     echo "Sending: raw write of 0x15 0x01 to /dev/i2c-$BUS (python3)" ;;
    esac
    fn="send_$method"; [ "$method" = python3 ] && fn=send_python
    if "$fn"; then
        OK=1
        break
    fi
    echo "  -> $method failed, trying next method"
done

echo ""
if [ "$OK" = 1 ]; then
    echo "SUCCESS: command accepted by the peppy MCU on bus $BUS."
    echo "The LEDs should stop blinking. If they start again later, re-run this"
    echo "script (or use peppy_keepalive.sh $BUS)."
    exit 0
fi

if [ "$TRIED" = 0 ]; then
    echo "ERROR: none of i2cset, i2ctransfer or python3 exist on this system."
    exit 1
fi

echo "FAILED: the peppy MCU did not accept the command on bus $BUS."
echo "Last kernel I2C messages:"
dmesg 2>/dev/null | grep -i "i2c" | tail -5
echo ""
echo "If you see 'Bus stuck' or 'NACK' for 20a113000.i2c above, the problem is"
echo "the I2C3 bus itself, not this command. Run:  sh i2c_debug.sh"
exit 1
