#!/bin/bash
# peppy_stop_blink.sh — Stop the HomePod 1st gen display LEDs from blinking
#
# The HomePod's top display is controlled by a Cypress CY8C4245LQI-483 (PSoC 4)
# touch/LED controller, known internally as "peppy-mcu". It sits on I2C bus 3
# at address 0x55.
#
# When the PSoC doesn't receive communication from the host SoC, it enters an
# autonomous "AutoLED" mode where the volume button LEDs blink. This is the
# blinking seen when:
#   - The HomePod is bricked (can't boot)
#   - Linux is booted (no peppy driver)
#   - The MCU times out waiting for the host
#
# The audioOS kernel extension "ApplePeppyDriver" disables AutoLED by sending
# I2C command 0x15 (SET_TOUCHPAD_SCAN) with a mode byte:
#   Bit 0: TouchScan enable (1=on, 0=off)
#   Bit 1: AutoLED enable (1=on, 0=off)
#
# Usage: peppy_stop_blink.sh [bus_number]
#   bus_number: Linux I2C bus number for I2C3 (default: auto-detect)

set -e

PEPPY_ADDR=0x55
CMD_VERSION=0x01
CMD_SET_TOUCHPAD_SCAN=0x15

# Auto-detect I2C bus (look for the one with peppy at 0x55)
find_i2c_bus() {
    for bus in /dev/i2c-*; do
        num="${bus#/dev/i2c-}"
        # Try to detect device at 0x55
        if i2cdetect -y -r "$num" 0x55 0x55 2>/dev/null | grep -q "55"; then
            echo "$num"
            return 0
        fi
    done
    return 1
}

BUS="${1:-}"
if [ -z "$BUS" ]; then
    echo "Auto-detecting I2C bus with peppy MCU at 0x55..."
    BUS=$(find_i2c_bus) || {
        echo "ERROR: Could not find peppy MCU on any I2C bus."
        echo "Make sure the I2C driver is loaded. Try:"
        echo "  modprobe i2c-dev"
        echo "  modprobe i2c-apple (or your platform I2C driver)"
        echo ""
        echo "If i2c-dev is loaded but no buses appear, the I2C"
        echo "controller driver may not be loaded. The HomePod A8's"
        echo "I2C3 is at MMIO address 0xa113000."
        echo ""
        echo "Manual fallback with devmem (requires busybox/devmem2):"
        echo "  See peppy_devmem.sh for direct MMIO I2C access."
        exit 1
    }
    echo "Found peppy MCU on I2C bus $BUS"
fi

echo "Peppy MCU at I2C bus $BUS, address $PEPPY_ADDR"

# Step 1: Wake the PSoC / query version (command 0x01)
# This is the first thing ApplePeppyDriver does on start
echo "Sending wake/version command (0x01)..."
i2cset -y "$BUS" "$PEPPY_ADDR" "$CMD_VERSION" 2>/dev/null || true

# Small delay for the MCU to process
sleep 0.1

# Step 2: Disable AutoLED (command 0x15, data 0x01)
# Mode byte: bit0=1 (TouchScan ON), bit1=0 (AutoLED OFF) → 0x01
echo "Disabling AutoLED mode (command 0x15, mode=0x01)..."
i2cset -y "$BUS" "$PEPPY_ADDR" "$CMD_SET_TOUCHPAD_SCAN" 0x01 2>/dev/null && {
    echo "SUCCESS: AutoLED disabled. Volume button LEDs should stop blinking."
} || {
    echo "WARNING: i2cset command 0x15 with data 0x01 failed."
    echo "Trying alternative: disable everything (mode=0x00)..."
    i2cset -y "$BUS" "$PEPPY_ADDR" "$CMD_SET_TOUCHPAD_SCAN" 0x00 2>/dev/null && {
        echo "SUCCESS: All modes disabled (TouchScan + AutoLED off)."
    } || {
        echo "ERROR: Could not communicate with peppy MCU."
        echo "The I2C bus may not be properly initialized."
        exit 1
    }
}

echo ""
echo "Note: The blinking will resume if the HomePod reboots or the"
echo "MCU resets. To keep it stopped, run this script at boot or"
echo "set up a periodic heartbeat (see peppy_keepalive.sh)."
