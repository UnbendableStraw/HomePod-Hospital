#!/bin/bash
# peppy_probe.sh — Probe and identify the HomePod peppy MCU via I2C
#
# Sends various I2C commands to the Cypress CY8C4245 (peppy-mcu) and
# reports what it finds. Use this to verify I2C communication works
# before trying to control LEDs.
#
# Usage: peppy_probe.sh [bus_number]

set -e

PEPPY_ADDR=0x55
BUS="${1:-}"

# Auto-detect
find_bus() {
    for bus in /dev/i2c-*; do
        num="${bus#/dev/i2c-}"
        if i2cdetect -y -r "$num" 0x55 0x55 2>/dev/null | grep -q "55"; then
            echo "$num"
            return 0
        fi
    done
    return 1
}

if [ -z "$BUS" ]; then
    echo "Scanning I2C buses for peppy MCU..."
    BUS=$(find_bus) || {
        echo "Not found. Listing available I2C buses:"
        ls -la /dev/i2c-* 2>/dev/null || echo "  No I2C buses found. Load i2c-dev module."
        exit 1
    }
fi

echo "========================================"
echo "HomePod Peppy MCU Probe"
echo "========================================"
echo "I2C bus: $BUS"
echo "Address: 0x55"
echo ""

# Scan the full I2C3 bus to see what's there
echo "--- I2C Bus Scan ---"
echo "Expected devices: 0x29 (ALS sensor), 0x55 (peppy MCU)"
i2cdetect -y -r "$BUS" 2>/dev/null || echo "i2cdetect failed"
echo ""

# Try reading version info (command 0x01)
echo "--- Version Info (command 0x01) ---"
# The version command returns several bytes
# Format: [version_hi] [version_lo] [res1_hi] [res1_lo] [res2_hi] [res2_lo] [val_hi] [val_lo]
echo -n "Attempting version read: "
i2cget -y "$BUS" "$PEPPY_ADDR" 0x01 w 2>/dev/null && echo "(OK)" || echo "(failed)"
echo ""

# Try reading the current mode byte
echo "--- Read Mode Byte ---"
echo -n "Current touchpad/AutoLED mode: "
i2cget -y "$BUS" "$PEPPY_ADDR" 0x15 2>/dev/null || echo "(could not read)"
echo ""

# Try to read serial number (if accessible)
echo "--- Serial Number ---"
echo -n "Serial read attempt: "
i2cget -y "$BUS" "$PEPPY_ADDR" 0x02 w 2>/dev/null || echo "(not accessible via simple read)"
echo ""

echo "--- Raw Byte Reads ---"
echo "Attempting to read first 16 register bytes..."
for reg in $(seq 0 15); do
    hex=$(printf "0x%02x" $reg)
    val=$(i2cget -y "$BUS" "$PEPPY_ADDR" "$hex" 2>/dev/null) || val="--"
    printf "  Reg 0x%02x: %s\n" $reg "$val"
done
echo ""

echo "--- Known Command Map ---"
echo "  0x01  Version Info / Wake"
echo "  0x11  Set LED Multi-Display State"
echo "  0x15  Set Touchpad Scan Mode (bit0=Touch, bit1=AutoLED)"
echo "  0x20  GPIO Control"
echo "  0x23  Raw Command Passthrough"
echo "  0x28  LED MD State Read"
echo "  0x38  CLCG Data Read"
echo "  0x39  CLCG Data Write"
echo ""
echo "To stop blinking: i2cset -y $BUS 0x55 0x15 0x01"
echo "To turn off all LEDs: i2cset -y $BUS 0x55 0x15 0x00"
