#!/bin/bash
# peppy_keepalive.sh — Periodic keepalive daemon for the peppy MCU
#
# The peppy MCU (Cypress CY8C4245) may re-enter AutoLED blink mode
# if it doesn't receive communication for an extended period. This
# script sends periodic SET_TOUCHPAD_SCAN commands to keep it quiet.
#
# Usage: peppy_keepalive.sh [bus_number] [interval_seconds]
#   bus_number: I2C bus (default: auto-detect)
#   interval_seconds: Keepalive interval (default: 30)

PEPPY_ADDR=0x55
CMD_SET_TOUCHPAD_SCAN=0x15
INTERVAL="${2:-30}"

find_bus() {
    for bus in /dev/i2c-*; do
        num="${bus#/dev/i2c-}"
        if i2cdetect -y -r "$num" 0x55 0x55 2>/dev/null | grep -q "55"; then
            echo "$num"
            return 0
        fi
    done
    return 1
}

BUS="${1:-}"
if [ -z "$BUS" ]; then
    BUS=$(find_bus) || {
        echo "ERROR: Could not find peppy MCU"
        exit 1
    }
fi

echo "Peppy keepalive daemon starting"
echo "  Bus: $BUS  Address: $PEPPY_ADDR  Interval: ${INTERVAL}s"
echo "  Press Ctrl+C to stop"

# Initial command to stop blinking immediately
i2cset -y "$BUS" "$PEPPY_ADDR" 0x01 2>/dev/null || true
sleep 0.1
i2cset -y "$BUS" "$PEPPY_ADDR" "$CMD_SET_TOUCHPAD_SCAN" 0x01 2>/dev/null || true

while true; do
    sleep "$INTERVAL"
    # Send SET_TOUCHPAD_SCAN with TouchScan=1, AutoLED=0
    i2cset -y "$BUS" "$PEPPY_ADDR" "$CMD_SET_TOUCHPAD_SCAN" 0x01 2>/dev/null || {
        echo "WARNING: keepalive send failed at $(date)"
    }
done
